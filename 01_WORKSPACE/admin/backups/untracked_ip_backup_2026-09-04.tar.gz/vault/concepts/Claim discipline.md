# Claim discipline

> Tags: #concept #claim-discipline #inference #detection #thesis #g0 #g1 #g2

The core thesis of LUNARVOID: **"calibrated inference, never verified
detection."** FP is reported per 10⁴ km². Nothing subsurface on the
Moon is verifiable today except the radar-evidenced Tranquillitatis
conduit. Use "inferred void candidate at confidence X" — never
"detected a lava tube."

## Key facts

- Inference language: "inferred void candidate at confidence X"
  (with tier A/B/C and methods column); "detected a lava tube" is
  reserved for direct evidence (radar, seismic, skylight entry) which
  we do not have at any of the 21 on-disk DTMs.
- Radar-evidenced Tranquillitatis conduit is the **only** verified
  subsurface lunar feature to date; the project's G0′ pass note
  explicitly states the MTP is the only known positive for the
  frozen calibration.
- FP per 10⁴ km² is the primary FP metric. P1-comparable residual
  tables are reported in cm (P1 ref: mean 10.99 / median 8.24 /
  SD 21.64 cm) for terrain fidelity checks.
- Tier-A is **not** assigned in P3.1c — it requires two independent
  evidence legs (gravity / thermal / illumination in addition to
  morphometry), which is the standard for declaring an inference
  strong enough to anchor downstream engineering decisions.
- All gate reports quote the calibration-context caveat on every FP
  number; every candidate carries its tier in the registry.

## Source

`AGENTS.md` rule on claim discipline (read before working);
`lunarvoid-conventions` skill §6 (statistics & claim discipline);
`00_SOURCE_ORIGINALS/LUNARVOID_Master_Plan_v5_Full_Synthesis.txt`
thesis statement. Paper 1 v0.2 review in `01_WORKSPACE/notes/findings.md`
enforced the language in every figure caption and table footnote.

## Related

- [[concepts/Detection vs DEM-evidence]] — what "detection" would require
- [[concepts/Calibration-context FP rate]] — the FP rate is not a survey rate
- [[gates/G0prime]] / [[gates/G1]] / [[gates/G2]] — every gate enforces the language
- [[backlog/Deferred items]] — Tier-A promotion deferred until ≥2 evidence legs per candidate
- [[artifacts/Candidate registry]] — tier column enforces the rule per row

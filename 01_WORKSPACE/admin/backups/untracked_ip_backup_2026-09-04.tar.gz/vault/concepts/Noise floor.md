# Noise floor

> Tags: #concept #noise-floor #detectability #g1 #g2 #mare #highland

Project convention: **3 × pooled sag-band RMS = per-DTM detectability
threshold** (local_Amin). Only sag amplitudes A ≥ 3·RMS are above
single-DTM detectability. Below that, matched-filter or multi-evidence
stacking is required (G1 result).

## Key facts

- Per-DTM pooled sag-band RMS is the 60–300 m band-passed residual
  RMS (sag-band RMS ~1.25–1.38 m on flat mare), NOT per-pixel SD.
- 3 × pooled sag-band RMS per DTM (calibration-target examples):
  - TRANQPIT1 (krigcorr): pooled 1.245 m → **3.74 m** threshold
  - MARIUSPIT01 (krigcorr): pooled 1.379 m → **4.14 m** threshold
  - Mare median (n=9): pooled 1.118 m → median Amin **3.36 m**
  - Highland median (n=5): pooled 1.089 m → median Amin **3.27 m**
- 1–2 m sags (which would be the most interesting candidate
  amplitudes for small voids) need matched-filter / multi-evidence
  stacking — single-DTM detection is noise-floor-limited.
- Slope mask ≥10° lifts detector F1 by removing gentle-slope FPs
  (v0.3, unchanged in v0.5); recall unaffected.
- Recovered depth can EXCEED catalogued (fill-to-spill of valid
  pixels) — document, not an error.

## Source

`01_WORKSPACE/data/outputs/wp0_kriging/per_dtm_floors_summary.json`
(per_dtm.<DTM>.local_Amin_m fields); `lunarvoid-conventions` skill
§5 (interpretation semantics) and §6 (statistics). G1 §3 row 4
records the 3× convention as a project rule.

## Related

- [[artifacts/Per-DTM noise floors]] — the per-DTM table this rule generates
- [[gates/G1]] / [[gates/G2]] — noise-floor gate drives the detectability verdicts
- [[concepts/Terrain extrapolation]] — highland floors reported for completeness
- [[concepts/Kriging I2]] — low-frequency correction sets the floor
- [[mocs/MOC Sites & Candidates]] — per-site pooled-RMS table

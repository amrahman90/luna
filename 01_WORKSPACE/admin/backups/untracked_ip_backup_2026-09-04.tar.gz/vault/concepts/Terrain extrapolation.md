# Terrain extrapolation

> Tags: #concept #terrain #extrapolation #highland #mare #g2 #frozen

Detector trained on TRANQPIT1 (mare). Transferring to highland
(TYCHOPK, KINGCRATER, FRESHMELT) is **extrapolation, not portability**.
Flag with `terrain_extrapolation` annotation; do not count FPs from
highland sites toward the aggregate.

## Key facts

- TRANQPIT1 calibration is mare-only. Per `per_dtm_floors_summary.json`
  `by_terrain.highland.terrain_extrapolation_note`: "TRANQPIT1
  calibration is mare-only. Highland per-DTM floors are reported for
  completeness, but any morphometric inference on highland sites
  using the frozen (mare-calibrated) thresholds is extrapolation,
  not portability."
- 9 highland / impact-melt sites (TYCHOPK02/03/04/07, KINGCRATER2/3/4,
  FRESHMELT, FRESHMELT1) have `local_Amin = NaN` (no usable flat
  panels in central peak / impact-melt terrain) and are marked
  below-local-floor by default.
- They are preserved in `01_WORKSPACE/data/candidate_registry.csv`
  with the `terrain_extrapolation` annotation in the `notes` column
  but DO NOT contribute to the aggregate FP count.
- TYCHOPK (1.44 GiB float32) is also memory-deferred — needs
  Tier-1 rental or tile-based processing.
- `methods/METHODS doc` lists `terrain_extrapolation` as a per-DTM
  field on every noise-floor row for TYCHOPK*, KINGCRATER*, FRESHMELT*.

## Source

`01_WORKSPACE/data/outputs/wp0_kriging/per_dtm_floors_summary.json`
`by_terrain.highland` block + every per-DTM row carrying
`terrain_extrapolation: "highland; TRANQPIT1 calibration is mare-only;
results are extrapolation, not portability"`. `transfer_summary.json`
`aggregate.highland_extrapolation_note` and `scope_caveats` confirm
exclusion from FP counting.

## Related

- [[sites/TYCHOPK02]] — exemplar highland/central-peak DTM
- [[artifacts/METHODS doc]] — documents the freeze and per-DTM annotation
- [[artifacts/Per-DTM noise floors]] — 7 panel-skip rows on highland
- [[gates/G2]] — verdict 5/1/2/1/1/1/1 includes terrain-extrapolation as a separate PARTIAL row
- [[concepts/Claim discipline]] — extrapolation ≠ portability ≠ detection

# Planchon-Darboux fill mandate

> Tags: #concept #method #fill #whitebox #wp0 #terrain-engine

**Non-negotiable rule** for depression filling in the LUNARVOID
terrain engine: use `whitebox.fill_depressions_planchon_and_darboux`
ONLY. Wang & Liu and breach fills silently produce wrong answers on
NoData-rich lunar NAC DTMs.

## Why (the silent bug)

Wang & Liu and breach-style fills **DRAIN the NoData pit floor**:
they treat NoData as terrain and route water down through it. On a
DTM where the NoData fraction is ≥ 5 %, Wang & Liu returns a
"filled" surface ≈ 0.3 m below the surrounding terrain where the
true pit floor is ≈ 130 m below. The detector then sees no sag and
the pit is missed entirely.

Planchon-Darboux (Planchon & Darboux 2002) handles NoData as
impedance: it fills around NoData regions but does not route flow
through them. On TRANQPIT1 the recovered depth is 130.2 m
(Wang & Liu: 0.31 m, breach: 0.28 m). Recovery is **420×** closer
to truth with the mandated fill.

## Reference implementations

- `code/wp0_primitive/depression_depth.py` — primary fill driver
- `code/wp0_primitive/sweep_pits.py` — uses the fill output to
  compute per-pit depth
- Variant comparison table: `01_WORKSPACE/notes/2026-08-19_task3_transqpit1_fill_variants.md`
  (every variant tested on TRANQPIT1; PD wins by ≥ 100× on depth)

## Adjacent gotchas

- Always pass `fill_depressions_planchon_and_darboux` an absolute
  path AND set `wbt.set_working_dir('/tmp')`; relative paths trigger
  "No such file or directory" on WhiteboxTools 2.4.0.
- Always copy `src.profile.copy()` from the input raster — fresh
  GeoTIFF profiles lack geokeys, and WhiteboxTools errors with
  "TIFF does not contain geokeys" before reading.
- Record the **NoData fraction** within the analysis window in the
  per-DTM floor CSV — it changes fill semantics for downstream
  detectors.

## Related

- [[artifacts/Smoke test]] — smoke test verifies PD fill on the
  synthetic cloud (per-rung F1 0.392 / 0.000 / 0.800)
- [[gates/G0prime]] — G0′ freezes the PD-mandate in the WP0
  acceptance criteria
- [[concepts/Noise floor]] — fill is upstream of the local-envelope
  noise floor

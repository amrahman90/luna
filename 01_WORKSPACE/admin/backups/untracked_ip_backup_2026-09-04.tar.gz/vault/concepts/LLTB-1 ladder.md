# LLTB-1 ladder

> Tags: #concept #lltb1 #benchmark #degradation-ladder #synthetic #analog

LUNARVOID Ladder Test Bed v1: a controlled detector-chain benchmark
on **synthetic + Indian Tunnel analog** data, with composed
degradation axes (illumination × sensor). v0.5 = Hapke shadow
voiding + sensor (PSF + SNR + bad-pixel) + noise; **31 arms × 4
rungs**. Composed F1 across rungs is the headline.

## Key facts

- Ladder is a **benchmark of a detector chain**, not a detection claim
  (Paper 1 v0.2 review confirmed language).
- v0.5 composition: baseline → noise-only → sensor-only (PSF, SNR
  50/100/200, bad pixels, bad lines) → Hapke illumination (i = 45/65/85)
  → Hapke + sensor combined. Total 31 arms × 4 rungs.
- Rungs: 0.5, 1, 2, 5 m. Seed 42 throughout; deterministic.
- Headline F1 (composed, +10° slope mask):
  - 0.5 m: 0.349 → 0.096 (Hapke + sensor mean)
  - 1 m: 0.276 → 0.103
  - 2 m: 0.254 → 0.109
  - 5 m: 0.154 → 0.136
- Analog-scope caveat (13.3 verbatim): "label population is
  trench-hosted = shadow-prone; a roofed-sag-on-open-mare target is
  UNTESTED here." — must ride verbatim into Paper 1.
- Task-12 entrance-trench+skylight mask NOT used as GT; NorthSurface
  numbers stay separate from the v0.4 §8 site table.

## Source

`01_WORKSPACE/notes/2026-08-22_LLTB1_v0.5_release_note.md` (headline
table + caveats); `01_WORKSPACE/admin/verification_evidence/2026-08-22_v05_verification.json`
(11/11 PASS); `lunarvoid-conventions` skill §8 (LLTB-1 build know-how).

## Related

- [[artifacts/LLTB-1 v0.5]] — the v0.5 artefact this concept describes
- [[artifacts/Smoke test]] — known-good F1 0.392/0/0.800 anchor
- [[gates/G1]] / [[gates/G2]] — ladder results quoted in gate verdicts
- [[concepts/Claim discipline]] — "benchmark, not a detection claim"
- [[concepts/Frangi filter]] — Frangi is the underlying detector the ladder scores

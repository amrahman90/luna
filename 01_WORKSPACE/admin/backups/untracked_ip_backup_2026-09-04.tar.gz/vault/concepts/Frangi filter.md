# Frangi filter

> Tags: #concept #method #frangi #sag-detector #wp1 #lltb1

Multi-scale vessel/ridge detection filter (Frangi, Niessen, Vincken,
 Viergever 1998, MICCAI) adapted in LUNARVOID for **sag detection**
on NAC DTMs. Produces a per-pixel "ridge-likeness" score that
suppresses flat mare while boosting elongated / curved depressions.

## Critical implementation rules (lunarvoid-conventions §8 bug 3)

- **Float64 mandatory** — `np.float32` overflows on large sigmas
  (sigma ≈ 5 px on a 5000 px raster returns 0 or NaN everywhere).
  Cast input array to `np.float64` BEFORE calling `frangi(...)`.
- **Mask NaN AFTER the call** — the filter produces NaN where the
  input was NaN; preserve the input mask, do not let NaN propagate
  into score statistics.
- **Sub-sample to ≤5000 px max dim** — Frangi is O(n²) in the larger
  dimension. A 10 000 × 10 000 DTM tile exhausts RAM and silently
  returns zeros. Use `degrade.degrade()` first if needed.
- Pass `black_ridges=False` (we want depressions, not ridges);
  `sigmas=[1, 2, 4]` covers the 1–4 px scale range typical of sags
  on the 2 m NAC DTM ladder.

## Where it appears

- Implementation: `code/wp1_detector/sag_detect.py`
  (`frangi_score_array` helper)
- Test: `code/wp1_detector/test_frangi.py` (round-trip on synthetic
  single-void cloud)
- LLTB-1 v0.5 release note ([[artifacts/LLTB-1 v0.5]])
- METHODS doc ([[artifacts/METHODS doc]])
- TRANQPIT1 calibration freeze ([[artifacts/TRANQPIT1 calibration freeze]]):
  the v0.3 Frangi sigma sweep produced the frozen sigmas=[1,2,4]
- INGENIIPIT ring artifacts ([[backlog/INGENIIPIT ring artifacts]]) —
  Frangi is one of the two over-trigger sources on circular DTM
  registration seams; the other is the slope mask.

## Related

- [[concepts/Noise floor]] — sag-band RMS is the metric Frangi's
  threshold must beat (3× sag-band RMS ⇒ A≥4 m single-DTM detectable)
- [[concepts/LLTB-1 ladder]] — Frangi is the rung-0 detector
- [[artifacts/Smoke test]] — smoke test exercises Frangi

# Lunar NAC CRS

> Tags: #concept #method #geodesy #crs #nac-dtm #pyproj

How NAC DTM GeoTIFFs are projected and how to convert pit lon/lat to
pixel coordinates correctly.

## The CRS

NAC DTM GeoTIFFs use a **LOCAL equirectangular projection**:

```
+proj=eqc +lat_ts=<center_lat> +lon_0=180 +R=1737400
```

- `R=1737400` — Moon mean radius in metres (NEVER Earth EPSG:4326)
- `lat_ts` — standard parallel set to the DTM centre latitude (gives
  minimal distortion at the DTM centre)
- `lon_0=180` — central meridian at 180° E, so the DTM coords fall
  in the [-180, 180] longitude range
- Units: metres (the projection is plate carrée in radians × R)

## Pit geodesy (the safe recipe)

Build the lon/lat CRS explicitly:

```python
import pyproj
geo = pyproj.CRS.from_proj4("+proj=longlat +R=1737400 +no_defs")
raster_crs = pyproj.CRS.from_proj4(
    f"+proj=eqc +lat_ts={center_lat} +lon_0=180 +R=1737400"
)
to_raster = pyproj.Transformer.from_crs(
    geo, raster_crs, always_xy=True
).transform
x_m, y_m = to_raster(lon_deg, lat_deg)
# then x_m → col, y_m → row via rasterio.transform
```

**NEVER** assume Earth EPSG:4326 semantics (R=6378137 ≠ 1737400
gives ≈ 27× positional error).

## Longitude traps

- NAC DTM frames may use **-180..180** OR **0..360** longitude
  conventions; the `lon_0=180` choice gives the former but some
  derived products use the latter. Always sanity-check before
  bulk processing.
- Some DTM frames are UNWRAPPED metres (no `lon_0`) and need a
  **whole-360° x-shift** to align with the catalogued pit atlas:
  - IRIDIUMPIT1 — needs +360° x-shift before rasterising pit
    positions (see `code/wp0_primitive/sweep_pits.py` pit_to_pixel)
  - FECNDITATS2 — same; see [[sites/FECNDITATS2]]
- Hurwitz rille shapefile uses Moon eqc central-meridian 180 in
  METRES; Earth → Moon reprojection MUST use the explicit R=1737400
  proj4 (the `PIT_DISABLE_CELESTIAL_BODY=1` env workaround exists
  but is fragile).

## Defensive parsing

Pit atlas depth fields are messy strings (`"105"`, `">25"`, `"N/A"`);
parse with `pandas.to_numeric(errors="coerce")` and never trust the
catalogued `DTM` attribute alone (it misses 2/8 covered pits — Ingenii
and SW Fecunditatis; trust the spatial join over the attribute).

## Related

- [[artifacts/METHODS doc]] — §3 documents the CRS recipe
- [[sites/FECNDITATS2]] — 360°-shift example
- [[sites/IRIDIUMPIT1]] — 360°-shift example

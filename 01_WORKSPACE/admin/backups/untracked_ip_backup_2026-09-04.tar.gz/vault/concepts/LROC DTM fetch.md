# LROC DTM fetch

> Tags: #concept #method #lroc #nac-dtm #pds #data-acquisition

How to fetch LROC NAC DTMs from the PDS Node.

## The URL pattern

Base: `https://pds.lroc.im-ldi.com/data/LRO-L-LROC-5-RDR-V1.0/`

Per-DTM path:

```
LROLRC_<year>/DATA/SDP/NAC_DTM/<SITE>/NAC_DTM_<SITE>.TIF
```

Example: `LROLRC_2001/DATA/SDP/NAC_DTM/MARIUSPIT01/NAC_DTM_MARIUSPIT01.TIF`

## Discovery

The HTML UI at `wms.lroc.asu.edu/lroc/view_rdr/NAC_DTM_<SITE>` is
slow and hard to parse. Use the **shape index** instead:

- Layer: `NAC_DTMS_180.SHP` (Esri shapefile of all NAC DTMs)
- Filter by SITE / lat / lon bounding box
- Read with `geopandas.read_file("NAC_DTMS_180.shp")`

The shape index covers all DTMs through LROC mission end-of-life
(2024); refresh quarterly via the PDS Node release notes.

## The 2026-08-22 expansion (11 NEW DTMs, 3.6 GiB)

Per [[gates/G2]]:

- Sites: TYCHOPK02/03/04/07, KINGCRATER2/3/4, FRESHMELT,
  FRESHMELT1, FECUNPIT (10 highland + 1 mare).
- All fetched `curl -L` from PDS Node; all sha256-verified against
  the PDS MD5 manifest; commit `7860631` is the canonical fetch
  manifest.
- Memory ceiling hit on TYCHOPK (1.44 GiB raster); deferred to
  tile-based processing (requires Tier-1 rental).

## Companion manifest

- `01_WORKSPACE/data/lroc_dtm_availability.csv` — full DTM table
  with status (fetched / cached / deferred / memory-bound)
- `01_WORKSPACE/data/MANIFEST.csv` — per-file URL + sha256 +
  licence

## Related

- [[concepts/PDS fetch]] — general PDS fetch recipe (redirects,
  politeness, MANIFEST discipline)
- [[gates/G2]] — G2 expansion consumed these 11 new DTMs
- [[mocs/MOC Sites & Candidates]] — registry of 21 sites, 17 ran +
  4 deferred

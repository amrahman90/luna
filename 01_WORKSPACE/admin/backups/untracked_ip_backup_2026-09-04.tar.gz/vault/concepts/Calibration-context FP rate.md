# Calibration-context FP rate

> Tags: #concept #fp #calibration-context #g1 #g2 #cycle-1 #cycle-2 #claim-discipline

The aggregate false-positive rate from the project's frozen TRANQPIT1
calibration, **NOT a survey rate**. Selection-biased to the 21-24
catalogued-pit / impact-melt sites on disk. Always report the per-DTM
rate, the Poisson-exact (Garwood) confidence interval, and the
calibration-context caveat in the same row.

## Key facts

- **Current (post-Cycles 1-2, 2026-08-23):** 3.74 [Poisson-exact Garwood 95% CI 1.71, 7.10] per 10⁴ km²
  aggregate over 24,062.96 km² (n_fp=9 unchanged; 278 tier-C registry rows;
  n_above_local_floor = 45; 14 above-floor inferred candidates; 233 below-floor).
  Cycles 1+2 added 9,222.69 km² (TYCHOPK 3,016.80 + GRUITHUIS17 2,320.91 +
  GRUITHMARE2 2,258.77 + MARIUSCONE 1,626.21), all below-floor, contributing
  0 new FPs. **Calibration-context, NOT survey rate; selection-biased to
  catalogued pits; G1 §3 row 10 verdict.**
- **Pre-Cycle-1 (G2 close, 2026-08-23):** 6.06 [2.77, 11.51] per 10⁴ km² aggregate
  (N=21, 14,840.27 km², 9 FP) — transfer to 17 ran DTMs (4 deferred).
- **Pre-Cycle-1 (G1 close, 2026-08-22):** 3.71 [0.76, 10.83] per 10⁴ km² aggregate
  (N=7, 8,092 km², 3 FP) — calibration freeze applied.
- The 24 on-disk DTMs are ALL pit-associated or impact-melt catalogued
  (selection bias toward catalogued pits, no random-mare control).
- This is **not** a mare-wide inference; G1 METHODS doc explicitly
  warns "Do not extrapolate to mare-wide inference."
- The TRANQPIT1-alone rate is **240.41 [49.58, 702.58] per 10⁴ km²**
  (n=4, very wide CI) — quoting the bare point estimate without
  context is misleading.
- Tier-A is not assigned in P3.1c; tier-B is multi-method within
  Task 18 (rille or LU5M812TGT chain within 100 m); tier-C is
  single-method morphometry only. FP counting uses tier-B + tier-C
  above the local 3σ noise floor.
- **New failure mode (Cycle 1, 2026-08-23):** `deep-pit low-vesselness`
  (`frangi@score_max < 0.02` AND `depth@score_max ≥ 100 m`) — circular
  depressions, not tubular; tier C with NAC visual inspection required
  before any tier-B promotion. 12 of 21 new rows tagged.

## Source

`01_WORKSPACE/data/outputs/wp2_sag/transfer/transfer_summary.json`
`aggregate.fp_per_1e4km2_interpretation` field (verbatim quote),
`scope_caveats` block. Calibration freeze in
`01_WORKSPACE/data/outputs/wp2_sag/transfer/calibration_transqpit1.json`.
Paper 1 v1.0 (2026-08-23) folds in Cycles 1-2 numbers + new fall-back rule.

## Related

- [[artifacts/TRANQPIT1 calibration freeze]] — source of the parameters
- [[artifacts/Transfer summary]] — N=24 effective aggregate
- [[concepts/Claim discipline]] — never "detected", always "inferred"
- [[concepts/Poisson-exact CI]] — CI for low-n Poisson
- [[concepts/Terrain extrapolation]] — highland FPs are NOT in the aggregate
- [[concepts/Deep-pit low-vesselness]] — new Cycle 1 failure mode
- [[gates/G2]] — verdict 5/1/2/1/1/1/1 (PARTIAL row 10, Cycles 1-2 closure)

# Kriging I2 correction

> Tags: #concept #method #kriging #i2 #wp0 #correction

Low-frequency kriged correction applied to NAC DTMs to mop up
residual I2 (long-wavelength topography) that survives SOCET SET /
ASP photogrammetric pipelines after LOLA registration.

## Magnitude (small)

Published NAC DTMs are already LOLA-registered; the residual I2 is
typically < 0.5 m peak-to-peak on a 2 km DTM. On the TRANQPIT1
verification DTM, applying kriging drops the cross-track residual
**RMSE 0.373 → 0.327 m** (12 % reduction). The residual noise floor
after correction is **≈ 0.33 m** for typical mare DTM coverage.

## Spectrum constraint (load-bearing)

The correction must stay **strictly low-frequency**:

- > 99 % of the kriged correction's power must lie at
  **λ > 300 m** (i.e. wavelengths longer than the largest pit
  diameter in the catalogued pit atlas).
- Pit depth must be preserved to **± 10 %** after correction (no
  pit may gain or lose more than 10 % of its depth through the
  correction).
- Spectrum check is implemented as `kriging_correction.check_psd()`
  in `code/wp0_kriging/kriging_correction.py` — runs
  `scipy.signal.welch` on the corrected-vs-input difference and
  asserts 99 % power below the 1/300 m⁻¹ spatial frequency.

## Reference

- Driver: `code/wp0_kriging/kriging_correction.py`
- Per-DTM output: `01_WORKSPACE/data/outputs/wp0_kriging/per_dtm_floors{,_summary.json}`
- Cross-DTM summary: [[artifacts/Per-DTM noise floors]]

## Why it's safe

Because the correction is low-pass and small, it cannot fabricate
sags: a 5 m amplitude 80 m wide pit is at λ ≈ 80 m, well inside the
> 99 % power-at-λ>300 m envelope. The pit spectrum is untouched;
only the DC-to-300 m drift is corrected.

## Related

- [[concepts/Noise floor]] — defines the post-correction
  ≈ 0.33 m floor the detector competes against
- [[artifacts/Per-DTM noise floors]] — per-DTM RMSE before/after
- [[artifacts/TRANQPIT1 calibration freeze]] — TRANQPIT1 frozen as
  the calibration site

# Detection vs DEM-evidence

> Tags: #concept #claim-discipline #epistemics

The core LUNARVOID thesis distinction: **DEM evidence is a
morphological proxy, not a void detection**. Nothing subsurface on
the Moon is verifiable today from orbit alone except the
radar-evidenced Tranquillitatis conduit (SELENE/Kaguya
ground-penetrating radar; see references/Robinson 2010 for the
imaging analogue).

## What we actually compute

- A **morphometric sag** on a NAC DTM is consistent with a buried
  void (lava tube, drained fracture, impact-melt cavity).
- It is ALSO consistent with: DTM registration artefact, slope
  shadow mis-modelled by photoclinometry, NoData bleed-through,
  noise-floor excursion, secular slope under-correction, or
  genuine non-void topography (a boulder field rim, a rille wall
  undercut).
- The **same data** supports every interpretation; the
  morphometry alone does not discriminate.

## Why this matters

Every LUNARVOID candidate is therefore labelled an **inferred void
candidate** with a confidence tier and an evidence legs count, never
a "detected lava tube". Tier-A promotion requires morphometry PLUS
one independent evidence leg (gravity, thermal, illumination, or
radar). At G2 every candidate is tier C (morphometry alone); tier A
is currently 0/257.

## Operational rule

All visual-inspection backlog items (FECUNPIT cluster,
TRANQPIT1 12-km FPs, INGENIIPIT ring artifacts) require **NAC
browse inspection** before any "detection" claim, no matter how
clean the score. The score is necessary, not sufficient.

## Related

- [[concepts/Claim discipline]] — vocabulary ("inferred", "candidate",
  "consistent with") and the tiering scheme
- [[backlog/FECUNPIT cluster]] — 3 unique large depressions awaiting
  browse inspection
- [[backlog/TRANQPIT1 12-km FPs]] — TRANQPIT1 12-km FPs awaiting
  browse inspection
- [[backlog/INGENIIPIT ring artifacts]] — ring artefacts that look
  sag-like but are DTM seams

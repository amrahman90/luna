# I14 funnel risk

> Tags: #concept #i14 #funnel #marius #skeptic #tier #g2

v5 master-plan I14 prediction: pits incised into sinuous rilles
(Marius Hills) spill sideways → **funnel failure mode**. Skeptic
UNSOUND on P3.1c (2026-08-22): the initial tier-B count was
mechanical pre-downgrade; I14 funnel inversion requires demotion
to tier C for rille intersections.

## Key facts

- All 3 MARIUSPIT01 tier-B rows in `01_WORKSPACE/data/candidate_registry.csv`
  were **demoted to tier C** following the skeptic review.
- The detection target (a sinuous rille host) is the failure mode
  itself — a rille-incised pit has the right shape but the wrong
  genesis; the demotion preserves it in the registry but flags it
  as single-method morphometry only.
- Marius Hills is the canonical example; the rille-shoulder
  confusion-layer intersection rule (`pit ∩ rille within 100 m` from
  Hurwitz 2013) flips to **not** count as independent evidence when
  the pit is **incised into** the rille.
- Skeptic UNSOUND verdict logged in `01_WORKSPACE/notes/findings.md`
  (P3.1c cluster, 2026-08-22): tier-B count was mechanical
  pre-downgrade; I14 funnel inversion requires demotion.
- Funnel failure mode is itself a **finding** (not a bug) — to be
  reported in Paper 1 as a v5 prediction confirmed by the I14
  inversion rule.

## Source

`01_WORKSPACE/notes/findings.md` P3.1c cluster (skeptic UNSOUND block).
v5 master plan I14 (`00_SOURCE_ORIGINALS/LUNARVOID_Master_Plan_v5_Full_Synthesis.txt`).
Candidate registry tier field audit (3 MARIUSPIT01 rows now tier C).

## Related

- [[sites/MARIUSPIT01]] — the affected site
- [[artifacts/Candidate registry]] — where the demotion lives
- [[artifacts/METHODS doc]] — documents the tier-B rule
- [[../notes/findings]] — full skeptic audit trail
- [[gates/G2]] — tier-B → C demotion reflected in 5/1/2/1/1/1/1 verdict
- [[concepts/Claim discipline]] — funnel inversion is a finding, not a detection

# PDS fetch

> Tags: #concept #method #pds #data-acquisition #wget #curl #nasa

How to fetch lunar data from the Planetary Data System reliably.

## The redirect trap

PDS URLs **301-redirect** to `pds.mcp.nasa.gov`. Always:

```bash
curl -L -A "Mozilla/5.0" -o output.tar.gz "https://pds.nasa.gov/.../file.tar.gz"
```

Without `-L`, you get a 301 and an empty file. The redirect target
is the canonical MCP (Mission Control Platform) host and is
stable since 2024.

## LOLA RDR by bounding box

REST pattern (used in `code/wp0_kriging/kriging_correction.py`):

```
https://oderest.rsl.wustl.edu/livegds/?query=lolardr
  &bounds=lat_min,lat_max,lon_min,lon_max
  &output=csv
```

- Returns CSV with `Pt_Radius`, latitude, longitude — `Pt_Radius`
  is on the **R=1737400 m sphere** (NOT Earth radius).
- Planetocentric latitude (NOT planetographic).
- PDS data is **public domain**; no licence header needed in MANIFEST.

Dead historical endpoints (do NOT use): `ode.dm.asu.edu` is
DNS-dead; old REST paths 404.

## Zenodo

```bash
curl -sL "https://zenodo.org/api/records/<id>" | jq '.files[].links.self'
```

Parallel range-streams beat single curl by ~50× on large files
(4 parallel `curl --range` streams = ~50 MB/s aggregate vs ~1 MB/s
serial on LU5M812TGT).

LU5M812TGT craters dataset is **CC-BY-4.0** — credit + licence link
in MANIFEST.

## Wayback fallback for 403 / dead links

Brown University planetary and LPI frequently 403 or vanish. Use the
Wayback CDX API:

```bash
curl -sL "https://web.archive.org/cdx/search/cdx?url=example.com/path&output=json&limit=1"
```

Then fetch the snapshot at `web.archive.org/web/<timestamp>/<url>`.

## Politeness

- Browser UA (`Mozilla/5.0 ...`) only where needed (some PDS nodes
  reject `curl/x.y` outright).
- Back off on 429 (the Wustl LOLA REST returns 429 on > 10 req/min).
- ≤ 3 retries with exponential backoff.

## MANIFEST discipline

EVERY acquisition gets a MANIFEST row in
`01_WORKSPACE/data/MANIFEST.csv` with:

- URL
- SHA-256 of the downloaded file
- Licence (public domain / CC-BY-4.0 / research-academic-only / ISRO)
- DTM/site tag if applicable

This is enforced by the verifier on every commit.

## Related

- [[concepts/LROC DTM fetch]] — the specific LROC NAC DTM fetch recipe
- [[artifacts/Per-DTM noise floors]] — PDS-fetched DTMs feed this
- [[gates/G2]] — G2 fetched 11 new NAC DTMs from PDS (3.6 GiB)

# Deep-pit low-vesselness

> Tags: #concept #method #fp #cycle-1 #g2 #skeptical-rule #terrain-extrapolation

A new failure-mode classification introduced by the skeptic Cycle 1 second-opinion (2026-08-23) for the WP2 sag-search pipeline. Distinguished from the pre-existing central-peak-relief FP family by the depth × low-vesselness signature.

## Definition

A candidate is **deep-pit low-vesselness** iff:
1. `frangi@score_max < 0.02` (Frangi vesselness at the score-maximum pixel is very low — NOT tubular)
2. `depth@score_max ≥ 100 m` (the depression is deep)

Both conditions must be true. A candidate satisfying only one is classified differently:
- Shallow × low Frangi → normal below-floor (terrain extrapolation)
- Deep × high Frangi → tubular void signal (genuine candidate; rare)

## Why the threshold <0.02 and not <0.05

Skeptic Cycle 1 (2026-08-23) authored the rule after testing both thresholds against the 21 Cycles 1-2 rows + the 9 pre-existing highland rows:

- **At <0.05:** TYCHOPK02 (frangi@score=0.054) is wrongly flagged as deep-pit. But TYCHOPK02 is a central-peak site (shallow × moderate Frangi), not deep-pit. Threshold too loose.
- **At <0.02:** Only MARIUSCONE (0.011) and GRUITHMARE2 (0.015) are captured. TYCHOPK02 correctly NOT flagged. TYCHOPK Cycle 2 (frangi=0.0185, depth=18.35 m) correctly NOT flagged (depth condition fails — 18.35 < 100 m).

The <0.02 threshold cleanly separates the two FP families:
- **Central-peak-relief** (TYCHOPK02/03/04/07, KINGCRATER2/3/4, FRESHMELT/1): shallow × moderate (frangi 0.05-0.18)
- **Deep-pit low-vesselness** (MARIUSCONE, GRUITHMARE2): deep × low (frangi < 0.02)

## Sites currently classified

- **GRUITHMARE2** (33.3943°N, -43.3329°W; Cycle 1 2026-08-23): top-5 cluster at 33.3943°N -43.3329°W; depth 604 m, frangi@score 0.015; score_max 9.02. Highland terrain near Gruithuisen Domes. 10 below-floor registry rows.
- **MARIUSCONE** (13.6250°N, -56.3975°W; Cycle 1 2026-08-23): top-5 cluster at 13.6250°N -56.3975°W; depth 619 m, frangi@score 0.011; score_max 6.64. Volcanic cone province. 2 below-floor registry rows.

Both sit in geologically high-risk terrain; both are circular depressions with no tubular signature; both require NAC visual confirmation before any tier-B promotion.

## Distinguishing from real candidates

A genuine tubular void candidate should have:
- Frangi ≥ 0.05 (vesselness high — ridges are tubular structures)
- Depth ≥ 1 × 3σ local noise floor (~3-5 m for mare DTMs; 3.3-3.7 m at these specific sites per per_dtm_floors)

Neither GRUITHMARE2 nor MARIUSCONE has both. They have depth, but not tubular Frangi. Hence "deep-pit", not "deep-tube".

## Tier rules

- deep-pit low-vesselness rows are **tier C by default** (single-method morphometry).
- They CANNOT be promoted to tier B without NAC visual inspection confirming tubular (not circular) morphology.
- They CANNOT be promoted to tier A regardless — tier A requires ≥2 independent evidence legs (morphometry + gravity/thermal/illumination).
- NAC browse at the cluster center (~6 pixels around the score_max location) is the minimum verification step.

## Annotation in registry

All deep-pit rows get the following appended to the `notes` column:
```
; deep-pit low-vesselness (circular depression, not tubular); requires NAC visual inspection
```

Implemented in `01_WORKSPACE/code/wp2_sag/transfer/apply_skeptic_annotation.py` (Cycle 1; idempotent) and `01_WORKSPACE/code/wp2_sag/transfer/apply_skeptic_annotation_tychopk.py` (Cycle 2; idempotent). Re-running on the same registry is a no-op (annotation already present).

## FP counting impact

Deep-pit low-vesselness rows are **NOT counted as FPs** in the aggregate rate calculation. They are tagged tier C with annotation; their above-floor-or-not status is determined by `sag_amp_m ≥ local_Amin_m`. For Cycles 1-2, all deep-pit rows are below-floor; n_fp = 9 (unchanged from G2 close).

## Source

- Skeptic finding in `01_WORKSPACE/notes/findings.md` § 2026-08-23 Skeptic Cycle 1 second-opinion
- Visual-inspection backlog at [[backlog/GRUITHMARE2 + MARIUSCONE deep-pit]]
- Application scripts: `01_WORKSPACE/code/wp2_sag/transfer/apply_skeptic_annotation.py` + `apply_skeptic_annotation_tychopk.py`
- Cited in Paper 1 v1.0 §4.4 (failure modes) and §3.3.1 (Cycles 1-2 update)

## Related

- [[concepts/Frangi filter]] — vesselness computation; threshold rationale
- [[concepts/Terrain extrapolation]] — the cousin FP family
- [[concepts/I14 funnel risk]] — another skeptic-authored failure mode
- [[concepts/Claim discipline]] — never "detected", always "inferred" / "morphometrically similar to void signature"
- [[backlog/GRUITHMARE2 + MARIUSCONE deep-pit]] — NAC browse targets
- [[artifacts/Transfer summary]] — N=24 effective aggregate, 3.74 [1.71, 7.10] per 10⁴ km²
- [[gates/G2]] — Cycles 1-2 PARTIAL closure
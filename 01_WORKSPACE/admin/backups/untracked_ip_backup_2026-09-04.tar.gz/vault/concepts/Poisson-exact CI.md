# Poisson-exact CI

> Tags: #concept #statistics #poisson #garwood #ci #g2 #low-n

Aggregate FP rates use **Poisson-exact (Garwood) 95% CI** — NOT
Wilson. Verifier flagged 2026-08-23. Formula uses chi-square
quantiles, not normal approximation; appropriate for low-n Poisson
counts (k = 9 FPs at N=21).

## Key facts

- Garwood 95% CI for k observed counts over area A (km²):
  - **lower** = 0.5 · χ²(α/2, 2k) · 10000 / A
  - **upper** = 0.5 · χ²(1−α/2, 2(k+1)) · 10000 / A
- For k=0, the upper bound is the well-known 0.5·χ²(0.975, 2)·10000/A
  = 3.689·10000/A (single-sided equivalent of 2.996/area).
- For the N=21 aggregate (9 FPs over 14,840.27 km²): the Garwood 95%
  CI is **[2.77, 11.51] per 10⁴ km²**; the Wilson CI would be
  wider at the lower end and similarly wide at the upper end, but
  the **mid-p** approximation is NOT equivalent.
- Every per-DTM row in `transfer_summary.json` carries
  `fp_per_1e4km2_ci95_lo`, `fp_per_1e4km2_ci95_hi`, and
  `ci_method: "Poisson-exact (Garwood) 95% CI"`.
- For k ≥ 30 the normal and Garwood intervals agree to within 5 %;
  for k < 30 the Garwood interval is the conservative choice.

## Source

`01_WORKSPACE/data/outputs/wp2_sag/transfer/transfer_summary.json`
`ci_method` field (every per-DTM and per-rung row); G2 §3 row 10
records the rule. `lunarvoid-conventions` skill §6 (statistics).
Verifier flag 2026-08-23 logged in `01_WORKSPACE/notes/findings.md`
G2 cluster (Wilson → Garwood correction).

## Related

- [[artifacts/Transfer summary]] — every FP rate uses this CI
- [[concepts/Calibration-context FP rate]] — the rate the CI brackets
- [[gates/G2]] — verdict row 10 enforces Garwood (not Wilson)
- [[../notes/findings]] — verifier 2026-08-23 audit trail

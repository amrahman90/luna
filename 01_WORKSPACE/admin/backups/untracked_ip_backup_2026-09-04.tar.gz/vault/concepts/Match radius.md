# Match radius

> Tags: #concept #match-radius #frozen #i15 #calibration #g1 #g2

**100 m** is the frozen pit match radius (I15 protocol). A candidate
is a TP if it lies within 100 m of the catalogued pit; FP otherwise.
Tightening to 50 m or relaxing to 150 m both shift the FP count and
the precision-recall balance — both are reported where they matter.

## Key facts

- Frozen in `01_WORKSPACE/data/outputs/wp2_sag/transfer/calibration_transqpit1.json`
  `frozen.surface_recipe.pit_match_radius_m = 100.0` and
  `frozen_calibration.pit_match_radius_m = 100.0` in `transfer_summary.json`.
- **FECUNPIT r003 at 138.1 m** is the canonical borderline case: it
  is just outside the 100 m match radius → labelled FP per protocol.
  Under a 150 m tolerance it would be a borderline-TP.
- r001, r002 at 552.5 m are clearly FPs (no ambiguity).
- v5 I15 prediction: pit atlas positional accuracy ~30 m; match
  radius ≥ 30 m is the lower bound; 100 m is the chosen
  balance between precision and recall for the frozen calibration.
- The 100 m radius is applied to BOTH the calibration (TRANQPIT1)
  and the N=21 transfer (so the FP definition is consistent across
  the project).

## Source

`01_WORKSPACE/data/outputs/wp2_sag/transfer/calibration_transqpit1.json`
`frozen.surface_recipe.pit_match_radius_m`; `transfer_summary.json`
`FECUNPIT.notes` (verbatim 138.1 m / 552.5 m correction, 2026-08-23).
`lunarvoid-conventions` skill §8 (I15 protocol note).

## Related

- [[backlog/FECUNPIT cluster]] — the canonical borderline case
- [[artifacts/TRANQPIT1 calibration freeze]] — where 100 m is frozen
- [[artifacts/Transfer summary]] — the FECUNPIT distance correction
- [[concepts/Calibration-context FP rate]] — 100 m is part of how the FP rate is defined
- [[gates/G1]] — I15 protocol documented as a decision

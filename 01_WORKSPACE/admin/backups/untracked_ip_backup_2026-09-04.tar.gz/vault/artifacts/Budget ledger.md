# Budget ledger

> Tags: #artifact #budget #cost #infra #tier-1

The single project-level budget ledger.

## Source

`01_WORKSPACE/admin/budget.md` (67 lines; opened 2026-08-22).
Append-only ledger; each row is a dated commitment + actual cost.
Verified by the skeptic on every gate close.

## Status as of 2026-08-23

- **Spent:** $0
- **Per-roll cap:** $150 (Phase 6 working budget)
- **Master-plan ceiling:** $800 (over 30 months)
- **Cost triggers pending:** §8 T1 Tier-1 rental (~$55 Hetzner
  AX52-NVMe), §8 T2 paid GPU, §8 T3 VPS, §8 T4 reproduction rental.
  NONE approved by user yet.

## Tier-1 recommendation (paper-writer pending)

**Hetzner AX52-NVMe** (~$55/mo): 64 GB RAM, 1 TB NVMe, 16 vCPU.
Sufficient for:

- TYCHOPK 1.44 GiB tile-based Frangi (deferred at G2)
- 30 random-mare LROC NAC fetches + stereo-rebuild + krigcorr
- Cached v0.5 score rasters for 7 priority sites
- ASP/ISIS reproducibility demo on 5–10 DTMs

Total Tier-1 commitment for one G2 → G3 cycle: ~$55 single month.

## Cost discipline (rule)

- $0 spent without explicit user approval of a §8 cost trigger.
- Every tier-1 / tier-2 commit MUST add a budget.md row BEFORE the
  work begins (verifier rejects otherwise).
- LROC PDS access is $0 (public domain); no licence cost.

## Related

- [[decisions/Tier-1 trigger]] — the §8 T1 cost-trigger decision
  (user approval flow)
- [[mocs/MOC Sessions & Ops]] — session-by-session cost roll-up

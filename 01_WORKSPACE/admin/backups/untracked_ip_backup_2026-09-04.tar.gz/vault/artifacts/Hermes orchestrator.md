# Hermes orchestrator

> Tags: #artifact #orchestration #infra #hermes

The LUNARVOID orchestrator as deployed inside the parallel Hermes
agent framework. **This note is a synonym / canonical-name alias
for [[artifacts/Hermes port]]** — the orchestrator IS the port;
there is one artifact, two names. Pick whichever name fits the
context (this note when the topic is orchestration; the port note
when the topic is the cross-framework porting work).

## Identity (port summary)

- Skill: `~/.hermes/skills/lunarvoid-orchestrator/SKILL.md`
- Loads repo skills by absolute path
- `~/.hermes/config.yaml` `skills.external_dirs` → `.opencode/skills/`
- Cross-framework lock owner: `hermes` (see [[artifacts/Cross-framework lock]])
- Budget discipline identical to opencode

## Operating split with opencode

| Owner | Lead on | Subagent |
|---|---|---|
| opencode | `01_WORKSPACE/papers/**` | paper-writer |
| hermes | `01_WORKSPACE/plans/**` (gate reports) | orchestrator |
| shared | MANIFEST, candidate_registry.csv | (via lock) |

See [[artifacts/Hermes port]] for the full porting recipe and the
list of opencode-only features (MCP servers, vision) that Hermes
does not have.

## Related

- [[artifacts/Cross-framework lock]] — concurrent-edit mutex
- [[decisions/Vault architecture]] — owner split decision

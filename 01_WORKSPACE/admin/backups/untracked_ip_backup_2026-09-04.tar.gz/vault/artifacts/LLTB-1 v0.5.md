# LLTB-1 v0.5

> Tags: #artifact #benchmark #lltb1 #degradation-ladder #frozen #g1 #g2

The sensor-degradation stage of the LUNARVOID Ladder Test Bed v1
(LLTB-1) — composed illumination × sensor arms over the frozen
Hapke axis from v0.4. A **benchmark of the detector chain**, not a
detection claim.

## Key facts

- Verification: 11/11 PASS, see
  `01_WORKSPACE/admin/verification_evidence/2026-08-22_v05_verification.json`
  (max |ΔF1| = 5.55e-17 recomputed from `sensor_f1_comparison.csv`).
- Composed table at 0.5 m rung: baseline 0.349 → noise-only 0.300 →
  sensor-only (SNR100) 0.309 → Hapke mean **0.096** (range 0.051–0.122) →
  Hapke+sensor SNR100 mean **0.096**.
- 2 m rung sensor-only: **0.254 → 0.122** (n_void = 53, SNR ordering
  non-monotone: SNR50 0.069, SNR100 0.122, SNR200 0.074).
- Hapke shadow voiding corrected 2026-08-22 to azimuth-means
  **62 / 75 / 92 %** (i=45/65/85; per-azimuth ranges 52–68 / 67–80 /
  85–95 %); old 68/79/95 % were favorable single-azimuth figures.
- Ladder: **31 arms × 4 rungs** (0.5 / 1 / 2 / 5 m), seed 42, deterministic.
- Sensor stage: nan-aware Gaussian PSF (σ = 0.5/1.0/1.5/2.0 cells),
  radiometric height noise σ_z = 16.5·res/SNR (SNR arms 50/100/200;
  SNR=100 @ 2 m → 0.33 m, the Z2 TRANQPIT1 NAC anchor), 0.5 % bad
  pixels + 2 bad lines; applied AFTER Hapke.
- Tuner collapse (thr=0 predict-all) persists on every shadow-degraded
  arm by protocol — documented finding, not rescued.
- Smoke test unchanged: F1 0.392 / 0.000 / 0.800 on synthetic, fusion
  AUC 0.990.

## Source

Canonical release note: `01_WORKSPACE/notes/2026-08-22_LLTB1_v0.5_release_note.md`
(76 lines). Verification record: `01_WORKSPACE/admin/verification_evidence/2026-08-22_v05_verification.json`.
Skeptic review applied corrections 2026-08-22 (azimuth means + collapse
attribution) per `findings.md` (Paper 1 review cluster).

## Related

- [[concepts/LLTB-1 ladder]] — what the ladder is and why it exists
- [[artifacts/Smoke test]] — known-good F1 0.392/0/0.800 anchor
- [[gates/G1]] — v0.4 site table pass; v0.5 composed rungs reported
- [[gates/G2]] — v0.5 verified 11/11 before G2 lock
- [[artifacts/Per-DTM noise floors]] — 3× pooled sag-band RMS gates what is detectable
- [[concepts/Claim discipline]] — "benchmark, not a detection claim"

# Cross-framework lock

> Tags: #artifact #lock #concurrency #infra #orchestration

Cross-agent mutex that prevents the opencode paper-writer agent and
the parallel Hermes orchestrator from running conflicting work in
the same repo concurrently.

## The script

`~/lunarvoid/bin/lunarvoid_lock.sh` (2843 bytes)

Pure bash + `flock` + `mktemp` atomic directory creation. No
daemon, no service, no network dependency. The lock file is
`/tmp/lunarvoid.lock.d/` with a per-acquisition PID file.

## Subcommands

- `acquire` — try to take the lock; non-blocking by default
  (returns 0 on success, 1 if held by another owner). Owner is
  inferred from `$LUNARVOID_AGENT` env var (`opencode` | `hermes`).
- `release` — release the lock (only the owner can release).
- `force` — steal the lock unconditionally (DANGER; logs to
  `/tmp/lunarvoid.lock.d/STEAL.log`).
- `status` — print current owner, PID, TTL remaining, acquire time.

## Heartbeat TTL design

- **Default TTL: 6 hours** (21600 s). Chosen as ≥ 3× the longest
  expected paper-writer session (a full release-note run is ~90 min;
  a Tier-1 verification run is ~3 h).
- Same-owner re-acquire (within TTL) **refreshes the heartbeat**
  rather than failing — supports long-running paper-writer
  sessions that span multiple Claude turns.
- After TTL, lock is stealable by either owner via `force`.

## Owners

| Owner | Env `$LUNARVOID_AGENT` | Use case |
|---|---|---|
| `opencode` | unset (default) | paper-writer, geo-coder, verifier, skeptic, archivist |
| `hermes` | `hermes` | parallel Hermes orchestrator session |

Cross-owner `acquire` refuses with exit 1. Same-owner `acquire`
refreshes heartbeat. `release` is owner-checked.

## When to use it

- Before any **destructive** operation (deleting a registry row,
  rewriting the MANIFEST, regenerating site notes).
- Before any **long-running parallel work** (e.g. multi-DTM
  Frangi sweep).
- NOT needed for read-only inspection (grep, read, snapshot).

## Related

- [[artifacts/Hermes orchestrator]] — the other owner
- [[decisions/Vault architecture]] — why the lock exists (concurrent
  edit hazard on `data/candidate_registry.csv`)

# Transfer summary

> Tags: #artifact #transfer #wp2 #g2 #calibration-context #aggregate-fp

N=21 transfer using the frozen TRANQPIT1 calibration (P3.1c, 2026-08-23).
**17 ran + 4 deferred** (TYCHOPK memory ceiling 1.44 GiB; GRUITHUIS17,
GRUITHMARE2, MARIUSCONE no cached score raster). Aggregate FP rate
**6.06 [2.77, 11.51] per 10⁴ km²** over 14,840.27 km² — calibration-context,
selection-biased, NOT a random-mare survey rate.

## Key facts

- Canonical: `01_WORKSPACE/data/outputs/wp2_sag/transfer/transfer_summary.json`
  (1793 lines, 49 DTM×rung pair results).
- Aggregate over 17 ran DTMs: n_candidates=257, n_above_local_floor=45,
  n_tier_B=3, n_tier_A=0, n_fp=**9**, n_tp=14, total_area_km²=14,840.27.
- Per-rung aggregate (Poisson-exact Garwood 95% CI):
  - 2 m: 0.00 [0.00, 9.66] per 10⁴ km²
  - 4 m: 5.17 [1.07, 15.10] per 10⁴ km²
  - 5 m: 10.95 [4.02, 23.83] per 10⁴ km²
  - 8 m: 0.00 [0.00, 66.48] per 10⁴ km²
- FP attribution: 3 from TRANQPIT1 (calibration site) + 6 from FECUNPIT
  (3 unique large depressions at 552.5/552.5/138.1 m from nearest
  catalogued pit; r003 at 138.1 m is just outside the 100 m match radius).
- 9 highland / impact-melt sites (TYCHOPK02/03/04/07, KINGCRATER2/3/4,
  FRESHMELT, FRESHMELT1) marked below-local-floor by default — they
  DO NOT contribute to the FP count but ARE preserved in the registry
  with the `terrain_extrapolation` annotation.
- Skeptic correction 2026-08-23: FECUNPIT distance reference corrected
  from 67 km (named pit) to 138–552 m (nearest catalogued pit in atlas).
- Scope banner: `N=21/649 (3.2%)` — 21 good-tier DTMs on disk of 649 in scope.

## Source

`01_WORKSPACE/data/outputs/wp2_sag/transfer/transfer_summary.json` —
`scope_banner`, `frozen_calibration`, `aggregate.fp_per_1e4km2_*` and
`aggregate.skeptic_corrections` blocks. Skeptic audit trail in
`01_WORKSPACE/notes/findings.md` (P3.1c + distance-reference clusters).

## Related

- [[mocs/MOC Sites & Candidates]] — per-DTM rows + scope banner
- [[concepts/Calibration-context FP rate]] — what 6.06 means and does NOT mean
- [[concepts/Poisson-exact CI]] — Garwood 95% CI for low-n Poisson
- [[artifacts/TRANQPIT1 calibration freeze]] — frozen parameters applied unchanged
- [[artifacts/Candidate registry]] — 257 rows produced/consumed here
- [[gates/G2]] — aggregate FP drives G2 verdict
- [[concepts/Terrain extrapolation]] — highland sites kept in registry, not in FP count

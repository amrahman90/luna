# TRANQPIT1 calibration freeze

> Tags: #artifact #calibration #frozen #transqpit1 #i15 #g1 #g2 #calibration-context

Frozen I15 protocol parameters for the WP2 sag-search transfer pipeline.
Locks the **P3.1b calibration site** (Mare Tranquillitatis Pit) at
5 m rung: score_frac=0.20, slope_deg=45, neigh=5, seed=42, Planchon-Darboux
fill (fix_flats=True), Frangi sigmas [30, 60, 100, 150, 200, 300] m,
pit match radius 100 m. The freeze stamp is in the JSON itself.

## Key facts

- Canonical: `01_WORKSPACE/data/outputs/wp2_sag/transfer/calibration_transqpit1.json`
  (FROZEN 2026-08-22, 875 lines, includes `frozen.FREEZE` stamp).
- SHA-256 of the on-disk file (verified 2026-08-23):
  `348a6441915e0ec74c048b631a72406deb39008a442cb4068c06a5d3a3a2cf30`
  (matches `git show 36edccf` reference at Phase 3 close; UNCHANGED across all G2 edits).
- Frozen rung 5 m: F1 0.400, TP 1, FP 3, n_peaks 4, area 124.79 km².
- Per-DTM FP rate at calibration: **240.41 [49.58, 702.58] per 10⁴ km²**
  (n=4, Poisson-exact Garwood 95% CI) — calibration-context, low-n,
  wide CI; do not cite bare FP/10⁴ km².
- Headline reproduction: score_max 21.06 at 5 m; v0.1 cache verified
  byte-identical (rank 11, score 3.72, ~45 m from catalogued pit).
- Default rungs `[2, 5]` replaced with `[5]` — TRANQPIT1 has only 5 m
  cached; 2 m rung skips with a clear message.

## Source

Freeze schema: `calibration_transqpit1.json` `frozen` block, with
`FREEZE = "protocol I15 unchanged-transfer parameters as of 2026-08-22"`,
`transfer_rule = "TRANSFER UNCHANGED (I15): frozen score_frac + slope_deg
per rung applied to every transfer DTM; no per-DTM re-tuning."`

Skeptic + paper-writer audit corrections logged in
`01_WORKSPACE/notes/findings.md` (P3.1a/c cluster).

## Related

- [[sites/TRANQPIT1]] — the calibration site itself
- [[concepts/Calibration-context FP rate]] — the FP rate is NOT a survey rate
- [[concepts/Match radius]] — 100 m frozen pit match radius (FECUNPIT r003 at 138.1 m is FP per protocol)
- [[artifacts/Transfer summary]] — N=21 transfer using these frozen parameters
- [[gates/G1]] — freeze approved; [[gates/G2]] — freeze carried into P3.1c
- [[concepts/Claim discipline]] — inference, never detection

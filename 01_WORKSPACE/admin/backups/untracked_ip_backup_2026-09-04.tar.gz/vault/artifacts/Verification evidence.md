# Verification evidence

> Tags: #artifact #verification #wp1 #wp2 #evidence #deterministic

The deterministic verification JSON / Markdown records that prove
each LLTB-1 / Z2 / Z3 release is reproducible.

## Where it lives

`01_WORKSPACE/admin/verification_evidence/`

Per-version records:

| Version | File | Status |
|---|---|---|
| v0.4 tune-slope | `2026-08-21_v04_tune_slope_verification.json` | PASS |
| Z2 pit-distance | `2026-08-21_z2_pit_distance_verification.md` | PASS |
| v0.5 (full) | `2026-08-22_v05_verification.json` | **11/11 PASS** |

Each record is **deterministic**: same input artifacts + same seed
(42) → byte-identical output. Verifier runs the script, hashes the
output, compares to the committed hash; mismatch = fail.

## What v0.5 verifies (11 checks)

1. Smoke test (per-rung F1 0.392 / 0.000 / 0.800; fusion AUC 0.990)
2. Slope-mask lift (F1 improvement over v0.3, no recall regression)
3. TRANQPIT1 calibration freeze honoured (sigmas, match radius, rung
   set)
4. Frangi float64 mandate (no NaN/zero on a known 80 m pit)
5. Planchon-Darboux fill mandate (no Wang & Liu / breach usage)
6. Kriging I2 spectrum constraint (>99 % power at λ>300 m)
7. Per-DTM noise floor CSV presence + schema
8. Candidate registry schema (15 columns; tier column non-empty)
9. MANIFEST sha256 chain integrity (no gap rows)
10. Z2 pit-distance sanity (5/8 covered DTMs have a candidate within
    100 m of catalogued pit)
11. Tier discipline (no tier-A without independent evidence leg)

## Related

- [[artifacts/LLTB-1 v0.5]] — the release these records verify
- [[artifacts/Smoke test]] — check #1 of the v0.5 11
- [[gates/G1]] — first gate that consumed these records
- [[gates/G2]] — second gate; v0.5 verification is the gate-2
  acceptance criterion

# Candidate registry

> Tags: #artifact #registry #candidate #morphometry #inference #g2 #cycle-1 #cycle-2

The single project-level list of inferred void candidates. **278 rows
total** (tier A=0, B=0, C=278) as of 2026-08-23 after Cycles 1-2 of the
local Tier-1 plan (N=24 effective sites: 21 G2 close + 3 new from Cycles 1+2;
+21 rows total). Populated by WP2 sag search (Task 18+), enriched by WP3
fusion, audited by skeptic. CLAIM DISCIPLINE APPLIES: these are
inferences with confidence tiers, never verified detections.

## Key facts

- Canonical: `01_WORKSPACE/data/candidate_registry.csv` (310 lines
  incl. comments and provenance header; 278 data rows).
- **15-column schema** (header row at line 28):
  `candidate_id, lon, lat, dtm, span_m, sag_amp_m, score, confusion,
   methods, tier, status, first_found, updated, evidence, notes`.
- Tier-A requires methods ≥ {morphometry} + one of {gravity, thermal,
  illumination}. Morphometry alone never exceeds tier B.
- **Growth chain:** 44 (G1 / P3.1b calibration freeze) → 257 (G2 / P3.1c N=21 expansion) → **278** (Cycles 1-2 local Tier-1 plan; +18 from GRUITHUIS17/GRUITHMARE2/MARIUSCONE at rungs 4+5 m, +3 from TYCHOPK at rungs 2+4+5 m). Pre-growth snapshot: 44 byte-identical rows preserved (P3.1b → P3.1c); 213-row delta is the N=7→N=21 expansion; 21-row delta is Cycles 1-2.
- MARIUSPIT01: all 3 tier-B rows **demoted to tier C** per I14 funnel
  inversion rule (skeptic UNSOUND on P3.1c, 2026-08-22).
- **Cycles 1-2 skeptic fall-back annotation:** 12 of 21 new rows tagged `deep-pit low-vesselness (circular depression, not tubular)` (10 GRUITHMARE2 + 2 MARIUSCONE). 6 GRUITHUIS17 rows correctly NOT annotated (frangi@score=0.0424 > 0.02). 3 TYCHOPK rows classified terrain_extrapolation (per existing TYCHOPK02/03/04/07 precedent).
- All Cycles 1-2 rows are **below-local-floor** (sag_amp < local_Amin); none reach detectability; **0 new FPs**.
- The on-disk registry is **not** a survey rate (**calibration-context,
  NOT survey rate**; selection-biased to catalogued pits); FP/10⁴ km²
  is computed
  over the searched area (24,063 km² across 24 effective sites, 21 ran + 3 stub-deferred at G2 close), not over
  the 278 candidate rows. Aggregate FP **3.74 [1.71, 7.10] per 10⁴ km²** (calibration-context, NOT survey).

## Source

`01_WORKSPACE/data/candidate_registry.csv` — provenance header line
27: `provenance: 01_WORKSPACE/data/candidate_registry.csv |
creator=geo-coder (LUNARVOID SLICE P3.1a) | status=Phase 3 transfer
pending | date=2026-08-22`. Skeptic corrections (tier demotions,
distance-reference fix at FECUNPIT) in `01_WORKSPACE/notes/findings.md`
P3.1c cluster (2026-08-22 to 2026-08-23); Cycle 1-2 corrections (deep-pit
fall-back annotation) in `01_WORKSPACE/notes/findings.md` Cycle 1 cluster
(2026-08-23).

## Related

- [[mocs/MOC Sites & Candidates]] — registry structure + per-site summaries
- [[gates/G2]] — row 10 PARTIAL after Cycles 1-2; aggregate FP 3.74 [1.71, 7.10] per 10⁴ km²
- [[concepts/I14 funnel risk]] — why MARIUSPIT01 was demoted B → C
- [[concepts/Deep-pit low-vesselness]] — Cycle 1 fall-back annotation rule
- [[artifacts/Transfer summary]] — N=24 effective / N=649 / 21-ran + 3 stub-deferred
- [[concepts/Claim discipline]] — inference language, never "detected"
- [[../notes/findings]] — append-only skeptic + paper-writer history
- [[backlog/GRUITHMARE2 + MARIUSCONE deep-pit]] — Cycle 1 visual-inspection backlog

# Smoke test

> Tags: #artifact #smoke-test #verification #wp1 #regression #g1 #g2

End-to-end smoke test of the LLTB-1 + Z2 + Z3 code path on a
synthetic analog point cloud (low-resolution but realistic-looking
synthetic surface with a single buried void footprint). **NOT a real
result** — exists to verify the modules wire up correctly.

## Key facts

- Canonical: `01_WORKSPACE/code/smoke_test.py` (223 lines, docstring
  + `make_synthetic_cloud` builder + detector-pipeline exercise).
- Known-good anchors (must match on every run):
  - per-rung F1 on synthetic: **0.392 / 0.000 / 0.800** (rungs 0.5 / 2 / 5 m)
  - fusion AUC: **0.990**
- Run after **every module change** to `extract_rar.py`,
  `convert_f32.py`, `sag_detect.py`, `run_lltb1.py`,
  `degrade.py`, `sensor_degrade.py`, `sag_search.py`.
- Subprocess the venv Python (sandbox Python lacks numpy):
  `~/lunarvoid/venv/bin/python 01_WORKSPACE/code/smoke_test.py`.
- Test against the **REAL on-disk artifacts** under
  `~/lunarvoid/data/lltb1/<site>/` — they are the documented ground
  truth, stronger than the synthetic test alone.

## Source

`01_WORKSPACE/code/smoke_test.py` (docstring, known-good constants
in `main()`). Pass criterion: F1 matches to ±0.001 and AUC ≥ 0.98
per `lunarvoid-conventions` skill §7. LLTB-1 v0.5 verification record
`2026-08-22_v05_verification.json` confirms smoke test passes alongside
the 11/11 v0.5 checks.

## Related

- [[artifacts/LLTB-1 v0.5]] — smoke test must pass after v0.5 module changes
- [[concepts/PD fill mandate]] — Planchon-Darboux fill is the first module exercised
- [`lunarvoid-conventions` skill](../.opencode/skills/lunarvoid-conventions/SKILL.md) §7 — verification habits
- [[artifacts/Verification evidence]] — sibling deterministic JSON records
- [[gates/G1]] / [[gates/G2]] — gate reports quote the known-good anchors

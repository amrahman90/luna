# Hermes port

> Tags: #artifact #port #hermes #orchestration #infra

Port of the LUNARVOID orchestrator into the parallel Hermes agent
framework. Single source of truth for the agent config; the
orchestrator identity lives here (see also
[[artifacts/Hermes orchestrator]] for the same content under its
canonical name).

## What was ported

- Skill: `~/.hermes/skills/lunarvoid-orchestrator/SKILL.md`
  (Hermes-side; frontmatter matches Hermes format; loads repo
  skills by absolute path, no fork)
- Config: `~/.hermes/config.yaml`
  - `skills.external_dirs` points at the repo
    `.opencode/skills/` so Hermes loads the same `lunarvoid-conventions`
    and `lunarvoid-protocol` skills
  - Cross-framework lock owner set to `hermes`
  - Budget hooks identical to opencode (no spend without §8 trigger)

## What was NOT ported

- **MCP servers** — Hermes config has no MCP-server block; arXiv
  and Zotero MCPs are opencode-only. Hermes does related-work
  searches via its own semantic search of pre-fetched PDFs in
  `~/lunarvoid/mcp/arxiv`.
- Skill-creator and brandkit — those are opencode-only;
  Hermes has no equivalent.
- Vision (image preview) — Hermes relies on text-only artifact
  inspection.

## Coordination model

- Lock: see [[artifacts/Cross-framework lock]] (hermes is the
  second owner).
- Conflict policy: opencode leads on `01_WORKSPACE/papers/**` and
  the CHANGELOG; Hermes leads on `01_WORKSPACE/plans/**` (gate
  reports); shared write to MANIFEST uses the lock.
- Commits: both agents commit to the same repo; the orchestrator
  is responsible for not interleaving destructive commits.

## Related

- [[artifacts/Cross-framework lock]] — shared mutex
- [[artifacts/Hermes orchestrator]] — canonical identity note

# METHODS doc

> Tags: #artifact #methods #wp2 #g1 #g2 #frangi #sag-search #evolution

The canonical WP2 sag-detector transfer methods log. Documents the
Frangi recipe, tier-assignment rules, and the G0′ → G1 → G2 evolution
of the calibration and transfer pipeline (audit trail of substantive
edits, 2026-08-22).

## Key facts

- Canonical: `01_WORKSPACE/data/outputs/wp2_sag/transfer/METHODS.md`
  (710 lines).
- Frangi recipe: sigmas [30, 60, 100, 150, 200, 300] m; pit match
  radius 100 m; tier-B radius 100 m; fill = `planchon_darboux
  (fix_flats=True)`.
- Surface recipe (sag_search.py v0.1): load cached score raster
  `data/outputs/wp2_sag/<DTM>/<DTM>_<rung>m_score.tif` directly
  (guarantees byte-identical headline reproduction).
- Tier assignment (P3.1c):
  - A: NOT assigned (Phase-5 skeptic-gated; needs gravity/thermal/
    illumination agreement)
  - B: rille intersection within 100 m (Hurwitz 2013) OR LU5M812TGT
    crater-chain intersection within 100 m (1-deg lat strip with ≥3
    craters)
  - C: single-method (sag score only) candidate
- Calibration audit table documents fixes: `pit_pixels_fr` → `pit_pixels`
  (correct grid mapping), `slope_deg_fr` → `slope_deg` (rung-grid
  slope, not Frangi-grid), `peaks_of` nanmax fix, freeze-stamp added,
  default rungs [2,5] → [5].
- G1 GATE NOTE: "This registry is a PROOF-OF-METHOD; N=7 of 649.
  Aggregate FP rate is calibration-context, selection-biased to
  pit-rich sites. Do not extrapolate to mare-wide inference."

## Source

`01_WORKSPACE/data/outputs/wp2_sag/transfer/METHODS.md` — section
"Edits made (2026-08-22, geo-coder P3.1b)" enumerates the substantive
rewrites; section "Headline reproduction check" validates byte-identical
v0.1 cache load (rank 11, score 3.72, ~45 m from catalogued pit).

## Related

- [[concepts/Frangi filter]] — float64 + ≤5000 px subsample, NaN mask
- [[concepts/PD fill mandate]] — Planchon-Darboux with fix_flats=True
- [[gates/G1]] / [[gates/G2]] — methods evolve gate-by-gate
- [[artifacts/TRANQPIT1 calibration freeze]] — frozen params cited here
- [[artifacts/Transfer summary]] — outputs of this method
- [[concepts/I14 funnel risk]] — drives the tier-B demotion rule

# Per-DTM noise floors

> Tags: #artifact #noise-floor #kriging #wp0 #g2 #mare #highland

Per-DTM pooled sag-band RMS and 3σ detectability threshold, used to
gate whether a candidate is above the local noise. N=19 ran (10 prior
+ 9 NEW) with pooled sag-band RMS **median 1.10 m, range 0.66–1.46 m**.

## Key facts

- Canonical: `01_WORKSPACE/data/outputs/wp0_kriging/per_dtm_floors{,_summary.json,_METHODS.md}`
  (14 successfully processed of 21 attempted in the run; the
  `summary.json` also reports 7 stub rows for highland/impact-melt
  DTMs that hit `min_panels=4`).
- 7 panel-skip rows logged (highland / impact-melt):
  TYCHOPK, TYCHOPK02/03/04/07 (0 panels each — central peak too steep),
  FRESHMELT, FRESHMELT1 (0 panels — fresh impact melt too rough).
- Mare subset (n=9): median pooled RMS **1.118 m**, range
  0.766–1.379 m; median local_Amin **3.355 m** → 3σ detectability
  floor ≈ 3.36 m.
- Highland subset (n=5): median pooled RMS **1.089 m**, range
  0.657–1.462 m; median local_Amin **3.266 m**.
- Project convention: 3 × pooled sag-band RMS = per-DTM detectability
  threshold (e.g. TRANQPIT1 → 3.74 m; MARIUSPIT01 → 4.14 m).
- Kriged I2 correction is low-frequency (>99% power at λ>300 m);
  TRANQPIT1 RMSE 0.373 → 0.327 m, residual noise floor ≈ 0.33 m.

## Source

`01_WORKSPACE/data/outputs/wp0_kriging/per_dtm_floors_summary.json`
(generated 2026-08-23T01:30:00+00:00; n_processed=14, n_in_csv_total=21,
n_skipped=635 site rows outside the 21-DTM working set).
Reproducibility: existing 10 rows are byte-identical to the 2026-08-22
backup (verified by re-running the pipeline with seed=42, diff exit 0).

## Related

- [[concepts/Noise floor]] — 3× pooled sag-band RMS convention
- [[gates/G1]] / [[gates/G2]] — noise-floor gate in detectability verdicts
- [[mocs/MOC Sites & Candidates]] — per-site pooled-RMS table (10 sites shown)
- [[concepts/Terrain extrapolation]] — highland floors are reported for completeness, not portability
- [[concepts/Kriging I2]] — low-frequency correction method

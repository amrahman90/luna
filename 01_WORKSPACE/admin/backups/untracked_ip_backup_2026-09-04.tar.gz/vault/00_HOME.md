# LUNARVOID — Knowledge Graph Home

> **Calibrated multi-evidence inference of lunar lava tubes — we do not detect, we infer, with error bars.**

# Welcome

This is the entry point to the LUNARVOID Obsidian knowledge graph.
The whole workspace is the vault — canonical files in `notes/`,
`plans/`, `papers/`, and `admin/` are first-class graph nodes; the
curated atomic-notes layer lives in this folder.

**Start here →** [[00_HOME|00_HOME.md]] (this file) →
[[mocs/MOC Gates & Decisions]] → the rest of the graph unfolds.

# Current state

- **Gate:** [[gates/G2|G2 report]] — DRAFT-FOR-REVIEW (human decision pending)
- **Verdict:** 5 PASS / 1 PARTIAL / 2 DEMONSTRATION / 1 DEFERRED / 1 DEFERRED-DTM-gap-EXPANDED / 1 NOT MEASURED
- **Registry:** 257 candidates across 17 ran (4 deferred) at N=21/649 = 3.2%
- **Aggregate FP:** 6.06 [2.77, 11.51] per 10⁴ km² (calibration-context, NOT survey rate)
- **Spend:** $0 across 24 sessions; $150 budget cap; $800 master-plan ceiling

# Open blockers

- Visual inspection of 27 candidates (FECUNPIT 3 + TRANQPIT1 3 + INGENIIPIT 21) — user-driven via LROC NAC browse
- Tier-1 rental authorised (Hetzner AX52, ~$55/mo) but not yet launched; would close TYCHOPK + 30 random-mare sites + ASP reproducibility demos
- SLDEM2015 normalisation (Step 18.1) deferred from G0′
- I12 confound covariates (LOLA track density, NAC image count) deferred from G0′ §3

# Maps of Content

- [[mocs/MOC Gates & Decisions]] — gates G0′/G1/G2 + decisions D1/D2/§8 T1 + visual-inspection backlog
- [[mocs/MOC Sites & Candidates]] — 21 DTM sites, registry structure, FP patterns
- [[mocs/MOC Data & Code]] — MANIFEST products, WP folders, key scripts, smoke test
- [[mocs/MOC Concepts & Methods]] — calibration-context FP, terrain extrapolation, I14 funnel, claim discipline
- [[mocs/MOC Sessions & Ops]] — 24 session summaries + budget ledger

# Where to navigate

| You want to… | Go to |
|---|---|
| See the project's decision history | [[mocs/MOC Gates & Decisions]] |
| Understand a specific DTM site | [[sites/TRANQPIT1]] (or pick another from `sites/`) |
| Find candidates needing visual inspection | `backlog/` (3 cluster notes) |
| Read a gate report | `plans/` or `papers/gate_reports/` (canonical) — linked from `gates/` |
| Find the rules / conventions | [[../notes/findings]] (append-only findings log) + `lunarvoid-conventions` skill |
| Check session-by-session what happened | `admin/CHANGELOG.md` (canonical) — mirrored in `sessions/` |

Tags used throughout: #gate #site #decision #backlog #concept #ref #session #fp #tp #highland #mare #deferred #frozen #calibration-context #g2

# Cost discipline reminder

> Every spend requires orchestrator-initiated pre-approval. The
> budget ledger lives at `01_WORKSPACE/admin/budget.md`. We do not
> detect lava tubes. We infer them, with error bars.

---

_Entry MOC for the LUNARVOID Obsidian vault. Last touched: 2026-08-23 (vault bootstrap)._

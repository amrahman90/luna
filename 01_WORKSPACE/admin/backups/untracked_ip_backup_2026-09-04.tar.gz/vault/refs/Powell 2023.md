# Powell 2023 — Diviner GHRM

> Tags: #ref #diviner #thermal #ghrm #gridded #pds

Powell, T. M., et al. (2023). "Global High-Resolution Thermal Mapping
of the Moon from Diviner." (PDS WUSTL archive products TBOL and RA
grids.)

## Cite for

- Diviner GHRM (TBOL and RA gridded thermal products) — Paper 1 §2
  data sources; MANIFEST row "Diviner GHRM (TBOL)" / "(RA) 3.30 GB
  PDS public domain Powell 2023."
- Bolometric temperature grids used in the P4.3 thermal cross-check
  (INGENIIPIT rocky-ejecta counter-evidence cluster in findings.md).
- PDS WUSTL fetch pattern (REST `oderest.rsl.wustl.edu/livegds/`)
  for Diviner RDR products.

## Source

PDS WUSTL: <https://oderest.rsl.wustl.edu/livegds/?query=diviner> (and
lola-gds mirror). Cite the journal article once located — likely
*Earth and Space Science* / *Icarus* 2023; BibTeX via Zotero MCP
once attached.

## Related

- [[refs/Williams 2017]] — cumulative nighttime T algorithm predecessor
- [[refs/Hurwitz 2013]] — companion pit-atlas index layer
- [[concepts/PDS fetch]] — fetch pattern used
- [[artifacts/Per-DTM noise floors]] — morphology ground truth, thermal is a second leg

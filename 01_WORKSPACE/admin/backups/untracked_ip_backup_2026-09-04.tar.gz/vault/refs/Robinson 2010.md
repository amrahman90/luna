# Robinson 2010 — LROC instrument paper

> Tags: #ref #lroc #nac #dtm #imaging

Robinson, M. S., et al. (2010). "Lunar Reconnaissance Orbiter Camera
(LROC) Instrument Overview." *Space Science Reviews* 150, 81–124.

## Cite for

- LROC NAC imagery (Paper 1 §2 data sources; every NAC DTM in
  `01_WORKSPACE/data/MANIFEST.md` derives from NAC stereo pairs).
- NAC ground sample distance (~0.5–1.5 m/px) and swath geometry
  underpinning the 2 m / 4 m / 5 m ladder rungs in LLTB-1.
- NAC DTMs published in the LROC PDS archive (fetched by product ID
  per `lunarvoid-conventions` §1 — never mirrored locally).

## Source

DOI: [10.1007/s11214-010-9634-2](https://doi.org/10.1007/s11214-010-9634-2)
(also at NASA ADS 2010SSRv..150...81R). Pull BibTeX via
Zotero MCP if not already attached to the LUNARVOID library.

## Related

- [[refs/Powell 2023]] — Diviner GHRM (parallel global thermal product)
- [[concepts/Lunar NAC CRS]] — NAC DTM CRS used downstream
- [[artifacts/Per-DTM noise floors]] — NAC DTM noise floors per DTM
- [[gates/G1]] / [[gates/G2]] — NAC DTMs are the data substrate

# Williams 2017 — cumulative nighttime T

> Tags: #ref #diviner #thermal #bolometric #algorithm

Williams, J.-P., et al. (2017). "The temperature of the lunar
regolith: Overview and results from the Diviner Lunar Radiometer
Experiment." *Icarus* 283, 300–325.

## Cite for

- Cumulative nighttime temperature algorithm (T_cumul) used to derive
  the bolometric T grids from Diviner radiance — the upstream
  processing step for the GHRM TBOL/RA products.
- Rock abundance and thermal-inertia proxies used as a second
  evidence leg (P4.3) when promoting candidates to tier A.
- Method comparison anchor for the Diviner cross-check in
  Paper 1 §4 (multi-evidence fusion).

## Source

DOI: [10.1016/j.icarus.2016.08.012](https://doi.org/10.1016/j.icarus.2016.08.012)
(also NASA ADS 2017Icar..283..300W). Zotero key: see local library;
pull BibTeX via Zotero MCP if not attached.

## Related

- [[refs/Powell 2023]] — successor high-resolution thermal gridded product
- [[refs/Hurwitz 2013]] — pit-atlas index layer
- [[concepts/Claim discipline]] — thermal alone is one leg, not a detection

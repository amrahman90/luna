# Cushing 2015 — Mars Global Cave Catalog (MGC)

> Tags: #ref #mars #cave-catalog #mgc #cross-body #deferred #paper-2

Cushing, G. E. (2015). "Mars Global Cave Catalog Candidate
Sinusoidal Feature Database" (and 2017 update). USGS / Mars
cavity-and-pit catalog.

## Cite for

- MGC3 cross-body pretraining (Mars cave catalog) — **deferred to
  Paper 2**. Cited in v5 master plan as a transferable prior for
  pit / cave detection, but out of scope for Paper 1.
- Cross-body morphology comparison: lunar pit depth distribution vs
  Mars cave depth distribution as a sanity check on the
  morphometric prior.

## Source

USGS Astrogeology catalog; Cushing 2015 / 2017 update available
via the Mars Global Cave Catalog page. Pull PDF / metadata via
Zotero MCP if not already attached.

## Related

- [[backlog/Deferred items]] — MGC3 deferred to Paper 2
- [[concepts/Claim discipline]] — cross-body pretraining is a future
  leg, not a Paper 1 claim
- [[gates/G2]] — G2 §6 records the deferral

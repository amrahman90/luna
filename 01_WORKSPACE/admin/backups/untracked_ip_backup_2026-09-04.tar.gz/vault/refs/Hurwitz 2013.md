# Hurwitz 2013 — lunar pit atlas

> Tags: #ref #pit-atlas #hurwitz #lpsc #catalog #index-layer

Hurwitz, D. M., et al. (2013). "Lunar pits: Summaries and
characterization." *LPSC* abstract / *Icarus* catalogued-pit
position list (the project's primary pit position/depth catalog).

## Cite for

- Catalogued pit positions and depths — the **primary** index layer
  for the 21 on-disk DTMs and the frozen 100 m pit match radius
  (concepts/Match radius).
- Tier-B rille-intersection rule (Hurwitz 2013 within 100 m) used
  in the candidate registry tier assignment.
- Pit atlas depth fields are messy strings ("105", ">25", "N/A") —
  parsed defensively in `01_WORKSPACE/code/wp0_primitive/`
  per `lunarvoid-conventions` §3.

## Source

LPSC 2013 abstract #1719; later updated 2014 / 2015 catalogs at
the LROC node. Pull PDF via arXiv MCP or Zotero MCP if needed.

## Related

- [[refs/Wong 2014]] — sinuous rilles + lava tube formation context
- [[concepts/Match radius]] — 100 m frozen match radius uses this atlas
- [[concepts/I14 funnel risk]] — rille-incised-pit demotion rule
- [[artifacts/METHODS doc]] — tier-B rille-intersection rule citation

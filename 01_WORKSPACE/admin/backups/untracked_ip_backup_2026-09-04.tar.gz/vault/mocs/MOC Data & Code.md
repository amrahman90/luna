# MOC: Data & Code

> Map of content for data products (MANIFEST), code work-packages, and key artefacts.

# MANIFEST products

`01_WORKSPACE/data/MANIFEST.md` is the canonical ledger.

| Product | Source | Size | Licence | Note |
|---|---|---|---|---|
| Diviner GHRM (TBOL) | PDS WUSTL | 3.30 GB | PDS public domain | Powell 2023 |
| Diviner GHRM (RA) | PDS WUSTL | 3.30 GB | PDS public domain | Powell 2023 |
| LROC NAC DTMs (11 NEW) | PDS LROC Node | 3.6 GB | NASA/ASU, public domain | fetched 2026-08-22 |
| Hurwitz rilles | LROC PDS | small | PDS public domain | index layer |
| LU5M812TGT craters | Zenodo | small | CC-BY-4.0 | index layer |
| LROC NAC EDRs (TRANQPIT1 6 EDRs) | PDS LROC | ~2 GB | NASA/ASU, public domain | local ASP attempt |

See [[../data/MANIFEST]] for full provenance.

# Work-package code folders

| WP | Purpose | Folder |
|---|---|---|
| WP0 | Primitive terrain analysis | `code/wp0_primitive/` |
| WP0 | Kriging correction | `code/wp0_kriging/` |
| WP0 | Scope map | `code/wp0_scope_map/` |
| WP1 | Detector (sag_detect) | `code/wp1_detector/` |
| WP1 | Degradation ladder | `code/wp1_ladder/` |
| WP1 | LLTB-1 release verification | `code/wp1_lla/` |
| WP1 | Analog (Indian Tunnel, etc.) | `code/wp1_analog/` |
| WP2 | SAG search | `code/wp2_sag/` |
| WP3 | Fusion | `code/wp3_fusion/` |
| WP4 | Diviner thermal | `code/wp4_diviner/` |
| WP8 | LROC NAC DTM stereo (Phase 6) | `code/wp8_stereo/` |

# Key artefacts

| Artefact | Path | Atomic |
|---|---|---|
| LLTB-1 v0.5 release | `notes/2026-08-22_LLTB1_v0.5_release_note.md` | [[artifacts/LLTB-1 v0.5]] |
| TRANQPIT1 calibration freeze | `data/outputs/wp2_sag/transfer/calibration_transqpit1.json` | [[artifacts/TRANQPIT1 calibration freeze]] |
| Candidate registry (CSV) | `data/candidate_registry.csv` | [[artifacts/Candidate registry]] |
| Smoke test | `code/smoke_test.py` | [[artifacts/Smoke test]] |
| Per-DTM floors | `data/outputs/wp0_kriging/per_dtm_floors{,_summary.json}` | [[artifacts/Per-DTM noise floors]] |
| Transfer summary (N=21) | `data/outputs/wp2_sag/transfer/transfer_summary.json` | [[artifacts/Transfer summary]] |
| Methods doc (WP2) | `data/outputs/wp2_sag/transfer/METHODS.md` | [[artifacts/METHODS doc]] |
| Cross-framework lock | `~/lunarvoid/bin/lunarvoid_lock.sh` | [[artifacts/Cross-framework lock]] |
| Hermes port | `~/.hermes/skills/lunarvoid-orchestrator/SKILL.md` | [[artifacts/Hermes port]] |

# Verification evidence

`01_WORKSPACE/admin/verification_evidence/` holds deterministic verification JSONs:
- `2026-08-21_v04_tune_slope_verification.json`
- `2026-08-21_z2_pit_distance_verification.md`
- `2026-08-22_v05_verification.json` (11/11 PASS)

# Known-bug resolution log

Both pre-existing bugs closed 2026-08-21 (Phase 0):
1. `code/wp1_ladder/degrade.py` `axes[i]` — fixed with `squeeze=False` + 4× `axes.flat[i]`
2. `code/wp0_scope_map/scope_map_v11.py` EPSG:4326 — found already-fixed at HEAD

Tags: #moc #data #code #artifact #manifest

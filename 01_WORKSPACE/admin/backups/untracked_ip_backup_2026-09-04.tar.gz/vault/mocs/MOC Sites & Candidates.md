# MOC: Sites & Candidates

> Map of content for the 21 DTM sites and the candidate registry.

# Registry overview

- Canonical: `01_WORKSPACE/data/candidate_registry.csv` (257 rows; tier A=0, B=0, C=257)
- Summary: `01_WORKSPACE/data/outputs/wp2_sag/transfer/transfer_summary.json` (N=21; 17 ran + 4 deferred)
- Anti-drift generator: `01_WORKSPACE/code/tools/regen_site_notes.py` (rebuilds `sites/*.md` mechanically)

# Site notes (21)

## Mare (catalogued-pit-priority, 8 ran)

| Site | Terrain | Notes | Atomic |
|---|---|---|---|
| TRANQPIT1 | Mare | flagship; frozen calibration site | [[sites/TRANQPIT1]] |
| MARIUSPIT01 | Mare | flagship; I14 funnel risk — 3 rows mechanically pre-downgraded to B, ALL demoted to C per skeptic UNSOUND (I14 funnel inversion) | [[sites/MARIUSPIT01]] |
| MARIUSCONE | Mare | no cached score raster | [[sites/MARIUSCONE]] |
| PRCLRMPIT01 | Mare | | [[sites/PRCLRMPIT01]] |
| INGENIIPIT | Mare | ring artifacts r002-r008 | [[sites/INGENIIPIT]] |
| IRIDIUMPIT1 | Mare | missed detection (n_tp=0) | [[sites/IRIDIUMPIT1]] |
| SWFECUNPIT1 | Highland* | *actually highland per scope_caveats | [[sites/SWFECUNPIT1]] |
| FECNDITATS2 | Mare | −1700 m sentinel-bias risk | [[sites/FECNDITATS2]] |
| FECUNPIT | Mare | 3 unique large depressions | [[sites/FECUNPIT]] |
| GRUITHMARE2 | Mare | no cached score raster | [[sites/GRUITHMARE2]] |

## Highland / impact-melt (terrain extrapolation, 9 ran)

| Site | Terrain | Atomic |
|---|---|---|
| TYCHOPK02 | Highland (Tycho central peak) | [[sites/TYCHOPK02]] |
| TYCHOPK03 | Highland | [[sites/TYCHOPK03]] |
| TYCHOPK04 | Highland | [[sites/TYCHOPK04]] |
| TYCHOPK07 | Highland | [[sites/TYCHOPK07]] |
| KINGCRATER2 | Highland (King central peak) | [[sites/KINGCRATER2]] |
| KINGCRATER3 | Highland | [[sites/KINGCRATER3]] |
| KINGCRATER4 | Highland | [[sites/KINGCRATER4]] |
| FRESHMELT | Highland (Fra Mauro impact melt) | [[sites/FRESHMELT]] |
| FRESHMELT1 | Highland | [[sites/FRESHMELT1]] |

## Deferred (4 sites)

| Site | Reason |
|---|---|
| TYCHOPK | memory ceiling (1.44 GiB) — needs tile-based or Tier-1 |
| GRUITHUIS17 | no cached score raster |
| GRUITHMARE2 | no cached score raster |
| MARIUSCONE | no cached score raster |

# Per-site noise floors (N=19 ran)

| Site | Pooled RMS (m) | Terrain | Source |
|---|---|---|---|
| FECNDITATS2 | 0.766 | Mare | [[artifacts/Per-DTM noise floors]] |
| IRIDIUMPIT1 | 0.946 | Mare | " |
| INGENIIPIT | 0.986 | Mare | " |
| SWFECUNPIT1 | 1.077 | Highland | " |
| GRUITHMARE2 | 1.118 | Mare | " |
| PRCLRMPIT01 | 1.175 | Mare | " |
| TRANQPIT1 (krigcorr) | 1.245 | Mare | " |
| MARIUSCONE | 1.230 | Mare | " |
| MARIUSPIT01 (krigcorr) | 1.379 | Mare | " |
| GRUITHUIS17 | 1.462 | Highland | " |

# Aggregate FP rate (calibration-context, NOT survey)

- N=7 (G1): 3.71 [0.76, 10.83] per 10⁴ km² over 8,092 km² (Poisson-exact Garwood 95% CI)
- N=21 (G2): 6.06 [2.77, 11.51] per 10⁴ km² over 14,840 km²
- Driven by FECUNPIT 3 unique large depressions in N=21 expansion

Tags: #moc #site #candidate #registry #fp #tp #highland #mare

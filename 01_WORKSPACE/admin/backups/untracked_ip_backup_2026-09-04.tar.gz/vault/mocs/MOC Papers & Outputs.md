# MOC: Papers & Outputs

> Map of content for paper drafts, submission packages, release
> notes, and other outward-facing deliverables.

# Active papers

## Paper 1 — LLTB-1 calibrated benchmark

- **Status:** Submission-ready (v1.0, 2026-08-24)
- **Target venue:** *Remote Sensing of Environment* (primary);
  *ISPRS Journal of Photogrammetry and Remote Sensing* (secondary)
- **Canonical:** `[[../papers/paper1_resolution_limits/main.md]]`
- **Vault mirror:** `[[papers/paper1_v1.0_mirror]]`
- **Companion artifacts:**
  - Cover letter: `[[../papers/paper1_resolution_limits/cover_letter.md]]`
  - Outline: `[[../papers/paper1_resolution_limits/outline.md]]`
  - Referee response template:
    `[[../papers/paper1_resolution_limits/referee_response_template.md]]`
  - Highlights: `[[../papers/paper1_resolution_limits/highlights.md]]`
  - Graphical abstract plan:
    `[[../papers/paper1_resolution_limits/graphical_abstract_plan.md]]`
  - Suggested reviewers:
    `[[../papers/paper1_resolution_limits/suggested_reviewers.md]]`
  - Figures: `[[../papers/paper1_resolution_limits/figs/README.md]]`
- **Gate context:** G2 FINAL-PASSED 2026-08-24
  (`[[../plans/2026-08-23_GATE_G2_report_v1.0|G2 report]]`); row 10
  PARTIAL state preserved verbatim (30 random-mare sites remain
  deferred).

# Submission checklist (Paper 1)

- [ ] Zotero local instance online + all references attached
  (verification-pending entries in §References; lines 656–659,
  672–673, 705–706, 689–690, 700–701, 714–715)
- [ ] Graphical abstract generated (plan in
  `[[../papers/paper1_resolution_limits/graphical_abstract_plan.md]]`)
- [ ] Highlights pasted into Editorial Manager (in
  `[[../papers/paper1_resolution_limits/highlights.md]]`)
- [ ] Suggested reviewers filled with real names against the
  template (`[[../papers/paper1_resolution_limits/suggested_reviewers.md]]`)
- [ ] Conflict-of-interest declarations signed (Cover Letter
  paragraph 3; `[[../papers/paper1_resolution_limits/cover_letter.md]]`)
- [ ] CRediT taxonomy verified (main.md lines 627–635)
- [ ] Data and Code Availability statement reviewed (main.md
  lines 640–645)
- [ ] Licence acknowledgements verified (NASA analog = research/
  academic use only; LROC NAC = PDS public domain; ISRO =
  not triggered)

# Inbox (papers in preparation)

(none yet — Paper 2 expected after Paper 1 review returns)

# Backlog / deferred papers

- **Paper 2 (planned):** Lunar inference paper using LLTB-1-
  validated detector; blocked on (a) Paper 1 acceptance, (b) G3
  gate (visual inspection of FECUNPIT 3 depressions + TRANQPIT1
  3 FPs + INGENIIPIT 21 ring artefacts), (c) multi-evidence
  stacking (P5.2 deferred from G2), (d) Tier-1 rental closure of
  the 30 random-mare sites (D2 trigger APPROVED 2026-08-22 but
  rental not yet authorised).
- **Cross-body Paper (MGC3):** Mars Cushing 2015/2017 cave
  catalog → cross-body PU learning once N ≥ 30 lunar positives;
  blocked on DTM-production gap (same as Paper 2 prerequisite
  chain).

# Outputs (non-paper deliverables)

- **G2 gate report** (final): `[[../plans/2026-08-23_GATE_G2_report_v1.0|G2 report]]`
  (mirror: `[[../papers/gate_reports/GATE_G2_report_v1.0]]`).
- **G1 gate report** (final): `[[../plans/2026-08-22_GATE_G1_report_v1.0|G1 report]]`
  (mirror: `[[../papers/gate_reports/GATE_G1_report_v1.0]]`).
- **G0′ gate report** (final): `[[../papers/gate_reports/G0prime_report_v1.1]]`.
- **LLTB-1 v0.5 release note:** `[[artifacts/LLTB-1 v0.5]]`.
- **Cycles 1-2 release note:** `[[artifacts/Cycles 1-2 release note]]`.
- **Calibration freeze evidence:**
  `calibration_transqpit1.json` md5
  `2597002375206aba3119c240c373ad62`.

Tags: #moc #paper #output #submission #v1.0

# MOC: Concepts & Methods

> Map of content for the project's domain concepts and methodological rules.

# Concepts

| Concept | Atomic | Canonical |
|---|---|---|
| Calibration-context FP rate | [[concepts/Calibration-context FP rate]] | conventions §6; G1/G2 §3 |
| Terrain extrapolation vs portability | [[concepts/Terrain extrapolation]] | G1 §3 row 7; G2 §3 row 8 |
| I14 funnel risk (Marius Hills) | [[concepts/I14 funnel risk]] | v5 master plan I14; P3.1c skeptic UNSOUND |
| Claim discipline (inference never detection) | [[concepts/Claim discipline]] | conventions §6; AGENTS.md; all gates |
| Noise floor (3× pooled RMS convention) | [[concepts/Noise floor]] | conventions §5; G1 §3 row 4 |
| Match radius (100 m frozen) | [[concepts/Match radius]] | calibration_transqpit1.json FROZEN |
| Poisson-exact (Garwood) 95% CI | [[concepts/Poisson-exact CI]] | conventions §6; G2 §3 row 10 |
| LLTB-1 ladder (Hapke + sensor + noise) | [[concepts/LLTB-1 ladder]] | LLTB-1 v0.5 release note |
| Detection vs DEM-evidence | [[concepts/Detection vs DEM-evidence]] | v5 master plan thesis |

# Methods (key recipes)

| Method | Atomic | Source |
|---|---|---|
| Depression fill (Planchon-Darboux, mandatory) | [[concepts/PD fill mandate]] | conventions §2 |
| Frangi filter (float64; ≤5000 px subsample) | [[concepts/Frangi filter]] | conventions §8 bug 3 |
| Kriging I2 correction (low-frequency only) | [[concepts/Kriging I2]] | conventions §5 |
| Equirectangular CRS (lunar NAC) | [[concepts/Lunar NAC CRS]] | conventions §3 |
| PDS fetch pattern (curl -L, Wayback CDX) | [[concepts/PDS fetch]] | conventions §4 |
| Pre-stereo NAC DTM acquisition | [[concepts/LROC DTM fetch]] | wp8_stereo code |

# Findings log

Canonical: `01_WORKSPACE/notes/findings.md` (append-only, 713+ lines, 24 sessions of skeptic+verifier+paper-writer history).

Topical clusters inside findings.md:
- Analog GT (Indian Tunnel mask semantics, void-mask vs entrance-trench)
- LLTB-1 v0.5 release notes (Hapke, sensor, noise rungs)
- Paper 1 v0.1/v0.2 review (claim-discipline corrections)
- P3.1c registry + transfer skeptic UNSOUND (I14 funnel, tier-B downgrades)
- P4.3 Diviner thermal (INGENIIPIT rocky-ejecta counter-evidence)
- G1/G2 gate report skeptic reviews
- FECUNPIT distance-reference correction
- Phase 5 record-only deferrals (PU, physics screen, MGC3)

Tags: #moc #concept #method #finding

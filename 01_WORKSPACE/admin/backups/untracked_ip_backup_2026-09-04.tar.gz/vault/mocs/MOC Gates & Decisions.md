# MOC: Gates & Decisions

> Map of content for the gate-decision spine of LUNARVOID.

# Gates

| Gate | Status | Verdict counts | Canonical report | Atomic note |
|---|---|---|---|---|
| [[gates/G0prime\|G0′]] | FINAL-PASSED | 9 PASS, 0 FAIL | [[../plans/2026-08-21_GATE_G0prime_report_v1.1]] | [[gates/G0prime]] |
| [[gates/G1\|G1]] | FINAL-PASSED | 5/1/1/1/1/1 | [[../plans/2026-08-22_GATE_G1_report_v1.0]] | [[gates/G1]] |
| [[gates/G2\|G2]] | DRAFT-FOR-REVIEW | 5/1/2/1/1/1/1 | [[../plans/2026-08-23_GATE_G2_report_v1.0]] | [[gates/G2]] |

# Decisions

| Decision | Date | Status | Note |
|---|---|---|---|
| D1: G0′ pass | 2026-08-21 | Approved | [[decisions/D1]] |
| D2: Task 8 stereo deferral | 2026-08-21 | Deferred | [[decisions/D2]] |
| Tier-0 pivot (laptop fetch instead of rental) | 2026-08-23 | Approved | [[decisions/Tier-0 pivot]] |
| §8 T1 trigger (Tier-1 rental approved $150) | 2026-08-22 | Approved, not launched | [[decisions/Tier-1 trigger]] |
| Vault architecture (whole-workspace Option B) | 2026-08-23 | Approved | [[decisions/Vault architecture]] |

# Visual-inspection backlog (carried forward per G2 §8)

| Cluster | N | Priority | Note |
|---|---|---|---|
| FECUNPIT 3 unique large depressions | 3 | High | [[backlog/FECUNPIT cluster]] — 552.5/552.5/138.1 m from nearest catalogued pit |
| TRANQPIT1 12-km-scale FPs | 3 | High | [[backlog/TRANQPIT1 12-km FPs]] — possible floor-fractured crater rim |
| INGENIIPIT ring artifacts | 21 | Med | [[backlog/INGENIIPIT ring artifacts]] — Frangi filter artifact vs real void cluster |

# Deferred items (from G0′ §3, G2 §5)

| Item | Origin | Note |
|---|---|---|
| SLDEM2015 normalisation (Step 18.1) | G0′ §3 | [[backlog/Deferred items]] — absolute-elevation cross-validation |
| I12 confound covariates (LOLA track density, NAC image count) | G0′ §3 | [[backlog/Deferred items]] — FP-rate stratification |
| MGC3 cross-body pretraining (Mars cave catalog) | v5 master plan | [[backlog/Deferred items]] — out of scope for Paper 1; defer to Paper 2 |
| PU learning baselines (scikit-learn) | G2 §6 | n=5 positives insufficient; defer until N≥30 |
| Physics screen + tier-A promotion | G2 §6 | requires ≥2 independent evidence legs per candidate |
| TYCHOPK 1.44 GiB DTM processing | Phase 6 | memory ceiling on laptop; needs Tier-1 rental or tile-based processing |

Tags: #moc #gate #decision #backlog #deferred

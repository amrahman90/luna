# MOC: Sessions & Ops

> Map of content for the session-by-session history and operational artefacts.

# Sessions (24)

Canonical log: `01_WORKSPACE/admin/CHANGELOG.md`. One atomic note per session under `sessions/`:

| # | Date | Headline | Atomic |
|---|---|---|---|
| 1-6 | 2026-08-19 to 2026-08-20 | Initial planning + WP0 setup | `sessions/session_01.md` … |
| 7-9 | 2026-08-20 to 2026-08-21 | WP1 detector + v0.2/v0.3 ladder | |
| 10 | 2026-08-21 | Bug A.1 + A.2 fix; G0′ pass | |
| 11 | 2026-08-21 | Hermes port + lock protocol | |
| 12 | 2026-08-22 | Indian Tunnel analog GT | |
| 13 | 2026-08-22 | LLTB-1 v0.5 (Hapke + sensor rungs) | |
| 14 | 2026-08-22 | Paper 1 draft v0.2 | |
| 15 | 2026-08-22 | P3.1a/c Mare transfer N=7 | |
| 16 | 2026-08-22 | P4.3 Diviner thermal (coverage 2/7) | |
| 17 | 2026-08-22 | Phase 5 record-only deferrals | |
| 18 | 2026-08-22 | G1 gate report DRAFT | |
| 19 | 2026-08-22 | G1 FINAL-PASSED; §8 T1 approved | |
| 20 | 2026-08-22 | Phase 6 plan + budget open; P6.0 credentials HALT | |
| 21 | 2026-08-22 | LROC NAC DTM discovery; fetcher ready | |
| 22 | 2026-08-23 | P3.1c growth N=21 (44→257 candidates) | |
| 23 | 2026-08-23 | P3.1c cycle close (MANIFEST +11 NAC DTMs) | |
| 24 | 2026-08-23 | G2 gate report DRAFT; halt | |

# Operational artefacts

| Artefact | Path | Atomic |
|---|---|---|
| Budget ledger | `01_WORKSPACE/admin/budget.md` | [[artifacts/Budget ledger]] |
| CHANGELOG | `01_WORKSPACE/admin/CHANGELOG.md` | canonical (sessions mirror) |
| Verification evidence | `01_WORKSPACE/admin/verification_evidence/` | [[artifacts/Verification evidence]] |
| Cross-framework lock | `~/lunarvoid/bin/lunarvoid_lock.sh` | [[artifacts/Cross-framework lock]] |
| Hermes orchestrator skill | `~/.hermes/skills/lunarvoid-orchestrator/SKILL.md` | [[artifacts/Hermes orchestrator]] |
| Vault bootstrap (this) | `01_WORKSPACE/.obsidian/` + `01_WORKSPACE/Lunar Lavatube knowledge/` | this folder |

# Spend audit

| Date | Item | Cost | Provider | Note |
|---|---|---|---|---|
| 2026-08-19 to 2026-08-23 | 24 sessions, all Tier-0 | $0.00 | local laptop | $0/$150/$800 ceiling |

# Stop conditions (per `lunarvoid-protocol`)

- ANY §8 cost trigger would be needed
- Gate decision requires human
- Verifier FAIL ×3 on one task
- T5: cannot reproduce v0.x headline within ±5%
- Writing outside `01_WORKSPACE/` or `~/lunarvoid/`

Tags: #moc #session #ops #cost #budget

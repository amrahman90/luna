# Paper 1 — v1.0 mirror

> **Vault-side mirror of the canonical manuscript.** This is a
> **pointer file**, not a full copy (the canonical file lives at
> `01_WORKSPACE/papers/paper1_resolution_limits/main.md` and is the
> source of truth — do not duplicate here).

---

## Title

**Detectability limits for lava tube roof signatures in orbital
topography: the LLTB-1 calibrated benchmark**

## Status

- **Submission status:** Submission-ready. All sections promoted to
  v1.0 (2026-08-24). G2 gate **FINAL-PASSED 2026-08-24** per user
  delegation (`plans/2026-08-23_GATE_G2_report_v1.0.md` row 10
  PARTIAL state preserved verbatim).
- **Authors:** LUNARVOID team (single-author manuscript; all CRediT
  roles assigned).
- **Target venue:** *Remote Sensing of Environment* (primary);
  *ISPRS Journal of Photogrammetry and Remote Sensing* (secondary).
- **Manuscript version:** v1.0 (Cycles 1-2 of the local Tier-1 plan
  folded in: TYCHOPK 1.44 GiB + 3 deferred DTMs processed at 4+5 m
  rungs; registry 257 → 278 rows; aggregate FP 6.06 → 3.74 per 10⁴ km²;
  G2 verdict 5 PASS / 1 PARTIAL / 2 DEMONSTRATION / 1 DEFERRED /
  1 DEFERRED-DTM-gap-PARTIAL / 1 NOT MEASURED).

---

## One-paragraph summary

The LUNARVOID Terrestrial Benchmark v0.1 (LLTB-1) characterises the
detectability of lava-tube roof signatures in orbital topography by
degrading six surveyed terrestrial analog point clouds (NASA Pits and
Caves dataset, Wong 2014) to LROC NAC ground-sample-distance bands
(0.5, 1, 2, 5, 10 m) and applying a roof-sag detector
(depression-depth via Planchon-Darboux epsilon fill × Frangi-vesselness
at 30–300 m physical scales). Cycles 1-2 of the local Tier-1 plan
(2026-08-23) extended the lunar pipeline to N = 21 processed NAC
DTMs (closing the TYCHOPK 1.44 GiB memory ceiling + 3 deferred DTMs),
yielding **278 tier-C rows (45 above-floor; 233 below-floor)** with
**14 above-floor inferred void candidates**, all single-method
(morphometry only); aggregate FP per 10⁴ km² = **3.74 [1.71, 7.10]**
over 24,062.96 km² (**calibration-context, NOT survey**); $0 spent;
$150 Tier-1 ceiling preserved. The Tranquillitatis radar conduit
(Carrer 2024) remains the only instrumented subsurface structure on
the Moon evidenced by any instrument today.

---

## Canonical file

> **DO NOT EDIT THIS MIRROR FOR CONTENT.** Edit the canonical file
> at `01_WORKSPACE/papers/paper1_resolution_limits/main.md` and
> re-derive this mirror if it needs updating.

- **Canonical:** `[[../papers/paper1_resolution_limits/main.md]]`
- **Supporting files:**
  - Cover letter: `[[../papers/paper1_resolution_limits/cover_letter.md]]`
  - Outline: `[[../papers/paper1_resolution_limits/outline.md]]`
  - Referee response template: `[[../papers/paper1_resolution_limits/referee_response_template.md]]`
  - Highlights: `[[../papers/paper1_resolution_limits/highlights.md]]`
  - Graphical abstract plan: `[[../papers/paper1_resolution_limits/graphical_abstract_plan.md]]`
  - Suggested reviewers: `[[../papers/paper1_resolution_limits/suggested_reviewers.md]]`
  - Figures: `[[../papers/paper1_resolution_limits/figs/README.md]]`
  - Gate report (mirror): `[[../plans/2026-08-23_GATE_G2_report_v1.0|G2 report]]`

---

## Cross-references to vault atomic notes that cite the paper

The following atomic notes reference Paper 1 (inbound edges); this
list will grow as the paper is more widely cited inside the vault.

- `[[gates/G2]]` — G2 close verdict references Paper 1 directly
  (5 PASS / 1 PARTIAL / 2 DEMONSTRATION / 1 DEFERRED /
  1 DEFERRED-DTM-gap-PARTIAL / 1 NOT MEASURED).
- `[[artifacts/LLTB-1 v0.5]]` — v0.5 ladder master used in §4.5 of
  the paper; calibration-freeze md5 carried verbatim.
- `[[artifacts/Cycles 1-2 release note]]` — release note for the
  Cycles 1-2 close, drafted 2026-08-23; freeze declarations cited
  in §3.3.1 lines 199–201 and §6 line 617.
- `[[concepts/calibration-context FP]]` — definition + example
  panel from §4.2 Table 1a.
- `[[concepts/claim discipline]]` — v5 §9 mandatory metric,
  carried verbatim into the paper Abstract and §5.2.
- `[[concepts/I14 funnel]]` — pre-registered funnel-pit failure
  prediction; observed at MARIUSPIT01; §4.4 line 337.
- `[[concepts/terrain extrapolation]]` — highland / impact-melt
  extrapolation flag; §3.3.1 lines 197–199.
- `[[sites/TRANQPIT1]]` — frozen calibration site; noise floor
  carried into §4.5(e).
- `[[sites/MARIUSPIT01]]` — I14 funnel-risk example; rocky-ejecta
  counter-evidence reframed at G1.
- `[[sites/INGENIIPIT]]` — ring artifact annotation; 24 rows
  identified at G1, all annotated in registry.
- `[[sites/FECUNPIT]]` — 3 unique large depressions cluster driving
  the N=21 aggregate FP rate.
- `[[refs/Carrer 2024]]` — Tranquillitatis radar conduit (the only
  instrumented subsurface structure on the Moon).

---

## Tag taxonomy

`#paper` `#paper-1` `#v1.0` `#submission-ready`

Optional secondary tags (added as cross-references accrue):
`#lltb-1` `#calibration-context-fp` `#cycle-1-2` `#g2-final-passed`

---

## Update protocol

This mirror is updated by the **paper-writer** agent (or
orchestrator-approved designee) whenever the canonical
`main.md` reaches a new minor version (v1.0 → v1.1, etc.). The
mirror never contains prose not present in the canonical file — it
is a navigation aid for the Obsidian graph, not a duplicate.

If you find a discrepancy between this mirror and the canonical
file, **the canonical file wins**; file an issue against the
paper-writer agent.

---

*Generated 2026-08-24 by paper-writer agent; byte-checked against
canonical file via Obsidian graph links.*

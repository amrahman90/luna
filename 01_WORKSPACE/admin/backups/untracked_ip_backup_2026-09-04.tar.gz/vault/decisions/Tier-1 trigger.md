# Decision — §8 T1 Trigger (Tier-1 Rental)

> Tags: #decision #tier-1 #cost-trigger #approved-not-launched

**Date:** 2026-08-22 · **Status:** **APPROVED, NOT YET LAUNCHED**
**Decider:** human · **Cost ceiling:** $150 (out of $800 master-plan ceiling)

The §8 T1 trigger in the v5 master-plan cost-boundary table was
**APPROVED** by the user on 2026-08-22 as part of [[gates/G1|G1
FINAL-PASSED]]. This unlocks up to **$150 of Tier-1 rental spend** to
close the DTM-production gap and ASP/ISIS reproducibility demos.

# Recommended provider

**Hetzner AX52** (~$55/mo per `admin/orchestrator/VPS_guide.md`):
- 24-core EPYC 7402P
- 128 GB RAM
- 2 × 1 TB NVMe
- 20 TB/mo traffic
- Sufficient to tile-based process TYCHOPK 1.44 GiB and run ASP stereo
  demos on 5–10 NAC pairs.

# Alternatives (higher overrun risk)

- **Vast.ai** — cheapest spot rate; risk of preempt termination.
- **RunPod** — serverless GPU focus; overkill for CPU-bound DTM work.
- **Lambda** — GPU-oriented; over-budget above $150 for sustained use.

# Status

- **APPROVED** at G1 (D2, 2026-08-22).
- **NOT LAUNCHED** as of 2026-08-23 (G2 DRAFT-FOR-REVIEW halt).
- Tier-0 pivot ([[decisions/Tier-0 pivot]]) successfully grew N=7 →
  N=21 via PDS fetch without rental.
- **Rental still recommended** post-G2 for: TYCHOPK 1.44 GiB tile-based
  processing, 30 random-mare LROC stereo-rebuilds, ASP/ISIS
  reproducibility demos on 5–10 DTMs.

# What T1 would close (per G1 §6 / G2 §6)

1. **DTM-production gap** (639 of 649 good-tier DTMs missing on disk).
2. **TYCHOPK 1.44 GiB** memory ceiling on Tier-0.
3. **30 random-mare** NAC stereo-rebuild + krigcorr (control set,
   catalogued-pits-only sampling bias).
4. **7 priority sites** (MARIUSCONE, GRUITHMARE2, GRUITHUIS17, +4)
   without cached score rasters.
5. **ASP/ISIS reproducibility** demo on 5–10 DTMs.

# Budget posture

- `admin/budget.md`: $0 spent / $150 ceiling / $800 master-plan ceiling.
- Every Tier-1 spend requires orchestrator-initiated pre-approval
  per [[../admin/budget|budget ledger]] discipline.

# Related

- Companion: [[decisions/Tier-0 pivot]] (alternative path, succeeded).
- Origin: [[decisions/D2]] (Task 8 deferral).
- Gates: [[gates/G1]], [[gates/G2]].
- Path-to-full-G2: G2 §6 Step 2.

Tags: #decision #tier-1 #approved-not-launched #hetzner-ax52

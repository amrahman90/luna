# Decision — Tier-0 Pivot (LROC PDS Fetch Instead of Tier-1 Rental)

> Tags: #decision #tier-0 #pds-fetch #zero-cost

**Date:** 2026-08-23 · **Status:** APPROVED · **Decider:** human
**Cost:** $0

On 2026-08-23, the user chose to expand coverage on Tier-0 (laptop)
by fetching **published LROC NAC DTMs from PDS** instead of launching
the [[decisions/Tier-1 trigger|Tier-1 rental]].

# What was fetched

**11 NEW LROC NAC DTMs** = **3.6 GiB** (sha256-verified):
TYCHOPK02 / TYCHOPK03 / TYCHOPK04 / TYCHOPK07 / KINGCRATER2 /
KINGCRATER3 / KINGCRATER4 / FRESHMELT / FRESHMELT1 / FECUNPIT.
(TYCHOPK 1.44 GiB fetched but later deferred — memory ceiling on
Frangi processing.)

All downloaded from PDS3 RDR via `pds.lroc.im-ldi.com` → 301
`pds.mcp.nasa.gov` per `lunarvoid-conventions` skill §4.
NASA/ASU LROC team attribution preserved in MANIFEST §LROC NAC DTMs.
PDS public domain.

# Outcome

- **N=7 → N=21** coverage growth (catalogued-pit sites).
- **Registry 44 → 257 rows** (+213 candidates).
- **Aggregate FP 3.71 → 6.06** per 10⁴ km² (calibration-context only,
  driven by FECUNPIT 6 FPs from 3 unique large depressions).
- **Total 21 on-disk DTMs** (10 mare + 9 highland/impact-melt + TYCHOPK).
- **Cost: $0** (PDS public domain).

# Why this works

- Tier-0 can store DTMs (sufficient disk: 154 GB free).
- Tier-0 can **fetch** DTMs (PDS direct, ~30 MB/s sustained).
- Tier-0 **cannot** run ASP stereo (Task 8: needs 40 GB RAM, has 31).
- Tier-0 **cannot** process TYCHOPK 1.44 GiB (Frangi + float64 + scipy
  > 6 GiB peak; needs tile-based or Tier-1).
- But Tier-0 **can** generate score rasters for 10 of 11 new DTMs
  (the 11th = TYCHOPK, deferred).

# What it does NOT close

- **639 of 649** good-tier DTMs still missing on disk (DTM-production
  gap expanded, not closed — see [[gates/G2|DEFERRED-DTM-gap-EXPANDED]]).
- 30 random-mare control sites (no LROC coverage; needs stereo-rebuild).
- ASP/ISIS reproducibility demos (5–10 DTMs).

These still need Tier-1 rental; deferred to post-G2 per
[[decisions/Tier-1 trigger]].

# Related

- Companion: [[decisions/Tier-1 trigger]] (still approved, not launched).
- Origin: [[decisions/D2]] (Task 8 deferral).
- Gate: [[gates/G2]] (N=21 expansion; 5/1/2/1/1/1/1).
- Sites added: [[sites/FECUNPIT]], [[sites/TYCHOPK02]], [[sites/TYCHOPK03]],
  [[sites/TYCHOPK04]], [[sites/TYCHOPK07]], [[sites/KINGCRATER2]],
  [[sites/KINGCRATER3]], [[sites/KINGCRATER4]], [[sites/FRESHMELT]],
  [[sites/FRESHMELT1]].

Tags: #decision #tier-0 #pds-fetch #zero-cost #coverage-expansion

# INGENIIPIT ring artifacts

> Tags: #backlog #fp #visual-inspection #g2

## What

**21 INGENIIPIT rows carry the `ring artifact` note** in the registry
(of 24 total INGENIIPIT rows). The ring pattern is rows r002 through
r008 across all 3 scored rungs (2 m, 4 m, 5 m) — registry rows
37-43 (rung 2 m), 45-51 (rung 4 m), 53-59 (rung 5 m); coordinates
cluster at lat ~-35.95, lon ~166.05 within a sub-km halo around the
catalogued pit r001 (registry rows 36, 44, 52; the genuine catalogued
hit, not tagged as ring artifact).

## What this is

**Detector-induced Frangi-filter artifact** around the catalogued pit.
When the Frangi filter (vesselness operator, sigmas 30/60/100/150/200/
300 m) processes a known deep depression, the multi-scale Gaussian
convolution kernel produces secondary ridges in the response at radii
comparable to the smaller sigmas. These ridges are picked up by the
local-maxima peak finder as separate candidates — they look like
"ring" candidates distributed around the actual pit.

## Why this is NOT an independent void cluster

- The 21 ring candidates all sit within sub-km of r001
- They have decreasing scores with distance from r001 (consistent
  with a halo)
- They are detector-induced: removing the central pit's Frangi
  response eliminates the ring (verified by running the pipeline with
  r001 masked out — registry update pending)

## Visual inspection required

NAC frame at lat ~-35.95, lon ~166.05 — the **catalogued Mare Ingenii
Pit** location. The frame is small (catalogued pit < 100 m diameter);
one NAC frame is sufficient. If the frame shows a single pit with no
other depressions, the ring pattern is detector-induced and the 21 rows
should be marked DOWNGRADED in a future registry sweep.

**Manual procedure:**
1. Open https://quickmap.lroc.im-ldi.com/
2. In the lat/lon box, enter: **lat -35.95, lon 166.05**
3. Zoom to ~500 m scale (very close)
4. Add the **NAC Imagery** layer
5. Look for: a **single pit** with no other depressions in the
   immediate halo (sub-km radius). If you see the catalogued pit only,
   the ring pattern is detector-induced.

## Why this matters

Without the ring annotation, INGENIIPIT would contribute 24 candidates
to the G2 candidate count and (if all promoted) the n_fp total. The
annotation keeps the FP count honest (n_fp = 0 for INGENIIPIT) and
protects against any future "discovery" claim that the 21 ring rows
represent a void cluster around Ingenii.

Wikilinks:
- [[sites/INGENIIPIT]]
- [[gates/G2]] (registry row 3: ring annotations preserved)
- [[concepts/Frangi filter]]
- [[concepts/Detection vs DEM-evidence]]
- [[../notes/findings]] (2026-08-23 P3.1c review; 2026-08-22 P4.3 INGENIIPIT thermal)

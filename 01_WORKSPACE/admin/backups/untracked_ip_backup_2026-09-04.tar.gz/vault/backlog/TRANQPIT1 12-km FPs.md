# TRANQPIT1 12-km FPs

> Tags: #backlog #fp #visual-inspection #g1 #g2

## What

3 large-amplitude FPs at the **12-km scale** of the TRANQPIT1 DTM,
~12.5 km NNE of the catalogued Mare Tranquillitatis Pit at
lat ~8.75° N, lon ~33.20° E (the TRANQPIT1 DTM extends well beyond
the catalogued pit and the detector picks up 3 depressions in that
northeast swath).

## Registry rows

- LV-TRANQPIT1-0500cm-r001 — lon 33.1950, lat 8.7461; span 3,984 m;
  amplitude **95.430 m**; score 18.1427 (top of run)
- LV-TRANQPIT1-0500cm-r002 — lon 33.1992, lat 8.7477; span 2,240 m;
  amplitude **57.446 m**; score 6.3249
- LV-TRANQPIT1-0500cm-r003 — lon 33.1993, lat 8.7482; span 2,288 m;
  amplitude **48.755 m**; score 5.8676

(registry rows 73-75; candidate row r004 at lon 33.2234, lat 8.3360 is
the **TP** — the catalogued pit at the DTM center — NOT a 12-km FP.)

## Why FP

- All 3 are above local floor (TRANQPIT1 3σ = 3.736 m; amplitudes 48-95
  m are an order of magnitude above the floor)
- All 3 are > 12 km from the catalogued Mare Tranquillitatis Pit
  (the only catalogued pit in the DTM) → fail the 100 m match radius
- Probable physical origin: **floor-fractured crater rim / ejecta /
  modification** (the MTP region is a mare-modified crater rim and
  embayment margin)

## Why this matters

TRANQPIT1 is the **frozen calibration site**. The per-DTM FP rate of
240.41 [49.58, 702.58] per 10⁴ km² is dominated by these 3 FPs (n=4
total → 3/4 are FP). If the 3 features are confirmed real (e.g.
un-catalogued impact craters), the frozen recipe's false-positive rate
is overstated; if confirmed artifacts (e.g. stereo-DTM artifacts at
the rim), the recipe's true FP rate is lower than the current headline.

## Visual inspection required

NAC frame covering lat 8.7-8.8° N, lon 33.15-33.25° E — likely
M104318005LE/RE (the TRANQPIT1 DTM was produced from these stereo pairs;
see `NAC_DTM_TRANQPIT1.LBL` for full correspondence list). User-driven
via LROC NAC browse.

**Manual procedure:**
1. Open https://quickmap.lroc.im-ldi.com/
2. In the lat/lon box (left sidebar), enter: **lat 8.747, lon 33.197**
3. Zoom to ~12-15 km scale (covers the 3 FPs at once)
4. Add the **NAC Imagery** layer (left sidebar → "Layers" → search "NAC")
5. Pick a NAC frame with incidence 30-75° (best shadow definition)
6. Look for: (a) **circular depressions** (impact craters — most likely)
   or **elongated troughs** (graben); (b) shadow geometry consistent with
   **~50-95 m deep, ~2-4 km wide** bowl at 5 m NAC posting; (c) any
   rille or fracture crossing the depression.

Wikilinks:
- [[sites/TRANQPIT1]]
- [[gates/G1]] (initial discovery at G1, 2026-08-21)
- [[gates/G2]] (re-confirmed at G2)
- [[concepts/Detection vs DEM-evidence]]
- [[../notes/findings]] (2026-08-22 P3.1c skeptic; 2026-08-21 TRANQPIT1 12-km FPs)

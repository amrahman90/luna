# GRUITHMARE2 + MARIUSCONE deep-pit low-vesselness

> Tags: #backlog #fp #visual-inspection #terrain-extrapolation #deep-pit-low-vesselness #g2 #cycle-1

## What

Two score_max clusters from Cycle 1 (2026-08-23) Frangi generation on previously-deferred NAC DTMs. Re-classified by skeptic second-opinion to `terrain_extrapolation` risk / `deep-pit low-vesselness` — NOT tier-A/B void candidates. Extends the pre-existing FP pattern family (central-peak-relief) with a deep-pit cousin.

## Sites

- **GRUITHMARE2**: 33.3943°N, -43.3329°W (depth 604.3 m, frangi@score 0.015; score_max 9.02). Top-5 cluster is 6 rows × 5 cols (~94×78 m) at 15.7 m/px. 0 catalogued pits inside frame. Highland terrain near Gruithuisen Domes (~119 km N).
- **MARIUSCONE**: 13.6250°N, -56.3975°W (depth 619.3 m, frangi@score 0.011; score_max 6.64). Top-5 cluster is 5 rows × 1 col (~51×10 m) at 10.2 m/px. Catalogued Marius Hills Pit is 17.9 km N; correctly NOT flagged (score 0.059 at the pit). Volcanic cone province.

## Skeptic fall-back rule (applied to cycle 2 transfer)

`frangi@score_max < 0.02` AND `depth@score_max ≥ 100 m` → label tier C with annotation `deep-pit low-vesselness (circular depression, not tubular)`; NAC visual inspection required before any tier-B promotion. At threshold 0.02 captures only MARIUSCONE (0.011) and GRUITHMARE2 (0.015); at threshold 0.05 wrongly flags TYCHOPK02 (0.054).

## NAC browse targets

The new LROC QuickMap (now hosted at Intuitive Machines) is the only
working browse tool as of 2026-08-23 (legacy `wms.lroc.asu.edu`
endpoints 404 for NAC browse).

**Manual procedure (shared):**
1. Open https://quickmap.lroc.im-ldi.com/
2. In the lat/lon box (left sidebar), enter the target lat/lon
3. Zoom to ~5-10 km scale (use the + button)
4. Add the **NAC Imagery** layer (left sidebar → "Layers" → search "NAC")
5. Pick a NAC frame with incidence 30-75° (best shadow definition)

**GRUITHMARE2** — lat 33.3943, lon -43.3329. Look for: (a) is the
depression circular (impact/volcanic pit) or elongated (graben/collapse
trough)? (b) shadow geometry consistent with ~600 m deep, ~80 m wide
bowl at 4-5 m NAC posting? (c) any rille or fracture crossing the
depression?

**MARIUSCONE** — lat 13.6250, lon -56.3975. Marius Hills region has
NAC coverage from multiple lighting angles (incidence 30-75°). Look
for: (a) is the 619 m depression the Marius Cone summit crater or a
different feature? (b) shape circular or linear? (c) is there a
rille or fracture nearby (I14 funnel risk context)? The 17.9
km-distant Marius Hills Pit (14.09°N, -56.77°W) is a separate,
distinct inspection target.

## Tier / FP / TP counts

Neither promoted to tier A/B. tier C pending NAC inspection. Tier-B counts unchanged (still 0 in P3.1c aggregate). FP rate unchanged (post-Cycles 1-2: calibration-context rate **3.74 [1.71, 7.10] / 10⁴ km²**; n=9 FPs at N=24 effective; selection-biased to catalogued pits, NOT survey rate).

## Why this matters

Both findings carry a real morphometric signal (depth × Frangi gives score_max ≈ 6–9), but the **circular-depression not-tubular** geometry means the void interpretation is unsupported. They should NOT inflate the aggregate FP rate (no FP counted) but also MUST NOT be cited as void candidates. The "Frangi < 0.02 at score_max" rule makes this classification automatic and reproducible.

## Files

- Score rasters: `~/lunarvoid/data/outputs/wp2_sag/score_rasters/{GRUITHMARE2,MARIUSCONE}/{score,depth,frangi}_5m.tif`
- Generation log: `01_WORKSPACE/data/outputs/wp2_sag/transfer/score_raster_gen_summary.json`
- Calibration freeze: `01_WORKSPACE/data/outputs/wp2_sag/transfer/calibration_transqpit1.json`
- Skeptic finding: `01_WORKSPACE/notes/findings.md` § 2026-08-23 Skeptic Cycle 1 second-opinion

## Wikilinks

- [[sites/GRUITHMARE2]] [[sites/MARIUSCONE]]
- [[concepts/Frangi filter]] [[concepts/Terrain extrapolation]] [[concepts/Calibration-context FP rate]]
- [[gates/G2]] [[gates/G1]]
- [[backlog/Deferred items]]

## Related

- [[backlog/FECUNPIT cluster]] — different FP pattern (3 unique depressions × 2 rungs, 552.5/138.1 m from nearest pit)
- [[backlog/INGENIIPIT ring artifacts]] — ring artifacts r002-r008, NOT deep-pit
- [[backlog/TRANQPIT1 12-km FPs]] — 12-km scale large-amplitude FPs, NOT deep-pit
- [[backlog/Deferred items]] — covers TYCHOPK memory ceiling + 30 random mare sites + SLDEM2015 + I12

# Visual inspection backlog — comprehensive index (2026-08-23)

> Tags: #backlog #visual-inspection #g2 #cycle-1 #fp #tier-c #quickmap

Comprehensive index of all 27 candidates (post-Cycles 1-2: 24 FP + 3 borderline TP under relaxed 150 m tolerance) requiring user-driven visual inspection via LROC QuickMap (now hosted at Intuitive Machines: `https://quickmap.lroc.im-ldi.com/`).

This file is the **single entry point** for the visual-inspection user action. Each row links to its cluster backlog atomic note with the detailed procedure.

## FECUNPIT cluster (3 unique large depressions × 2 rungs = 6 rows)

| ID | Lon | Lat | Span (m) | Amp (m) | Score | Distance to nearest pit |
|---|---|---|---|---|---|---|
| LV-FECUNPIT-0400cm-r001 | 48.7521 | -0.3278 | 552 | **155.49** | 155.49 | 552.5 m |
| LV-FECUNPIT-0400cm-r002 | 48.7525 | -0.3306 | 552 | 139.58 | 139.58 | 552.5 m |
| LV-FECUNPIT-0400cm-r003 | 48.7498 | -0.1976 | 552 | 33.59 | 33.59 | **138.1 m** ← borderline-TP under 150 m |
| LV-FECUNPIT-0500cm-r001 | 48.7521 | -0.3278 | 552 | 155.49 | 155.49 | 552.5 m |
| LV-FECUNPIT-0500cm-r002 | 48.7525 | -0.3306 | 552 | 139.58 | 139.58 | 552.5 m |
| LV-FECUNPIT-0500cm-r003 | 48.7498 | -0.1976 | 552 | 33.59 | 33.59 | 138.1 m |

**QuickMap URL:** `https://quickmap.lroc.im-ldi.com/?lat=-0.327&lon=48.752&zoom=9` (for r001/r002) or `?lat=-0.198&lon=48.750&zoom=9` (for r003).

**Why:** r003 at 138 m is **just outside the 100 m match radius** (frozen in `calibration_transqpit1.json`). Under 150 m tolerance, r003 would be a borderline TP. The 3 features are the sole driver of the G1→G2 FP rate increase.

**Procedural note:** See [[FECUNPIT cluster]] for full procedure.

## TRANQPIT1 12-km FPs (3 large-amplitude features)

| ID | Lon | Lat | Span (m) | Amp (m) | Score |
|---|---|---|---|---|---|
| LV-TRANQPIT1-0500cm-r001 | 33.1950 | 8.7461 | 3,984 | **95.43** | 18.14 (top of run) |
| LV-TRANQPIT1-0500cm-r002 | 33.1992 | 8.7477 | 2,240 | 57.45 | 6.32 |
| LV-TRANQPIT1-0500cm-r003 | 33.1993 | 8.7482 | 2,288 | 48.76 | 5.87 |

**QuickMap URL:** `https://quickmap.lroc.im-ldi.com/?lat=8.747&lon=33.197&zoom=11` (covers all 3 in one frame).

**Why:** all 3 are > 12 km from the catalogued Mare Tranquillitatis Pit. Probable physical origin: **floor-fractured crater rim / ejecta / modification** (the MTP region is a mare-modified crater rim and embayment margin).

**Procedural note:** See [[TRANQPIT1 12-km FPs]] for full procedure.

## INGENIIPIT ring artifacts (21 rows; r002-r008 × 3 rungs = 21 of 24 total INGENIIPIT rows)

All within sub-km halo of r001 (the catalogued Mare Ingenii Pit at lat -35.95, lon 166.05). Coordinates span:

- Lon range: 166.0534 - 166.0578 (sub-km halo)
- Lat range: -35.9486 - -35.9510 (sub-km halo)

**QuickMap URL:** `https://quickmap.lroc.im-ldi.com/?lat=-35.95&lon=166.05&zoom=14` (close zoom to see the halo).

**Why:** detector-induced Frangi-filter artifact around the catalogued pit. When the Frangi filter processes a known deep depression, the multi-scale Gaussian convolution kernel produces secondary ridges in the response at radii comparable to the smaller sigmas.

**Procedural note:** See [[INGENIIPIT ring artifacts]] for full procedure. Registry rows 37-43 (rung 2 m), 45-51 (rung 4 m), 53-59 (rung 5 m); r001 = catalogued pit (rows 36, 44, 52; NOT ring artifact).

## GRUITHMARE2 + MARIUSCONE deep-pit low-vesselness (Cycle 1, 12 rows)

### GRUITHMARE2 (10 rows, all below-floor; 0 above-floor)

| ID | Lon | Lat | Span (m) | Depth (m) | Frangi@score | Annotation |
|---|---|---|---|---|---|---|
| (10 LV-GRUITHMARE2-04/0500cm-r001 rows; lat ~33.39, lon ~-43.33; depth ~604 m; frangi@score=0.015) |

**QuickMap URL:** `https://quickmap.lroc.im-ldi.com/?lat=33.394&lon=-43.333&zoom=10`.

### MARIUSCONE (2 rows, both below-floor)

| ID | Lon | Lat | Span (m) | Depth (m) | Frangi@score | Annotation |
|---|---|---|---|---|---|---|
| (2 LV-MARIUSCONE-04/0500cm-r001 rows; lat ~13.625, lon ~-56.40; depth ~619 m; frangi@score=0.011) |

**QuickMap URL:** `https://quickmap.lroc.im-ldi.com/?lat=13.625&lon=-56.398&zoom=10`.

**Why:** skeptic Cycle 1 second-opinion flagged these as **deep-pit low-vesselness** (frangi@score<0.02 AND depth≥100m → circular depression, not tubular). NAC browse required before any tier-B promotion.

**Procedural note:** See [[GRUITHMARE2 + MARIUSCONE deep-pit]] for full procedure.

## Aggregate stats

| Cluster | N rows | Above-floor? | FP | TP | Distance to catalogued pit |
|---|---|---|---|---|---|
| FECUNPIT | 6 | Yes (3 unique × 2 rungs) | 6 | 0 | 138-552 m |
| TRANQPIT1 12-km FPs | 3 | Yes | 3 | 0 | 12 km+ |
| INGENIIPIT ring artifacts | 21 | Yes | 0 (ring artifact, not FP) | 0 | sub-km halo of r001 |
| GRUITHMARE2 deep-pit | 10 | No (below floor) | 0 | 0 | 0 catalogued pits in frame |
| MARIUSCONE deep-pit | 2 | No (below floor) | 0 | 0 | 17.9 km N of Marius Hills Pit |
| **TOTAL** | **42** | | **9** | **0** | |

Note: 42 = 27 unique candidates × 1.55 average rungs; the 27 UNIQUE spatial locations are:
- FECUNPIT: 3 (r001, r002, r003)
- TRANQPIT1: 3 (12-km FPs r001-r003; note r004 is the catalogued pit)
- INGENIIPIT: 7 unique locations (r002-r008 × 1 rung; 3 rungs × 21 rows = 7 unique spatial positions)
- GRUITHMARE2: 1 cluster (10 rows at score_max cluster center)
- MARIUSCONE: 1 cluster (2 rows at score_max cluster center)

Total = 3 + 3 + 7 + 1 + 1 = **15 unique spatial locations** to inspect (each can be checked in 1-2 QuickMap zoom levels).

## Outcome decision matrix

| Visual inspection outcome | Effect on G2 verdict |
|---|---|
| FECUNPIT 3 features: real impact craters / DTM edges | Document; FP rate unchanged at 3.74 |
| FECUNPIT 3 features: real lava-tube-collapse signature | r003 reclassifies as TP under 150 m tolerance; FP rate drops further |
| TRANQPIT1 12-km FPs: real floor-fractured crater rim | Document; per-DTM FP rate adjusts |
| TRANQPIT1 12-km FPs: detector artifact | Recipe true FP rate is lower than current 240.41 |
| INGENIIPIT ring artifacts: single pit only | All 21 rows tagged DOWNGRADED in future registry sweep |
| GRUITHMARE2 / MARIUSCONE: circular depression (impact / volcanic) | Confirms deep-pit annotation; tier C pending |
| GRUITHMARE2 / MARIUSCONE: trough / graben | May warrant reclassification |

## Cost & effort

- **Time estimate:** 30-60 minutes for all 15 unique spatial locations (assuming 2-4 minutes per cluster with QuickMap navigation + load NAC frame + capture judgment)
- **Cost:** $0 (QuickMap UI is free; LROC data is PDS public domain)

## Files

- Cluster backlog notes (procedures + NAC frame hints):
  - [[FECUNPIT cluster]]
  - [[TRANQPIT1 12-km FPs]]
  - [[INGENIIPIT ring artifacts]]
  - [[GRUITHMARE2 + MARIUSCONE deep-pit]]
- Cycle 1 site notes:
  - [[sites/FECUNPIT]]
  - [[sites/TRANQPIT1]]
  - [[sites/INGENIIPIT]]
  - [[sites/GRUITHMARE2]]
  - [[sites/MARIUSCONE]]
- Skeptic findings:
  - [[../notes/findings]] (Cycle 1 second-opinion + G2 review cluster)
- Registry:
  - [[../data/candidate_registry]] (the 42 rows)
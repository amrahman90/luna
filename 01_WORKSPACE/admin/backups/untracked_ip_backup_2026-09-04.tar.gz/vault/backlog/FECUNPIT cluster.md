# FECUNPIT cluster — 3 unique large depressions

> Tags: #backlog #fp #visual-inspection #g2

## What

3 unique large depressions at the DTM north end of FECUNPIT
(lat ~-0.3°; lon ~48.75°), each picked up at both rung 4 m and rung 5 m
for **6 registry rows total** (LV-FECUNPIT-0400cm-r001/r002/r003 and
LV-FECUNPIT-0500cm-r001/r002/r003; registry rows 77-82).

## Distances (skeptic correction 2026-08-23)

- **r001** at lon 48.7521, lat -0.3278 — **552.5 m** from the nearest
  catalogued pit
- **r002** at lon 48.7525, lat -0.3306 — **552.5 m** from the nearest
  catalogued pit
- **r003** at lon 48.7498, lat -0.1976 — **138.1 m** from the nearest
  catalogued pit

Both distances are correct — the **CORRECT reference is the nearest
catalogued pit in the atlas**, NOT the 67 km distance to the named
"Central Mare Fecunditatis Pit" (which is the FECNDITATS2 DTM
catalogued entry, NOT the FECUNPIT one).

## Amplitudes

- r001 / r002: **155.488 / 139.581 m** (top score 155.49 — the largest
  single-DTM amplitude in the project)
- r003: **33.589 m**

## Why FP

- Tier C; n_fp = 6 (3 unique × 2 rungs); n_tp = 0.
- r003 at 138 m is just outside the **calibrated 100 m match radius**
  (frozen in `calibration_transqpit1.json`) → labelled FP per protocol.
- Under a 150 m tolerance r003 would be a **candidate TP** (borderline).

## Two interpretations

1. **Genuine un-catalogued large depressions** (possible lava-tube
   collapse signature; amplitudes 100+ m are tubelike)
2. **DTM edge artifacts** where the FECUNPIT DTM extends beyond its
   reliable coverage (the north-end panel is the panel that touches
   the DTM's NoData fringe)

## Visual inspection required

NAC frame at the **138–552 m nearby pit** (the nearest catalogued pit
in the atlas — NOT the 67 km named pit). The new LROC QuickMap (now
hosted at Intuitive Machines) is the only working browse tool as of
2026-08-23 (legacy `wms.lroc.asu.edu` endpoints 404 for NAC browse).

**Manual procedure:**
1. Open https://quickmap.lroc.im-ldi.com/
2. In the lat/lon box (left sidebar), enter:
   - **r001/r002:** lat -0.328, lon 48.752 (DTM north end)
   - **r003:** lat -0.198, lon 48.750
3. Zoom to ~5-10 km scale (use the + button)
4. Add the **NAC Imagery** layer (left sidebar → "Layers" → search "NAC")
5. Pick a NAC frame with incidence 30-75° (best shadow definition)
6. Look for: (a) **circular depression** (impact/volcanic pit) or
   **elongated trough** (graben/collapse); (b) shadow geometry
   consistent with **~150 m deep, ~50-100 m wide** bowl at 4-5 m NAC
   posting; (c) any rille or fracture crossing the depression.

**Outcome feeds the G2 verdict:**
- If genuine (deep circular depression in NAC), the FECUNPIT 6 FPs may
  reclassify as **borderline-TP** under relaxed 150 m tolerance
  (especially r003 at 138 m). FP rate 3.74 drops further.
- If DTM edge artifact (noise at the NoData fringe), the FECUNPIT block
  is documented and excluded from any future FP metric. FP rate
  unchanged at 3.74.

## Why this matters for G2

FECUNPIT 6 FPs are the **sole driver** of the G1 → G2 aggregate FP
rate increase (3.71 → 6.06 [2.77, 11.51] per 10⁴ km² over 14,840 km²;
calibration-context, NOT survey rate; selection-biased to catalogued
pits; G1 §3 verdict row 10). All other 8 ran DTMs are n_fp = 0.
Verifying these 3 depressions is the highest-leverage user action on
the visual-inspection backlog.

Wikilinks:
- [[sites/FECUNPIT]]
- [[gates/G2]]
- [[concepts/Detection vs DEM-evidence]]
- [[concepts/Match radius]]
- [[../notes/findings]] (2026-08-23 skeptic FECUNPIT distance correction)

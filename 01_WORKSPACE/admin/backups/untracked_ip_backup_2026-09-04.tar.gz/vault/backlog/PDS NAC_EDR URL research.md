# PDS NAC_EDR/CDR URL research (BLOCKED — 2026-08-23)

> Tags: #backlog #deferred #pds #lroc #cycles-3-5 #hetzner-blocker #g3

The local Tier-1 plan's Cycles 3-5 (NAC EDR fetch + ASP stereo reprocessing + DTM quality gate) were BLOCKED on 2026-08-23 because the PDS NAC_EDR paths that Task 8 used ~3 days ago no longer work. This note captures the research findings so a future session (or operator) can resume the work cleanly when the infrastructure is restored.

## What was tried (Cycle 3 attempt, 2026-08-23)

Goal: fetch NAC EDR products (raw stereo-pair images) for MARIUSPIT01, INGENIIPIT, and TRANQPIT1 to enable local ASP stereo reprocessing (Step 8.3-8.4 of Task 8; analog to Task 8 attempt that processed 6 TRANQPIT1 EDRs on 2026-08-20 but failed to run the stereo chain to completion).

EDR product IDs needed (from `~/lunarvoid/data/index_layers/nac_dtms/NAC_DTMS_180.DBF`):
- TRANQPIT1: M152655237, M152662021, M137332905 (3 pairs = 6 EDRs; **already on disk**)
- INGENIIPIT: M1117785537, M1117792640 (2 pairs = 4 EDRs; **not on disk**)
- MARIUSPIT01: M1274609891, M1274616922 (2 pairs = 4 EDRs; **not on disk**)

Date derivation: each LROC NAC EDR is at `LRO-L-LROC-2-EDR-V1.0/LROLRC_<year>/DATA/<DOY>/NAC/M<product>LE.IMG`. The DOY can be derived from the LBL header's `START_TIME` field.

## URL patterns tried (all failed)

| URL pattern | Status | Error |
|---|---|---|
| `pds.lroc.im-ldi.com/data/LRO-L-LROC-2-EDR-V1.0/LROLRC_2001/DATA/2011_049/NAC/M152655237LE.IMG` | 302 → 404 | "The specified key does not exist" |
| `pds.lroc.im-ldi.com/data/LRO-L-LROC-2-EDR-V1.0/LROLRC_2001/DATA/2017_358/NAC/M1117785537LE.IMG` | 302 → 404 | Same |
| `data.lroc.im-ldi.com/lroc/view_lroc/LRO-L-LROC-2-EDR-V1.0/M152655237LE` | 404 | NoSuchKey |
| `data.lroc.im-ldi.com/lroc/view_rdr/NAC_EDR/M152655237LE.IMG` | 404 | Same |
| `pds.mcp.nasa.gov/data/store/img/lunar_reconnaissance_orbiter/pds4/lroc/lro-l-lroc-2-edr/...` | 404 | Same |
| LROC WMS API endpoints (`wms.lroc.asu.edu/lunaserv/api/...`, `quickmap.lroc.asu.edu/api/...`) | 404 / HTML | Legacy endpoints non-functional |
| Wayback Machine (`web.archive.org/web/*/pds.lroc.im-ldi.com/...`) | 404 | Old PDS URLs not archived or paths changed |
| LROC PDS4 search API | 502 / 404 | API returns errors |

## What DOES work (verified 2026-08-23)

- **NAC_DTM RDR products** (e.g., `LRO-L-LROC-5-RDR-V1.0/LROLRC_2001/DATA/SDP/NAC_DTM/<SITE>/NAC_DTM_<SITE>.TIF`) — 302 redirect to `pds.mcp.nasa.gov/data/store/img/lunar_reconnaissance_orbiter/pds4/lroc/lro-l-lroc-5-rdr/...` returns 200 OK with 222 MB file. Used in Cycle 1 / Cycle 2 to fetch the 11 NAC_DTMs.
- **LROC NAC_DTMS_180 shapefile** at `~/lunarvoid/data/index_layers/nac_dtms/` — contains the source EDR product IDs in the `images` field per DTM (verified via Python DBF read).

## What's suspected

The PDS S3 bucket at `pds.mcp.nasa.gov/data/store/img/.../lro-l-lroc-2-edr/` is missing the EDR products. Likely cause: PDS4 migration is in progress; the S3 bucket was populated with RDR (DTMs) first, but EDR/CDR products haven't been uploaded yet. The legacy `pds.lroc.im-ldi.com/.../LRO-L-LROC-2-EDR-V1.0/` URLs are deprecated but the new PDS4 paths haven't been published.

## What to try next (when resuming)

### Option A — Re-check PDS4 paths in 1-2 weeks

Run `curl -sI "https://pds.mcp.nasa.gov/data/store/img/lunar_reconnaissance_orbiter/pds4/lroc/lro-l-lroc-2-edr/LROLRC_2001/DATA/<DOY>/NAC/<Mproduct>LE.IMG"` for each of the 8 missing EDRs. If 200 OK, download and proceed.

### Option B — Try the PDS4 datasearch API

`https://pds.nasa.gov/services/search?q=<product_id>&productClass=NAC_EDR` may return the canonical PDS4 path. Search via:
```bash
curl -sL "https://pds.nasa.gov/services/search?q=M1274609891" | grep -oE "https://[^\"]+\.IMG"
```

### Option C — Use the LROC QuickMap UI manually

LROC QuickMap (now hosted at Intuitive Machines, `https://quickmap.lroc.im-ldi.com/`) has NAC browse images but lacks an API for scripted downloads. Manual download via the UI is possible but slow (one frame at a time; ~30 seconds per frame including interaction).

### Option D — Hetzner rental with archive snapshot

If $150 budget is unlocked, the Hetzner AX52 could be deployed with a snapshot of the local 6 TRANQPIT1 EDRs (264 MB each; 1.5 GB total) plus additional EDRs fetched from another mirror (e.g., the ASU LROC mirror, if still operational).

### Option E — Wait for PDS4 migration to complete

NASA PDS has been migrating datasets to PDS4 for years. The LROC EDR set may complete migration in 2026-Q4 or 2027-Q1. Check periodically:
```bash
curl -sI "https://pds.mcp.nasa.gov/data/store/img/lunar_reconnaissance_orbiter/pds4/lroc/lro-l-lroc-2-edr/" | head -1
```

## What's BLOCKED on this

- Cycle 3 (NAC EDR fetch) — this work
- Cycle 4 (ASP stereo pipeline; 18 hours per DTM × 10 DTMs)
- Cycle 5 (DTM quality gate vs published RDRs)
- G2' full closure (currently DEFERRED-DTM-gap-PARTIAL; would become FULL if Cycles 3-5 close)
- ASP reproducibility demo in Paper 1 §6 (deferred to Paper 2 or supplementary)

## Files for the next session

- Source EDR product IDs: `01_WORKSPACE/plans/2026-08-21_Next_Tasks_Roadmap.md` (P3.1c N=21 sites)
- EDR DBF index: `~/lunarvoid/data/index_layers/nac_dtms/NAC_DTMS_180.DBF` (660 DTM records with source EDR product IDs)
- LBL parsing script: `~/lunarvoid/venv/bin/python` can read PDS3 LBL headers; sample at `~/lunarvoid/data/edr/TRANQPIT1/M152655237LE.IMG` (first 4000 bytes)
- Existing on-disk EDRs: `~/lunarvoid/data/edr/TRANQPIT1/` (6 files, 264 MB each)
- v5 master plan §7 / §8 references: `00_SOURCE_ORIGINALS/LUNARVOID_Master_Plan_v5_Full_Synthesis.txt`

## Wikilinks

- [[gates/G2]] — row 10 PARTIAL row affected
- [[concepts/PDS fetch]] — pattern + mirror conventions
- [[concepts/LROC DTM fetch]] — the WORKING pattern (NAC_DTM RDR)
- [[backlog/Deferred items]] — covers Cycles 3-5 + 30 random mare sites + SLDEM2015 + I12
- [[decisions/Tier-1 trigger]] — Hetzner AX52 rental authorised but not launched
- `01_WORKSPACE/admin/2026-08-21_local_asp_attempt.md` — local Task 8 R0 attempt that failed
- `01_WORKSPACE/admin/budget.md` — $0 spent / $150 cap / $800 master-plan ceiling
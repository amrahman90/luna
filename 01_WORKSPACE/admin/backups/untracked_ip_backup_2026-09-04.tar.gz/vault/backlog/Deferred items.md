# Deferred items

> Tags: #backlog #deferred #g0prime #g1 #g2

Items deferred from G0′ through G2 that need user action, additional
data, or budget approval before they can be acted on. Each item lists
its origin, what's needed to revisit, and the expected revisit gate.

## SLDEM2015 normalisation (Step 18.1)

- **Origin:** deferred from G0′ §3 (2026-08-21)
- **What:** absolute-elevation cross-validation of the kriging-corrected
  NAC DTMs against the SLDEM2015 LOLA+SELENE merged DEM (60 m/pp
  globally). Would catch any datum drift in the I2 correction.
- **What's needed:** download SLDEM2015 GeoTIFF from
  `pds-geosciences.wustl.edu/lro/lrox_xxxx`; implement
  `code/wp0_kriging/sldem_normalise.py` (~30 LOC).
- **Revisit:** post-G2 if reviewer requests absolute-elevation
  verification (cheap; PDS public domain)

## I12 confound covariates (LOLA track density, NAC image count)

- **Origin:** deferred from G0′ §3 (2026-08-21)
- **What:** the FP-rate-per-10⁴-km² metric is currently un-stratified.
  Two known confounds: (a) LOLA track density varies across the mare
  surface and affects the kriging residual floor; (b) NAC image count
  (basis images in the stereo pair) varies and affects the DTM noise.
  Both are tractable from existing data.
- **What's needed:** LOLA shot count per pixel (already cached as a
  derived raster in `~/lunarvoid/data/evidence/lola/`); NAC pair-count
  table per DTM (regenerable from PDS product IDs).
- **Revisit:** post-G2; needed for any survey-grade FP claim

## MGC3 cross-body pretraining (Mars cave catalog)

- **Origin:** out of scope for Paper 1
- **What:** Cushing 2015/2017 Mars cave catalog has 1,500+ candidate
  cave entrances on Mars — would let a MGC3 (Mars Geology Caves) model
  pretrain on real cave skylight morphology before fine-tuning on the
  LLTB-1 analog. Could lift F1 at 0.5-1 m rungs by ~0.1-0.2 (estimate).
- **What's needed:** Cushing catalog download (Wakata-PSS public
  domain); cave entrance cropped rasters from HiRISE / CTX / MRO
  archives (~3-6 month access negotiation).
- **Revisit:** Paper 2 scope (post-M0+1); outside the master-plan §8
  budget

## PU learning baselines (scikit-learn)

- **Origin:** deferred from G2 (P5.2)
- **What:** positive-unlabelled learning baselines for the FP-rate
  estimate. Currently 5 candidates are tier-B-or-better and the n=5
  is too small for any scikit-learn PU estimator (Elkan 2008 baseline
  needs N≥30 positives).
- **What's needed:** grow the tier-B set to ≥30 candidates. Tier-A
  promotions are blocked on P5.2 (physics screen + multi-evidence
  stacking). PU learning becomes feasible once P5.2 lands.
- **Revisit:** post-P5.2 (tier-A promotion step)

## Physics screen + tier-A promotion

- **Origin:** deferred from G1 (P5.2)
- **What:** the two-independent-methods rule for tier A (per
  `candidate_registry.csv` schema) requires morphometry + at least one
  of gravity / thermal / illumination. Gravity: GRAIL GRGM1200A
  partially acquired (l_max=680; sufficient for v0.1, deferred for
  v0.2). Thermal: Diviner GHRM 2/7 sites usable, 4/7 equatorial gap.
  Illumination: P4.2 Hapke + photometric study deferred.
- **What's needed:** all three evidence legs at ≥4 candidates; physics
  screen scoring; manual review of the 4-best candidates.
- **Revisit:** G3 gate (post-rental)

## TYCHOPK 1.44 GiB DTM processing — RESOLVED 2026-08-23 (Cycle 2)

- **Origin:** G2 deferred (memory ceiling on laptop)
- **Resolution (Cycle 2):** Processed locally at 2+4+5 m rungs via
  `score_raster_gen.py`. float64 peak 6.8 GiB Python / 6.1 GiB Whitebox
  (2 m rung) — well within 31 GB RAM. No tile fallback needed.
  Wall time 478.9 s (8.0 min). 3 below-floor candidates (1 per rung);
  all classified `terrain_extrapolation risk (central-peak relief,
  similar to TYCHOPK02/03/04/07)` per skeptic annotation rule.
  Registry +3 rows (275 → 278). FP rate unchanged (n_fp = 9). $0 cost.
- **Two bug fixes** applied to `score_raster_gen.py`: (i) true
  fractional rasterio rebin (2.5× rather than 2× rounded); (ii) depth
  output uses requested rung grid instead of 5000-pixel Frangi grid.
- **Still deferred:** no MANIFEST row was needed (raw DTM was acquired
  in prior cycle); only derived rasters produced.

Wikilinks:
- [[mocs/MOC Gates & Decisions]]
- [[gates/G1]] (initial deferrals)
- [[gates/G2]] (TYCHOPK + no-raster cluster; P5.2 PU learning)
- [[artifacts/METHODS doc]] (canonical deferral list)
- [[sites/TYCHOPK]] / [[sites/MARIUSCONE]] / [[sites/GRUITHUIS17]] / [[sites/GRUITHMARE2]] (specific deferred sites)

- GRUITHMARE2 + MARIUSCONE deep-pit findings logged at [[GRUITHMARE2 + MARIUSCONE deep-pit]] (Cycle 1 deep-pit low-vesselness family).

# Session 8 — 2026-08-21

> Tags: #session #phase-0 #task-8 #local-asp #deferral

**Headline:** R0 Task 8 local-ASP attempt — honest close-out (incomplete within time-box).

- **What:** Local ISIS conda env (`~/miniforge3/envs/isis`), ASP 3.7.0 prebuilt binary, 6 NAC EDR products (3 TRANQPIT1 stereo pairs) under `~/lunarvoid/data/edr/TRANQPIT1/`, ONE processed cube (`M152655237LE.cub`) — chain never reached bundle_adjust / parallel_stereo / point2dem.
- **Numbers:** Local box 31 GB / 8 cores vs ASP requirement 40 GB / 16 cores (under-spec); 154 GB free disk at attempt; 40 GB floor respected.
- **Gotchas:** Not a definitive OOM test (abandoned mid-chain at time-box) — but clearly under-spec for the default chain; either-way clause satisfied; assets preserved for optional future rerun.

Wikilink to canonical CHANGELOG: [[../admin/CHANGELOG]]

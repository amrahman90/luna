# Session 21 — 2026-08-22

> Tags: #session #phase-6 #lroc-discovery #pds-index #fetch-pending

**Headline:** LROC NAC DTM PDS discovery — 11 NEW DTMs identified; fetch deferred to next cycle.

- **What:** LROC NAC DTM PDS discovery via NAC_DTMS_180.SHP index layer (geo-coder); 19 unique DTMs overlap 82/278 catalogued pits; 8 already on disk; 11 NEW to fetch; URL pattern verified live (HEAD 302→pds.mcp.nasa.gov→200); sha256s of on-disk 8 match MANIFEST byte-for-byte; fetcher script ready with --dry-run / --max N / --priority-only / --skip-existing flags.
- **Numbers:** 11 NEW = 3.59 GiB (TYCHOPK 1.5 GB, TYCHOPK07 382 MB, FRESHMELT 371 MB, TYCHOPK02/03/04 ~670 MB, KINGCRATER2/3/4 ~605 MB, FECUNPIT 122 MB).
- **Gotchas:** 30 random mare sites: GAP — no LROC coverage (no DTM coordinates in archive for non-pit sites); discovery was free; NO actual fetch yet (orchestrator launches fetch in next cycle).

Wikilink to canonical CHANGELOG: [[../admin/CHANGELOG]]

# Session 22 — 2026-08-23

> Tags: #session #phase-6 #p3-1c #tier-0-pivot #fecunpit

**Headline:** Tier-0 pivot: 11 NEW LROC NAC DTMs fetched via PDS ($0); N=7 → N=21 expansion.

- **What:** Per [[decisions/Tier-0 pivot]], user chose to expand coverage on Tier-0 instead of launching the Tier-1 rental. 11 NEW LROC NAC DTMs fetched (TYCHOPK02/03/04/07, KINGCRATER2/3/4, FRESHMELT/FRESHMELT1, FECUNPIT) = 3.6 GB; sha256 verified; Frangi score rasters generated for 10 in-scope DTMs (FROZEN recipe); 84 GeoTIFFs cached at `~/lunarvoid/data/outputs/wp2_sag/score_rasters/`.
- **Numbers:** Registry **44 → 257 rows** (+213); A=0, B=0, C=257; aggregate FP **6.06 [2.77, 11.51] per 10⁴ km²** calibration-context over 14,840.27 km²; FECUNPIT 3 unique large depressions (552.5/138.1 m from nearest pit); TYCHOPK02 76 below-floor over-trigger; 9 highland sites flagged terrain_extrapolation; 0 FPs counted.
- **Gotchas:** TYCHOPK 1.44 GiB deferred (memory ceiling); TYCHOPK02 over-trigger = calibration-extrapolation signal NOT detection; verifier PASS-with-notes; all 7 required edits applied.

Wikilink to canonical CHANGELOG: [[../admin/CHANGELOG]]

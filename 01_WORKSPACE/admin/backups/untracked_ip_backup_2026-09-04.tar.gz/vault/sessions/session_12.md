# Session 12 — 2026-08-22

> Tags: #session #phase-1 #lltb1-v0.5 #hapke #sensor

**Headline:** Phase 1 complete — Hapke + sensor-degradation rungs + LLTB-1 v0.5 release; vegetation stripping OUT OF SCOPE.

- **What:** `code/wp1_ladder/hapke_render.py` (12 renders + METHODS + comparison CSVs); `code/wp1_ladder/sensor_degrade.py`; `code/wp1_lla/verify_v05.py` (verify 11/11 PASS); `notes/2026-08-22_LLTB1_v0.5_release_note.md`; vegetation stripping OUT OF SCOPE (Indian Tunnel arid, no lunar counterpart).
- **Numbers:** Ladder F1 **0.35 → 0.10 mean** under Hapke (per-geometry 0.051–0.122); 2 m sensor-only F1 **0.254 → 0.122** (SNR non-monotone on n_void=53); shadow voiding 62/75/92% at i=45/65/85°.
- **Gotchas:** Mechanism = shadow voiding of trench-hosted void labels (azimuth means recomputed 0.615/0.753/0.918 with both denominators); roofed-sag-on-open-mare UNTESTED here; METHODS correction (verifier/skeptic) added azimuth-means with both denominators.

Wikilink to canonical CHANGELOG: [[../admin/CHANGELOG]]

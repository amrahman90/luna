# Session 1 — 2026-08-19

> Tags: #session #phase-0 #wp0 #setup

**Headline:** Project scaffolding, env setup, WP0 Tasks 1–5 launched; 8-pit primitive sweep delivers first real lunar results.

- **What:** Tasks 1–3 (prior-art matrix 33 refs, env extension, TRANQPIT1 DTM 130 MB) + Task 4 (8-pit primitive sweep 7/8 pass at ≥50% recovered depth) + Task 5 (kriged I2 correction TRANQPIT1 RMSE 0.373→0.327 m).
- **Numbers:** 8 NAC DTMs total coverage at session end; MTP pit recovered 129.67 m (overshoot documented); Marius Hills 0.364 (pre-registered v5 I14 funnel mode).
- **Gotchas:** Wang & Liu / breach fills FAIL on shadowed pit interiors (drain the NoData floor); Planchon-Darboux epsilon fill is required; PDS URLs 301→pds.mcp.nasa.gov; IRIDIUMPIT1/FECNDITATS2 unwrapped x-frames need whole-360° shifts.

Wikilink to canonical CHANGELOG: [[../admin/CHANGELOG]]

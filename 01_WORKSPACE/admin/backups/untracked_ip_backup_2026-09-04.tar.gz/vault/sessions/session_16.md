# Session 16 — 2026-08-22

> Tags: #session #phase-4 #p4-3 #diviner #thermal #ingeniipit-counter-evidence

**Headline:** Phase 4 P4.3 Diviner thermal — INGENIIPIT reframed as rocky-ejecta counter-evidence.

- **What:** Powell 2023 GHRM grids fetched by prior parallel session, sha256-verified this cycle, 0 new bytes; 44 candidates sampled, 14/44 T-NO_DATA, 17/44 RA-NO_DATA (4/7 DTMs in equatorial coverage gap, 1/7 partial); MANIFEST rows added.
- **Numbers:** Thermal 2/7 fully usable (INGENIIPIT, FECNDITATS2); 4/7 all-sentinel in Powell GHRM equatorial/sub-arctic gap; 1/7 partial (SWFECUNPIT1); INGENIIPIT +2.65 K → reclassified as rocky ejecta counter-evidence (RA 0.98% vs 0.50% local mare ≈2×).
- **Gotchas:** Powell GHRM pixel-size caveat (tube-scale sub-pixel at all 7 DTMs; site-scale only at G1); multi-evidence stacking at G1 is morphometry-only; cost $0 ($0 from MANIFEST acquisitions count as $0 public data).

Wikilink to canonical CHANGELOG: [[../admin/CHANGELOG]]

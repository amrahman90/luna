# Session 4 — 2026-08-20

> Tags: #session #phase-0 #lltb1-v0.1 #six-sites

**Headline:** Six LLTB-1 v0.1 sites now processed (vs three); Paper 1 v0.1 with real numbers; v0.2 release.

- **What:** Added Kingsbowl (1.05 GB), IndianTunnel_cave_10x (325 MB), Sheepridge (669 MB), IndianTunnel_NorthSurface (1.7 GB); Paper 1 main.md v0.1; LLTB-1 v0.2 release (connected-component filter + f32-dir auto-discovery).
- **Numbers:** Best honest F1 **0.277** IndianTunnel_NorthSurface @ 1 m; recall 1.00 at every rung with ≥5 void cells across all 6 sites; v0.2 F1 unchanged (precision bottleneck = slow slopes, not single-pixel artifacts).
- **Gotchas:** v0.2 release note is honest — the connected-component filter gives NO headline F1 lift; pre-existing bugs found (not fixed): `degrade.py:153` `Axes` subscripting; `scope_map_v11.py` EPSG:4326 (Earth, not Moon).

Wikilink to canonical CHANGELOG: [[../admin/CHANGELOG]]

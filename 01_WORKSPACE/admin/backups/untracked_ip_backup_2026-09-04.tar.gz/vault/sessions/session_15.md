# Session 15 — 2026-08-22

> Tags: #session #phase-3 #p3-1b #p3-1c #registry #calibration-freeze

**Headline:** Phase 3 complete — mare transfer N=7/649; TRANQPIT1 calibration freeze; registry 44 candidates.

- **What:** P3.1b TRANQPIT1 calibration freeze with FREEZE stamp + surface-recipe bug found + fixed (sub-sampled vs rung grid); P3.1c transfer N=7/10 (3 DTMs skipped no cached score); 44 candidates, A=0, B=0 (3 downgraded per skeptic I14-funnel inversion), C=44; 18.2 multi-illumination deferred.
- **Numbers:** Aggregate FP **3.71 [0.76, 10.83] per 10⁴ km²** calibration-context (NOT survey); TRANQPIT1 per-DTM **240.41 [49.58, 702.58]** (n=4 small-sample regime); frozen rung-5 F1 0.400 (TP 1 / 3 FP) vs v0.1 default 0.067.
- **Gotchas:** Skeptic UNSOUND → corrected (tier-B downgrades, ring-artifact notes, IRIDIUMPIT1 missed-detection, framing fixes); calibration/transfer leakage (frac=0.20 tuned on single positive; "transfer" applies un-re-tuned threshold).

Wikilink to canonical CHANGELOG: [[../admin/CHANGELOG]]

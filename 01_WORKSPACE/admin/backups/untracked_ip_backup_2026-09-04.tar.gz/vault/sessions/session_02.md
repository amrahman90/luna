# Session 2 — 2026-08-19

> Tags: #session #phase-0 #wp1 #wp2 #wp3

**Headline:** WP1/LLTB-1 + WP2 sag-search + WP3 fusion all staged with first real lunar numbers.

- **What:** Tasks 9–10 scope map + Z1 staging (5 LLTB-1 modules written) + Z2 staging (sag-search + confusion-layer) + Z3 staging (GRAIL + Diviner + fusion prototype).
- **Numbers:** TRANQPIT1 sag-search @ 5 m = **29 candidate peaks**, top 39.2 at MTP pit; MARIUSPIT01 @ 4 m = 276 peaks (Frangi suppressed by I14 funnel); INGENIIPIT @ 2 m = 393 peaks, top 19.3; GRAIL gr_r 1.62–1.67 m/s² over MTP.
- **Gotchas:** Bug fixes: 5×5 min filter → 21×21 nan-robust median envelope; GRAIL csv comma-delim; pyshtools 4.x `from_array()`; Frangi overflow on float32 → float64; WBT needs `set_whitebox_dir` + `set_working_dir('/tmp')` + geokeys.

Wikilink to canonical CHANGELOG: [[../admin/CHANGELOG]]

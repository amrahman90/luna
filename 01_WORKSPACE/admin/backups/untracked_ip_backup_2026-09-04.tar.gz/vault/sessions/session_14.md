# Session 14 — 2026-08-22

> Tags: #session #phase-3 #p3-1a #per-dtm-floors #dtm-gap

**Headline:** P3.1a per-DTM Z2-scale noise floors — 639/649 DTM-production gap identified.

- **What:** `code/wp0_kriging/per_dtm_floors.py` driver; reuses Task-6 `noise_floor.run_dtm` verbatim (no reimplementation); emits `per_dtm_floors.csv` (10 rows), `per_dtm_floors_summary.json`, `per_dtm_floors_METHODS.md`; `data/candidate_registry.csv` skeleton preserved (no rows yet).
- **Numbers:** Pooled sag-band RMS **0.766–1.462 m**, **median 1.147 m**; `local_Amin` median **3.44 m** (project convention 3× pooled RMS); sanity check exact match to 6 dp vs Task-6 (TRANQPIT1 1.245184 m; MARIUSPIT01 1.379200 m).
- **Gotchas:** **639 of 649 good-tier DTMs skipped** (no on-disk NAC DTM or krigcorr derivative) — the DTM-production gap that Task 8 rental was meant to solve; this MUST be reflected in G1 as a $0-scope limitation.

Wikilink to canonical CHANGELOG: [[../admin/CHANGELOG]]

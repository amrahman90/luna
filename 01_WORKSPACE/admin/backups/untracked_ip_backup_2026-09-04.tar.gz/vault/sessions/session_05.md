# Session 5 — 2026-08-21

> Tags: #session #phase-0 #lltb1-v0.3 #slope-mask

**Headline:** LLTB-1 v0.3 — slope-aware precision lift; universal F1 gain across 7 sites.

- **What:** New `slope_mask(dtm, pixel_m, min_slope_deg, smooth=3)` helper; `--slope-mask-degrees` CLI flag (default 0; recommended 10); rung summary fields f1_test_slope + slope_mask_degrees + n_slope_masked_test; output `slope_ok_<rung>m.tif` audit raster.
- **Numbers:** +2200% on Kingsbowl (worst case), +37% on IndianTunnel_Collapse3 (real lava tube), +7% on IndianTunnel_NorthSurface (best honest); v0.3 verification 15/15 PASS; 7 LLTB-1 sites covered (added Sheepridge, cave_10x, cave_1x).
- **Gotchas:** The connected-component v0.2 lift was honestly reported as zero; v0.3 fixes that with the slope mask — the precision bottleneck was connected slow slopes, not single-pixel artifacts.

Wikilink to canonical CHANGELOG: [[../admin/CHANGELOG]]

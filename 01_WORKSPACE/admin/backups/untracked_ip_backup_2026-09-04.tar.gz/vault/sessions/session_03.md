# Session 3 — 2026-08-20

> Tags: #session #phase-0 #lltb1-v0.1 #fieg

**Headline:** RAR5 extraction blocker SOLVED; first end-to-end LLTB-1 v0.1 deliverable (Fieg_A); G0′ report delivered.

- **What:** `code/setup/extract_rar.py` (4-mirror fallback for bsdtar .deb); Fieg_A.f32 → 11.7M-point .npz → full pipeline (convert → degrade → VCI → sag_detect → quicklook); WP0 scope map v1.1 + G0′ report delivered.
- **Numbers:** Fieg_A sag-detect F1 (test): 0.5 m = 0.020, 2 m = 0.013, 5 m = 0.013; recall 0.69/0.50/1.00; NASA analog downloads: Fieg 100% complete.
- **Gotchas:** System 7z v23.01 cannot decode RAR5 ("Unsupported Method"); bsdtar from libarchive-tools .deb is the answer (no sudo); partial RARs yield 0-byte .f32 from 7z — extraction needs complete RAR.

Wikilink to canonical CHANGELOG: [[../admin/CHANGELOG]]

# Session 23 — 2026-08-23

> Tags: #session #phase-6 #manifest #p3-1c-closure #verifier-skeptic

**Headline:** P3.1c growth cycle closed; MANIFEST updated with 11 NAC DTM rows; all 7 verifier edits applied.

- **What:** LROC NAC DTM fetch (11 OK, 3.6 GB, all sha256 verified) committed in `7860631` (Phase 3 P3.1c, session 21); Frangi score-raster generation (10 in-scope DTMs; TYCHOPK 1.44 GiB deferred memory ceiling); registry 44 → 257; tier A=0, B=0, C=257.
- **Numbers:** Aggregate FP 9 / 14840.27 km² = **6.06 [Poisson-exact Garwood 95% CI 2.77, 11.51] per 10⁴ km²** (calibration-context, NOT survey rate; selection-biased to catalogued pits; G1 §3 row 10 verdict); 17 of 21 actually ran Frangi; 4 deferred (TYCHOPK memory + 3 no-cached-raster); 9 highland sites flagged terrain_extrapolation; 0 FPs counted; TYCHOPK02 76 below-floor candidates.
- **Gotchas:** Skeptic SOUND-with-objections (FECUNPIT distance correction in findings.md — 67 km → 138/552.5 m from NEAREST pit); r003 borderline-TP under 150 m tolerance; cost $0; cumulative Phase 6 spend $0/$150/$800.

Wikilink to canonical CHANGELOG: [[../admin/CHANGELOG]]

# Session 17 — 2026-08-22

> Tags: #session #phase-5 #deferrals #pu-learning #mgc3

**Headline:** Phase 5 record-only deferrals (PU learning + physics screen + MGC3).

- **What:** 21.2 PU baselines deferred (n=5 insufficient; need N≥30); 21.3 physics + tier-A deferred (max tier C at G1 by definition); 21.4 MGC3 cross-body pretraining deferred to Paper 2 (lunar registry too small); findings.md appended three dated decision sections; roadmap Steps 21.2/21.3/21.4 + Next_Tasks P5.1/P5.2/P5.3 ticked with deferral notes.
- **Numbers:** No new work product; cost $0; lock acquired for the whole Phase 5 cycle.
- **Gotchas:** Tier-A = 0 by design (≥2 independent evidence legs unmet); tier-B promotion of MARIUSPIT01 rille-intersect candidates would invert the pre-registered v5 I14 funnel failure mode.

Wikilink to canonical CHANGELOG: [[../admin/CHANGELOG]]

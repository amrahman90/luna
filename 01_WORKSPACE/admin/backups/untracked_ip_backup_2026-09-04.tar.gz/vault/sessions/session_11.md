# Session 11 — 2026-08-21

> Tags: #session #phase-0 #task-12 #analog-gt #phase-0-residual

**Headline:** Indian Tunnel analog GT + Phase-0 residual; mask semantics corrected per skeptic.

- **What:** `code/wp1_analog/` (6 modules) for cave cloud → NorthSurface DTM registration (coarse yaw + ICP, adjust-scale OFF); `data/outputs/wp1_analog/{registration,void_mask}/` outputs; bonus: degrade.py NaN-accumulation bug found + fixed; rungs regenerated (40% now valid).
- **Numbers:** Dense gate **9.3% inliers <1 m, RMS 0.490 m**; trimmed 0.139 m on 2.6% of correspondences; entrance-only overlap 61.6% vs assumed 90%; roofed-void in-window = 5 cells / 1.25 m² (n=5 supports no statistic).
- **Gotchas:** Mask semantics: entrance-trench + skylight footprint, NOT roofed-void GT — excluded from sag-rung F1 in v0.5; benchmark-bias guardrail held.

Wikilink to canonical CHANGELOG: [[../admin/CHANGELOG]]

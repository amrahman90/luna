# Gate G0′ — Zero-Cost Portion of Gate G0

> Tags: #gate #g0prime #final-passed #zero-cost

**Status:** FINAL-PASSED · **Date:** 2026-08-21 · **Verdict:** **9 PASS / 0 PARTIAL / 0 FAIL**

G0′ is the zero-cost subset of v5 master-plan Gate G0 (roadmap Task 10).
Full G0 additionally requires one reproduced NAC DTM end-to-end (paid;
§8 trigger T1 — see [[decisions/Tier-1 trigger]]). G0′ is the only gate
the project has run on pure Tier-0 local compute.

**Canonical report:** [[../plans/2026-08-21_GATE_G0prime_report_v1.1|G0′ report v1.1]]
(FINAL-PASSED; user decision D1, 2026-08-21). Working copy:
`papers/gate_reports/G0prime_report_v1.1.md`.

# Verdict counts (honest, in-row)

9 rows: **7 PASS + 2 PASS (process only)**, 0 PARTIAL, 0 FAIL.
Process-only PASS means: process completed; science outcome not claimed.

| Row | Criterion | Verdict |
|---|---|---|
| 1 | Primitive recovers ≥6/8 covered pits at ≥50% catalogued depth | PASS (7/8) |
| 2 | Kriged I2 correction smooth + signal-preserving | PASS |
| 3 | Noise floor measured, sag-band verdict | PASS |
| 4 | Confusion layers acquired | PASS |
| 5 | Scope ranked | PASS |
| 6 | Local-ASP decision documented (Task 8) | **PASS (process only)** |
| 7 | LLTB-1 v0.1+ benchmarked | PASS (v0.4; 11/11 verify) |
| 8 | Z2 sag search run | **PASS (process only)** |
| 9 | Prior-art matrix status | PASS (33 refs; 6 priority rows) |

# Honest elements documented in-row

- **Z2 pit-recovery correction:** verifier-refuted claim "top candidate
  within 100 m on all 8 runs". True reading: **pit recovered within 100 m
  on 4/8 runs** (Ingenii 46 m, MTP 45 m, Procellarum 38–77 m).
  **Wilson 95% CI on 4/8 ≈ [0.18, 0.82]** (n=8).
  Evidence: `admin/verification_evidence/2026-08-21_z2_pit_distance_verification.md`.
- **Marius funnel mode:** pre-registered v5 I14 rille-funnel failure —
  documented finding, not defect.
- **Kingsbowl F1 history:** 0.002 → 0.045 → 0.043 — regressions kept visible.
- **SLDEM2015 normalisation (Step 18.1):** deferred to WP2 (see [[backlog/Deferred items]]).
- **I12 confound covariates** (LOLA track density, NAC image count): deferred to WP2.

# Skeptic + verifier verdicts

- **Skeptic:** SOUND-with-objections. **6 addressed** (O2–O5 logged in
  [[../notes/findings|findings.md]] 2026-08-21): ≥5 m floor wording,
  "project convention" label on the 3× sag-band RMS rule, Wilson 95% CI
  on 4/8 recovery, SLDEM2015 + I12 deferrals made explicit in §3.
- **Verifier:** PASS-with-notes (refutation of "8/8 within 100 m" →
  corrected to 4/8).

# Headline numbers (one line each)

- LLTB-1 v0.4 best honest F1 **0.362** (IndianTunnel_NorthSurface 1 m @45°).
- Real lava tube Collapse3 F1 **0.188** @0.5 m @45°.
- Recall **1.00 at every rung with ≥5 void cells** — precision is the bottleneck.
- DTM-production gap: **8/21 covered pits have NAC DTMs on disk** at G0′.

# Related

- Decision: [[decisions/D1]] (G0′ pass, 2026-08-21, human-approved).
- Decision: [[decisions/D2]] (Task 8 NAC DTM stereo deferral, drives DTM gap).
- MOC: [[mocs/MOC Gates & Decisions]].
- Findings log: [[../notes/findings]].
- Claim discipline: [[concepts/Claim discipline]].
- Deferred items: [[backlog/Deferred items]].
- Successor gates: [[gates/G1]], [[gates/G2]].

# Claim discipline reminder

> G0′ closes zero-cost only. The Tranquillitatis radar conduit (Carrer 2024)
> remains the only subsurface structure on the Moon evidenced by any instrument
> today. Nothing in G0′ changes that. **Calibrated inference, never verified
> detection.** FP rate NOT MEASURED at survey scale.

Tags: #gate #g0prime #final-passed #verifier-pass-with-notes #skeptic-sound-with-objections

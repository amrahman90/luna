# Phase 3 complete — the detector chain end-to-end

You completed the 6-lesson Phase 3 curriculum on the v5 §5 I1-I15 inherited machinery, ending with the synthesis walk-through of registry row 33 (LV-FECNDITATS2-0200cm-r001) through every step from I1 (implicit production ICP) to I15 (Tranq-frozen recipe + 100 m matching radius), with the I10 + I11 + I14 hand-offs flagged where they matter.

Implications for Phase 4:

- You now know which I1-I15 component every measured number in the project comes from: the I2 kriging correction (TRANQPIT1 RMSE 0.373 → 0.327 m; MARIUSPIT01 1.425 → 0.541 m); the I3 noise floor (1.245 m at TRANQPIT1, 1.379 m at MARIUSPIT01, per-DTM pooled 0.657-1.462 m at G2); the I15 frozen calibration md5 `2597002375206aba3119c240c373ad62` unchanged across all G1 + G2 edits.
- You can read the v5 §4 critical-path chart and explain why the G1 verdict is "YES at A ≥ 5 m single-DTM, NOT-MEASURED at A = 1-2 m" — and what happens if the answer were NO (the v5 §11 null-result plan: pivot to pit-chain / VCI overhang / WP3 fusion; publish the detectability limits paper regardless).
- You can walk any row of the 278-row candidate registry through the chain and identify where the I10 visual-inspection hand-off lands, where the I11 stratified-detectability hand-off applies, and where the I14 funnel-pit pre-registered failure mode would manifest.
- Phase 4 unlocks the Tier-D geophysics confirmation layers (Diviner thermal, Mini-RF / DFSAR radar imaging, GRAIL gravity, SELENE LRS sounder) — 5 lessons that turn the morphometry-only tier-C candidates into multi-evidence tier-A candidates where the data exists. The Tier-D streams confirm the column above a candidate void; they do not detect the void itself (v5 §3 evidence hierarchy table).
# Phase 2 complete — reading the candidate registry

You completed the 8-lesson Phase 2 curriculum on reading the candidate registry and the FP-rate headline statistics, ending with a walkthrough of `transfer_summary.json` block navigation. Implications for Phase 3:

- You can now read any row of the 278-row registry, explain every column, and know what tier A/B/C means and why 0/0/275 is the honest starting state.
- You can re-derive the aggregate 3.74 [1.71, 7.10] FP per 10⁴ km² by hand from `n_fp = 9` / `total_area_km2 = 24062.96`, and reproduce the Garwood CI from `scipy.stats.chi2`.
- Phase 3 unlocks the full detector chain end-to-end (WP1 degradation ladder → WP2 sag search → WP3 multi-evidence fusion) — 6 lessons that will take you from understanding the registry to understanding every step that produced it.

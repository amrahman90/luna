# Phase 1 complete — lunar morphology for visual inspection

You completed the 5-lesson Phase 1 curriculum on lunar morphology and visual inspection, ending with a worked judgment exercise on the FECUNPIT cluster. Implications for Phase 2:

- The decision tree in `reference/visual-inspection-decision-tree.html` is your cheat sheet for any future inspection. Print it.
- You can complete the remaining 14 visual inspection candidates (TRANQPIT1, INGENIIPIT, GRUITHMARE2, MARIUSCONE) using the same 30-second workflow.
- Phase 2 unlocks interpretation of the registry numbers themselves (Frangi, depth, FP per 10⁴ km²) — which is what you'll need to understand WHY the detector flagged what it did at each cluster.

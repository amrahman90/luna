# Curriculum complete — LUNARVOID learning 35/35

Curriculum complete. 35/35 lessons across 7 phases built; 7 reference cards; 7 learning records; 2 shared assets (`assets/lesson.css` 251 lines; `assets/quiz.js` 44 lines). Total gitignored footprint: ~21,000 lines of educational content (33 prior lessons × ~510 lines avg = ~16,830 lines + 2 Phase 7 lessons 0034-0035 ~650 lines avg = ~1,300 lines + 7 reference cards ~250 lines avg = ~1,750 lines + 7 learning records ~14 lines avg = ~98 lines + 2 shared assets 295 lines + this record). Curriculum is COMPLETE; the MISSION (visual inspection → registry literacy → detector chain → geophysics → photogrammetry → publication → project operations) is end-to-end covered.

## Curriculum map

| Phase | Topic | Lessons | Status |
|---|---|---|---|
| **1** | Lunar morphology for visual inspection (immediate blocker) | 5 lessons (0001-0005) | COMPLETE |
| **2** | Reading the candidate registry (Frangi, depth, FP per 10⁴ km², tiers) | 8 lessons (0006-0013) | COMPLETE |
| **3** | The detector chain end-to-end (I1-I15 inherited components) | 6 lessons (0014-0019) | COMPLETE |
| **4** | Geophysics confirmation layers (Diviner, Mini-RF, GRAIL, SELENE LRS) | 5 lessons (0020-0024) | COMPLETE |
| **5** | Photogrammetry (NAC + ISIS3 + ASP) — gated on rental | 5 lessons (0025-0029) | COMPLETE |
| **6** | Writing & publication (venues, cover letters, referee responses) | 4 lessons (0030-0033) | COMPLETE |
| **7** | Project operations (orchestrator loop, verifier + skeptic cycles) | 2 lessons (0034-0035) | COMPLETE |
| **TOTAL** | All phases | **35/35** | **COMPLETE** |

## Reference cards

| Card | Topic | Anchor |
|---|---|---|
| 1 | Visual inspection decision tree (Phase 1) | 30-second workflow + artifact scan + decision tree + verdicts |
| 2 | Registry cheatsheet (Phase 2) | 278-row registry column dictionary + tier-A/B/C semantics + FP per 10⁴ km² |
| 3 | Inherited machinery I1-I15 cheatsheet (Phase 3) | Mueller 2026 + Reichenzeller 2026 source-of-truth + lunar ports |
| 4 | Geophysics confirmation cheatsheet (Phase 4) | Tier-D architecture + Carrer 2024 Tranquillitatis anchor + v5 §9 carve-out |
| 5 | Photogrammetry cheatsheet (Phase 5) | NAC geometry + ISIS3 chain + ASP flags + Tier-1 hardware floor |
| 6 | Writing & publication cheatsheet (Phase 6) | 6-venue strategy + 4-paragraph cover letter + 28-Q referee library + 3-tier decision tree |
| 7 | Project operations cheatsheet (Phase 7) | 5-agent team + commit-message convention + stop conditions + skeptic's 4 objections + cost discipline reminder |

## Learning records

| Record | Phase | Implications for next phase |
|---|---|---|
| 0001 | Phase 1 complete (morphology) | Phase 2 unlocks registry literacy |
| 0002 | Phase 2 complete (registry) | Phase 3 unlocks detector chain |
| 0003 | Phase 3 complete (I1-I15) | Phase 4 unlocks geophysics |
| 0004 | Phase 4 complete (Tier D) | Phase 5 unlocks photogrammetry |
| 0005 | Phase 5 complete (photogrammetry) | Phase 6 unlocks publication |
| 0006 | Phase 6 complete (publication) | Phase 7 unlocks project operations |
| 0007 | **Curriculum complete (terminal)** | The substrate is yours; the curriculum is end |

## Project readiness checklist — what's now possible

After completing the 35/35 curriculum, the following is now within independent reach (no longer requires the orchestrator's summary):

- **Read every paper number + its provenance.** Lessons 0010 + 0012 + 0024 cover the FP per 10⁴ km² framing (calibration-context NOT survey; v5 §9 line 572-574 carve-out); lesson 0013 covers the `transfer_summary.json` 1,963-line canonical summary; lesson 0032 covers the 28-Q pre-prepared referee library where each Q cites the exact provenance path (`data/outputs/...` + `notes/findings.md` + `papers/gate_reports/...`). The aggregate 3.74 [1.71, 7.10] per 10⁴ km² can be re-derived from `transfer_summary.json` and the 278-row registry in ~5 min.

- **Operate the orchestrator loop independently.** Lesson 0034 covers the 5-agent team (geo-coder / verifier / skeptic / archivist / paper-writer) and their permission boundaries; the task lifecycle (lock → MISSION read → geo-coder → verifier → skeptic (on scientific claims) → archivist → loop); the commit-message convention (no cost info; semicolon clauses; one-line headline; 01_WORKSPACE paths; compact numbers); the 5 stop conditions (cost trigger; gate decision; verifier FAIL ×3; T5 regression; out-of-workspace write). Lessons 0034 + 0035 are the manual-invocation pattern for the verifier and skeptic outside the autonomous loop.

- **Decide tier-decisions (rental vs local) with math.** Lesson 0033 covers the 3-tier compute decision tree anchored in v5 §7 lines 410-423 verbatim (Tier-0 laptop; Tier-1 rental bursts; Tier-2 GPU hourly); the 5-step Tier-1 trigger checklist (work cannot complete on Tier-0; specific DTM need; $150 ceiling preserved; trigger logged; work-queue defined); the honest math against the $800 / 30-month master ceiling (worst case ~$285-340 self-funded; best case net-zero with cloud research credits); the Hetzner rental kit as the launch-ready Tier-1 implementation gated on PDS recovery.

- **Run the visual inspection workflow.** Lessons 0001-0005 cover the lunar morphology for visual inspection: how lava tubes form (buoyant drained flow + roof collapse); pit vs skylight vs tube-shaped depression; NAC imagery interpretation (incidence vs emission; phase angle; sun azimuth); common artifacts (Frangi rings at pit rims; sun-azimuth shading; DTM edge; ejecta terrain); the FECUNPIT first-judgment (3 unique large depressions × 2 rungs at DTM north end ~67 km from catalogued pit; amplitudes 155/140/34 m; per-session 27 CHANGELOG entry). Phase 1 is the immediate blocker; the visual inspection cheatsheet (reference card 1) is the 30-second decision tree.

- **Write a referee response to common critiques.** Lesson 0032 covers the 28-Q pre-prepared Q/A library (8 categories: statistics/FP framing Q1/Q3/Q26/Q27; methodology/detector Q4/Q5/Q9/Q14/Q17/Q18/Q25; scope/generalisation Q6/Q10/Q15/Q16/Q24; novelty vs ESSA Q2; subsurface evidence anchor Q8/Q23; multi-evidence stacking Q7; engineering/data Q11/Q12/Q13/Q19/Q20/Q21/Q22; title discipline Q28). Each stub follows the per-comment A/B/C structure (Section A referee comment verbatim; Section B 4-move response from Section D; Section C manuscript change with before/after diff + reason). The library grows by ~4-8 stubs per paper in v5 §12; expansion-time savings on receipt of a decision letter is ~10-15 min per stub vs ~60-90 min from scratch.

- **Hand the project to another agent (or a future you) with full context.** The 3 durable outputs per orchestrator cycle (commit + CHANGELOG entry + findings entry, per the project-operations cheatsheet section 6) are the on-disk context any future agent needs to pick up where the orchestrator left off. The CHANGELOG (date — what — numbers — where — why format) is the process ledger; the findings log (claim + confidence + evidence + caveat; dated sections; append-only) is the scientific ledger; the MANIFEST (URL + SHA-256 + size + date + licence + parent) is the data-acquisition ledger. The 6 h lock TTL + the re-acquire-at-start-of-cycle rule (lunarvoid-protocol skill line 38 verbatim) match the compaction-safe rule to a long-pause survival mechanism.

## Closing

The curriculum is 35/35 complete across 7 phases. Every lesson is anchored in the actual LUNARVOID project artefacts (`v5 master plan` §3 evidence hierarchy + §7 INFRASTRUCTURE + §8 WP0-WP7 + §9 MANDATORY REPORTING + §10 RISK REGISTER + §12 publication strategy; `lunarvoid-protocol` skill; `lunarvoid-conventions` skill; `admin/CHANGELOG.md`; `admin/hetzner_rental_kit/launch.sh`; `papers/paper1_resolution_limits/*` submission package; `notes/findings.md`). The reference cards compress each phase into a printable one-pager. The learning records document the inter-phase links (each phase's record ends with implications for the next phase; this terminal record ends with the project readiness checklist). The shared assets (`lesson.css` 251 lines + `quiz.js` 44 lines) carry the visual + interactive substrate.

The next time you write a paper section, dispatch a verifier check, trigger a skeptic review, decide a tier-1 rental, or hand the project off to a future agent, the curriculum is the on-tap reference. The operational substrate is yours; the curriculum is complete.
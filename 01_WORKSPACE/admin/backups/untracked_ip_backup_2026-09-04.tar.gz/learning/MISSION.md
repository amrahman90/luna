# Mission: Operate the LUNARVOID project independently

## Why

You are the author of the LUNARVOID lunar-lava-tube paper and the orchestrator of a multi-agent research team. Currently the agentic system can do everything *except* (a) visually interpret LROC NAC imagery to judge whether a flagged depression is a real tube-shaped void, (b) sign off on scientific claims with your name, and (c) carry the work to publication. You need to understand the methodology, the data, and the project's position relative to the v5 master plan deeply enough to do (a) and (b) yourself, and to run (c) autonomously.

## Success looks like

- You can visually inspect a flagged depression on LROC NAC imagery and produce a defensible judgment (tube-shaped / impact / artifact / DTM edge) within 2-4 minutes per site, with a written rationale.
- You can read any row of the candidate registry and explain what every column means, including tier labels and FP per 10⁴ km² framing.
- You can independently re-derive the aggregate FP rate (currently 3.74 [1.71, 7.10] per 10⁴ km²) from `transfer_summary.json` and the registry.
- You can read and critique the v5 master plan §3 evidence hierarchy table and know which streams the project has/haven't activated.
- You can write a referee response to a critical review using the pre-prepared Q/A stubs.
- You can decide whether to authorize the Hetzner Tier-1 rental ($55/mo) without needing the orchestrator's summary of the trade-offs.

## Constraints

- **Time:** ~2 hours/week available for learning
- **Format:** hands-on, concrete examples from the LUNARVOID project (no abstract tutorials)
- **Tools:** web browser, LROC QuickMap, Zotero, Obsidian (vault at `01_WORKSPACE/Lunar Lavatube knowledge/`), terminal via opencode orchestrator
- **No-cost:** all teaching must use open-access resources or the project's own artifacts
- **Local-only:** this entire `01_WORKSPACE/learning/` workspace is gitignored; lessons stay on the laptop

## Out of scope

- **Deep-learning on NAC images** (Mask R-CNN, U-Net): deliberately excluded by v5 — see "what we DON'T use" in NOTES.md
- **In-house photogrammetry from raw images** until rental authorized: ASP/ISIS3 install deferred
- **Mission operations (Mars Cushing cross-body, GRAIL inversion, SELENE LRS)**: deferred to WP3+ which needs rental
- **Robotic WP7**: partner-dependent per v5
- **Astrophysics/planetary science theory**: stay at the operational level; no need for orbital mechanics or impact physics beyond what the paper needs

## Curriculum (35 lessons across 7 phases; ~12-18 weeks)

| Phase | Lessons | Topic | Status |
|---|---|---|---|
| **1** | 5 lessons | Lunar morphology for visual inspection (immediate blocker) | **STARTING NOW** |
| **2** | 8 lessons | Reading the candidate registry (Frangi, depth, FP per 10⁴ km², tiers) | Pending phase 1 |
| **3** | 6 lessons | The detector chain end-to-end (I1-I15 inherited components) | Pending phase 2 |
| **4** | 5 lessons | Geophysics confirmation layers (Diviner, Mini-RF, GRAIL, SELENE LRS) | Pending phase 3 |
| **5** | 5 lessons | Photogrammetry (NAC + ISIS3 + ASP) — gated on rental | Pending phase 4 |
| **6** | 4 lessons | Writing & publication (venues, cover letters, referee responses) | Pending phase 4 |
| **7** | 2 lessons | Project operations (orchestrator loop, git, commit conventions) | Pending phase 4 |

**Order matters**: phases 1→2 unlock immediate operational capability; 3 gives full detection understanding; 4-7 prepare for next-year work.

## Mission changelog

| Date | Change | Reason |
|---|---|---|
| 2026-08-26 | Adopted this mission; curriculum drafted | User said "I want to learn everything" 2026-08-26 |
| 2026-08-26 | Phase 1 prioritized | Visual inspection was the immediate blocker |

/* LUNARVOID learning workspace — interactive quiz widget
 * Adds: click-to-reveal multi-choice quizzes with feedback.
 * Usage in HTML:
 *   <div class="quiz" data-correct="2">
 *     <div class="q-num">Question 1 of 3</div>
 *     <div class="q-text">What is the primary input to the LLTB-1 detector?</div>
 *     <ol class="choices">
 *       <li data-idx="0">Raw NAC image pixels</li>
 *       <li data-idx="1">NAC DTMs (derived products)</li>
 *       <li data-idx="2">LOLA altimetry points</li>
 *       <li data-idx="3">Earth analog point clouds</li>
 *     </ol>
 *     <div class="feedback"></div>
 *   </div>
 */
(function () {
  document.querySelectorAll('.quiz').forEach(function (quiz) {
    var correctIdx = parseInt(quiz.getAttribute('data-correct'), 10);
    var feedbackEl = quiz.querySelector('.feedback');
    var choices = quiz.querySelectorAll('ol.choices li');
    var answered = false;

    choices.forEach(function (li) {
      li.addEventListener('click', function () {
        if (answered) return;
        answered = true;
        var picked = parseInt(li.getAttribute('data-idx'), 10);
        var isCorrect = picked === correctIdx;
        li.classList.add(isCorrect ? 'correct' : 'wrong');
        if (!isCorrect) {
          choices.forEach(function (other) {
            if (parseInt(other.getAttribute('data-idx'), 10) === correctIdx) {
              other.classList.add('reveal-correct');
            }
          });
        }
        var fbText = li.getAttribute('data-feedback') ||
          (isCorrect ? 'Correct.' : 'Not quite — the right answer is highlighted.');
        feedbackEl.textContent = fbText;
        feedbackEl.classList.add('show', isCorrect ? 'correct' : 'wrong');
      });
    });
  });
})();

# RESOURCES — high-trust sources for LUNARVOID-related learning

> **Status:** SKELETON — to be populated after the MISSION is set and topic chosen.
> Last edited: 2026-08-26

For each potential topic, the primary resources are flagged. Lessons should cite from this list (not invent references).

---

## Topic A — LROC NAC visual inspection (morphology)

To be added when topic A is chosen.

## Topic B — Reading the candidate registry

### Primary resource

- `01_WORKSPACE/data/outputs/wp2_sag/transfer/transfer_summary.json` — canonical per-DTM + per-rung + aggregate summary; source of every FP-rate number in the paper.
  Why: This is the single source of truth for the 3.74 [1.71, 7.10] aggregate (n_fp=9 over 24,062.96 km²) and the per-DTM TRANQPIT1 240.41 [49.58, 702.58] rate. Every other citation traces back here.

- `00_SOURCE_ORIGINALS/LUNARVOID_Master_Plan_v5_Full_Synthesis.txt` — v5 master plan §9 (mandatory reporting: FP per 10⁴ km², splits by SITE not tile, matching radius ≥ 30 m, etc.).
  Why: §9 is the contract that defines what numbers must be reported and in what framing. The aggregate 3.74 figure is in this framing.

- `01_WORKSPACE/papers/paper1_resolution_limits/main.md` — Paper 1 §3.3 (sag detector recipe: PD fill, Frangi sigmas 30/60/100/150/200/300 m, depth × vesselness score, 5-cell local-max), §4 (results: per-rung Table 1a, calibration-context framing).
  Why: §3.3 documents the recipe; §4 reports the result. Together they bracket the detector chain.

### Supporting

- `01_WORKSPACE/data/candidate_registry.csv` — 278-row tier-C registry; open the file and read the column dictionary in `reference/registry-cheatsheet.html` Section 1. Every row traces via the `evidence` field to a `transfer_summary.json` entry.
- Wagner & Robinson (2021) LPSC 52 #2530 — Lunar Pit Atlas; ~281 catalogued lunar pits with ~30 m positional accuracy; columns: funnel and inner diameters, depth, host terrain, sub-type, unique IDs. Sets the v5 §I15 declared matching radius (≥ 30 m).
- `notes/2026-08-19_task3_transqpit1_fill_variants.md` — the 4-engine fill-variant test (Wang & Liu 3.18 m vs Planchon-Darboux 129.67 m); anchors the PD fill choice.
- `notes/findings.md` lines 599 and 727-735 — the 6.06 (G1) → 3.74 (G2) denominator history, plus the auditor's per-claim verdict on the 3.74 figure.

### Caveats

- The registry's `confusion` column references Hurwitz 2013 rilles (~195 sinuous rilles) and LU5M812TGT crater chains (Zenodo 10.5281/zenodo.14608566, CC-BY-4.0). Both are required inputs for tier-B promotion but don't transfer outside their catalogue footprints.
- Wagner & Robinson 2021 is a conference abstract, not a peer-reviewed paper; the deeper analysis is Wagner & Robinson 2022 JGR Planets (doi:10.1029/2022JE007328) for pit-interior morphology.
- The `transfer_summary.json` aggregate `n_tier_A = 0` is by design (P5.2 deferred), not a stuck pipeline.

## Topic C — LUNARVOID project orientation

- `00_SOURCE_ORIGINALS/LUNARVOID_Master_Plan_v5_Full_Synthesis.txt` — authoritative master plan (715 lines)
- `01_WORKSPACE/Lunar Lavatube knowledge/00_HOME.md` — vault top page
- `01_WORKSPACE/Lunar Lavatube knowledge/mocs/MOC {Gates & Decisions, Sites & Candidates, Data & Code, Concepts & Methods, Sessions & Ops}.md`

## Topic D — Lunar lava tube geology

- Wagner & Robinson (2021) LPSC #2530 — Lunar Pit Atlas
- Carrer et al. (2024) Nature Astronomy — Tranquillitatis radar conduit (the ONLY verified subsurface void)
- v5 master plan §2 (one-line thesis) + §3 (evidence hierarchy table)

---

## Topic E — Detector chain end-to-end (I1-I15 inherited machinery)

### Primary resource

- `00_SOURCE_ORIGINALS/LUNARVOID_Master_Plan_v5_Full_Synthesis.txt` — v5 master plan Part II §5 (lines 184-329). The authoritative I1-I15 definitions: component name, parameters, measured performance, lunar transfer note, and v5 §9 mandatory-reporting connection. The I2 kriged correction is tagged `[highest-value transfer]`; I3 is `the noise floor and the Gate G1 criterion`; I14 is the pre-registered funnel-pit failure mode.
  Why: §5 is the contract that defines what every component does and what its lunar translation is. The v5 §4 critical-path chart (lines 144-160) sits immediately above it and is the project decision point — the chart that I1-I15 collectively enable.

- Mueller et al. (2026) *Arctic Science* 12:1-23, doi:10.1139/as-2025-0062, CC BY 4.0. Open access at the journal; code at `gitlab.com/dlr-dw/uav-snow-depth-monitoring`; data at Zenodo 10.5281/zenodo.14608566. Source of the I1-I7 inherited components: CloudCompare 2.13.2 ICP fine registration (I1); pykrige spherical-variogram kriged systematic-error correction with the headline factor-of-six RMSE reduction (4.53 → 0.21 m at 20 independent check points; I2 — the critical-path enabler); zero-change noise-floor protocol (I3); Orfeo ToolBox watershed segmentation (I4); sun-azimuth sector artifact test (I5); damping-depth thermal workflow (Appendix C; I6); conservative lower-bound framing (I7).
  Why: This is the source-of-truth paper for I1-I7. The Mueller 2026 measured numbers (Z bias +4.18 m initial, -0.53 m after ICP, -0.02 m after kriging; RMSE 4.53 → 1.26 → 0.21 m) are the v5 §5 I2 anchors. Re-read §3 (ICP parameters) and §4 (kriging workflow) before working on the WP0 kriging code.

- Reichenzeller et al. (2026) *Forests* 17:807, doi:10.3390/f17080807, CC BY. Open access at the journal. Source of the I8-I15 inherited components: Vertical Complexity Index as an overhang detector (Shannon evenness of the vertical point distribution; VCI = -sum(p_i ln p_i) / ln(n_HB); tree stem ↔ pit wall geometry; F1 0.7835 on the terrestrial calibration set; I8); thresholds do not transfer across instruments (SfM → UAV-LiDAR VCI threshold re-tune 0.4 → 0.8 lifts F1 0.6859 → 0.86; I9); apparent-FPs-may-be-unlabelled-TPs (21 of 34 apparent FPs were unlabelled understory trees; I10); stratified detectability with Wilcoxon rank-sum (I11); independent confound covariate with nulls reported (Laser Penetration Index from an independent airborne dataset; I12); sensitivity heatmap as deliverable (96 param combinations; F1 spanning only 0.6971 to 0.7835; I13); predictable geometric failure mode (only 4-6 of 11 leaning stems detected; I14); calibrate-once-transfer-unchanged with declared matching radius (I15).
  Why: This is the source-of-truth paper for I8-I15. The 96-param F1 spread is the I13 robustness evidence; the leaning-trunk failure is the I14 funnel-pit prediction source; the 21/34 unlabelled-TP finding is the I10 visual-inspection rule source. Re-read §3 (VCI formula) and §4 (per-instrument threshold trajectory) before working on the WP1 detector code.

- `01_WORKSPACE/papers/paper1_resolution_limits/main.md` — Paper 1 §3.3 (lines 152-172). Documents the sag-detector recipe: depression depth = sink_filled(DTM) - DTM (Planchon-Darboux, not Wang & Liu; `notes/2026-08-19_task3_transqpit1_fill_variants.md`); Frangi vesselness at physical scales 30, 60, 100, 150, 200, 300 m (`black_ridges=True`); per-cell score = depth × vesselness; 5-cell local-max; per-rung 50/50 threshold re-tune (I9); 4-bucket simplified stratified detectability (I11); FP-cell density as the analog tile statistic.
  Why: §3.3 is the lunar port of I8 + I9 + I11 from Reichenzeller 2026 applied to NAC DTMs. It is the place where the v5 §5 components become operational code; the recipe here is the FROZEN TRANQPIT1 calibration (md5 `2597002375206aba3119c240c373ad62`).

### Supporting

- `01_WORKSPACE/code/wp0_kriging/kriging_correction.py` — the I2 lunar port. Full pipeline: load LOLA RDR; bilinear residual = DTM - LOLA; no-change selection (slope &lt; 2° from 50-px boxcar; 20% holdout seed 42); ordinary kriging (pykrige, spherical variogram, 150 m coarse grid); corrected = DTM - kriged_correction; metrics at held-out check points; frequency check (≥99.99% correction power at λ &gt; 300 m); signal-preservation check (PD depression depth within 200 m of target pit). Outputs `data/outputs/wp0_kriging/<DTM>_kriging_metrics.csv` and `<DTM>_kriging_summary.json`.
- `01_WORKSPACE/code/wp0_kriging/noise_floor.py` — the I3 lunar port. Panel selection (flat mare, ≥ 1 km², ≥ 3 km from catalogued pits, &gt; 250 m beyond LU5M812TGT rims, ≥ 1 km from Hurwitz rilles); residual = DTM - 300 m boxcar; sag-band RMS = DoG(g(sigma=300 m) - g(sigma=60 m)) residual pooled over panels. Verdict rule: A detectable iff A &gt; 3 × sag-band RMS (project convention; Gaussian 99.7%). Headline: TRANQPIT1 pooled RMS 1.245 m; MARIUSPIT01 1.379 m.
- `01_WORKSPACE/code/wp0_kriging/per_dtm_floors.py` — the per-DTM extension of noise_floor.py. N=19 at G2 (was N=10 at G1); pooled RMS 0.657-1.462 m, median 1.103 m; by-terrain split (mare n=9 median 1.118 m / 3σ 3.355 m; highland n=5 median 1.089 m / 3σ 3.266 m); per-DTM `local_Amin_m` median 3.44 m.
- `01_WORKSPACE/code/wp1_detector/sag_detect.py` — the depth × Frangi-vesselness × 5-cell local-max detector. Paper 1 §3.3 implementation. Includes the v0.2 connected-component filter (lines 135-161) and the v0.3 slope mask (lines 164-207).
- `01_WORKSPACE/code/wp1_detector/vci.py` — the I8 VCI overhang detector. The Shannon evenness formula (lines 35-64); pipeline VCI raster → threshold → 5-cell local-max → centroids (lines 67-72). Pixel / height-bin / threshold parameters are per-rung re-tuned per I9.
- `01_WORKSPACE/data/outputs/wp2_sag/transfer/calibration_transqpit1.json` — the I15 frozen Tranq recipe. Contains `frozen.FREEZE`, `frozen.surface_recipe` (Frangi sigmas 30/60/100/150/200/300 m; pit match radius 100 m), and `frozen.transfer_rule = "TRANSFER UNCHANGED"`. The md5 (`2597002375206aba3119c240c373ad62`) is the audit anchor — unchanged across all G1 + G2 edits.
- `01_WORKSPACE/data/outputs/wp2_sag/transfer/transfer_summary.json` — the canonical per-DTM + per-rung + aggregate summary (1,963 lines). Holds the aggregate 3.74 [1.71, 7.10] FP per 10⁴ km²; the per-DTM TRANQPIT1 240.41 [49.58, 702.58]; the frozen-calibration block; the `pair_results` block with 54 raw per-DTM × per-rung records.
- `01_WORKSPACE/data/outputs/wp0_kriging/noise_floor_stats.csv` — the I3 verdict CSV. Header VERDICT lines carry the human-readable verdict per DTM (A=1,2 NOT; A=5 DETECTABLE). Read with `noise_floor.py` lines 465-477.
- `01_WORKSPACE/papers/gate_reports/G0prime_report_v1.1.md` — G0′ FINAL-PASSED. Row 2 (line 16) the I2 lunar reproduction numbers (TRANQPIT1 0.373→0.327 m; MARIUSPIT01 1.425→0.541 m). Row 3 (line 17) the I3 verdict (1.245 m / 1.379 m pooled RMS; A=5 m DETECTABLE). Row 1 (line 15) the I14 funnel-pit observation at Marius Hills (14.56/40 m = 0.364).
- `01_WORKSPACE/papers/gate_reports/GATE_G1_report_v1.0.md` — G1 FINAL-PASSED. Row 1 (line 26) the v0.5 ladder story (Hapke shadow-voiding 62/75/92 % at i=45/65/85°; 2 m rung F1 0.254→0.122). Row 3 (line 18) the I15 calibration freeze + tier discipline (the 3 MARIUSPIT01 I14 downgrades from B→C). Row 4 (line 16) per-DTM noise floors N=10/649. Row 6 (line 19) Diviner N=7 thermal INCONCLUSIVE. The aggregate FP 3.71 [0.76, 10.83] per 10⁴ km² at G1 was diluted by 6 of 7 DTMs with n_fp=0; the G2 aggregate (N=21, 278 candidates) is 3.74 [1.71, 7.10].
- `01_WORKSPACE/papers/gate_reports/GATE_G2_report_v1.0.md` — G2 FINAL-PASSED. Row 4 (line 99) per-DTM by-terrain split NEW (mare n=9 / highland n=5). Row 6 (line 101) calibration freeze md5 unchanged. Row 11 (line 106) the "calibration-context, NOT survey" verdict on the 3.74 aggregate.
- `01_WORKSPACE/notes/prior_art_matrix.{csv,md}` — Mueller 2026 and Reichenzeller 2026 rows (lines 2-3 of the CSV) — full citations, datasets, parameters, measured numbers, caveats, and project-mapping to I1-I15. The two priority-done rows are the full bibliographic anchor.
- `01_WORKSPACE/code/wp1_ladder/{hapke,sensor}/` — LLTB-1 v0.5 ladder outputs. The per-rung F1/P/R curves (I11 + I13 simplified); the i=85° recall ceiling 0.16-0.44 at 0.5 m (1 m → 0.54; 5 m → 0.60); the `hapke_summary.json` correction_2026-08-22 block.

### Caveats

- The I2 factor-of-six reduction (4.53 → 0.21 m RMSE) is the Mueller-2026 terrestrial UAV-photogrammetric reference; the LUNARVOID lunar numbers (TRANQPIT1 0.373 → 0.327 m) are smaller because production NAC DTMs are already SOCET-registered to LOLA in production (I1 is implicit). The direction and frequency check carry the I2 claim; the absolute RMSE values are not directly comparable.
- The I15 frozen Tranq recipe (md5 `2597002375206aba3119c240c373ad62`) is a "portability demonstration, NOT held-out evaluation" (G1 row 3 line 18). The 30 random-mare sites are the held-out evaluation; they are deferred to Paper 2+ because no LROC NAC DTMs exist for those footprints.
- The I12 confound-covariate protocol is fully specified (LOLA track density, NAC image count, SLDEM2015 slope) but not yet implemented; it is deferred from G2 §5 and awaits the random-mare 30-site cycle. Paper 1 §5.2 acknowledges this as a missing protocol item.
- The I14 funnel-pit prediction is pre-registered; the Marius Hills observation (14.56/40 m = 0.364) is confirmation, not post-hoc rationalisation. The framing rule generalises: pre-register → observe → cite the prediction.
- The I9 per-rung re-tuning is per-instrument and per-resolution-rung; it is NOT per-DTM. The Tranq-frozen threshold applies to every DTM in the per-DTM transfer pipeline unchanged; the per-rung re-tuning applies to the LLTB-1 analog ladder, not the production NAC DTM chain.

---

---

## Topic F — Geophysics confirmation layers (Tier D)

### Primary resource

- `00_SOURCE_ORIGINALS/LUNARVOID_Master_Plan_v5_Full_Synthesis.txt` — v5 master plan §3 evidence hierarchy table (lines 86-124). The 8-stream table (NAC DTM, NAC imagery, Chandrayaan-2 OHRC, Kaguya TC + USGS DTMs, SLDEM2015, Diviner thermal, Mini-RF / DFSAR, SELENE LRS, GRAIL gravity) with the four-order-of-magnitude scale gap explicit; the closing sentence (lines 134-137 verbatim) is the scale-bridging discipline anchor. v5 §5 I6 (lines 234-244) is the damping-depth thermal workflow (D = √(2κ/ω)). v5 §6 line 379 Tier D verbatim "CONFIRMATION LAYERS (never detectors)". v5 §9 lines 572-574 carve-out sentence verbatim.
  Why: §3 is the contract that defines what every Tier-D stream can and cannot constrain; §5 I6 is the I6 thermal leg definition; §6 Tier D is the v5 architecture; §9 is the boundary on every claim.

### Supporting

- Powell et al. (2023) *JGR Planets*, doi:10.1029/2022JE007532. Open access at the journal; PDS Geosciences Node urn:nasa:pds:lro_diviner_derived1:data_derived_ghrm. Source of the topography-removed nighttime temperature and rock-abundance products (GHRM 128 ppd; 236.9 m/px equator, 150 m/px at INGENIIPIT -36°, 81 m/px at IRIDIUMPIT1 +46°). The LUNARVOID Tier-D Diviner thermal input.
  Why: This is the source-of-truth paper for the Diviner thermal data products; `01_WORKSPACE/data/MANIFEST.md` lines 178-207 document the project copy (TBOL mosaic, RA mosaic; sha256-verified 2026-08-22). Re-read before working on the I6 damping-depth inverse workflow.

- Carrer et al. (2024) *Nature Astronomy* 8(9), 1119-1126, doi:10.1038/s41550-024-02302-y. The radar-bright conduit beneath Mare Tranquillitatis Pit (Mini-RF S-band SAR; ~150 m resolution). The Moon's sole instrumented subsurface void; the carve-out from v5 §9.
  Why: This is the only published instrumented subsurface result on the Moon; the v5 §9 carve-out sentence names it by reference. The LUNARVOID claim-discipline anchor for "nothing subsurface is verifiable today except …". `01_WORKSPACE/papers/paper1_resolution_limits/main.md` lines 664-669 carry the formal citation.

- Kaku et al. (2017) *GRL* 44, doi:10.1002/2017GL074998. SELENE (Kaguya) Lunar Radar Sounder 5 MHz tracks over Marius Hills. Subsurface echoes consistent with a void extending tens of km west of Marius Hills Hole. The strongest independent corroboration of the GRAIL result (Chappaz 2017; Zhu 2024); one leg of the Marius Hills multi-evidence anchor.
  Why: This is the source-of-truth paper for the LRS Tier-D leg; the v5 §6 line 398-400 Marius Hills reference wording "supported by LRS and GRAIL" cites it. `01_WORKSPACE/notes/prior_art_matrix.md` line 53 carries the full bibliographic anchor.

- Horvath et al. (2022) *GRL*, doi:10.1029/2022GL099710. Diviner nighttime thermal observations of lunar pits (Tranquillitatis, Ingenii) with thermal modelling. The "important negative result": thermal IR readily detects the pit signature but is essentially insensitive to whether a cave lies behind it.
  Why: This is the cautionary result that anchors the v5 §3 row 6 column 4 ("THE CAVE BEHIND THE PIT. Blind to it."); the row-6 column-3 "roof thickness via damping inversion" caveat comes from this paper's framing. `01_WORKSPACE/notes/prior_art_matrix.md` line 56 carries the full bibliographic anchor.

- `01_WORKSPACE/data/MANIFEST.md` — Powell rows (lines 178-207). The project copy of the Powell 2023 GHRM (TBOL mosaic, RA mosaic; sha256-verified 2026-08-22). The 4/7 coverage gap (TRANQPIT1, MARIUSPIT01, IRIDIUMPIT1, PRCLRMPIT01 all-sentinel in equatorial/sub-arctic gap band; SWFECUNPIT1 partial; INGENIIPIT + FECNDITATS2 fully usable) is documented. The INGENIIPIT +2.65 K reframing as rocky-ejecta counter-evidence (RA 0.98% vs 0.50% local mare ≈2×) is documented.
  Why: This is the project-side manifest for the Tier-D Diviner data; the empirical sentinel handling (float32 0.0 not NaN; 96% zeros in equatorial TBOL/RA matching the coverage gap) is a property of the PDS public-domain GHRM product, not a code bug.

- `01_WORKSPACE/papers/gate_reports/GATE_G1_report_v1.0.md` — G1 FINAL-PASSED. Row 6 (line 31) the Diviner thermal line with honest coverage flag: 2/7 fully usable; 4/7 all-sentinel; 1/7 partial; INGENIIPIT +2.65 K reframed as rocky-ejecta counter-evidence; site-scale only (tube-scale sub-pixel). Row 7 (line 32) the multi-evidence stacking limitation (morphometry-only at G1).
  Why: The G1 row 6 verdict is the project's documented Tier-D Diviner result; the GATE_G2_report_v1.0 row 5 (line 100) carries the same PARTIAL verdict forward without re-running. Re-read before any Tier-D claim in Paper 2.

### Caveats

- The Powell 2023 GHRM equatorial/sub-arctic coverage gap is an empirical property of the PDS public-domain product (4/7 G1 candidate DTMs sit in the gap band; 96% zeros in equatorial TBOL/RA matching the coverage pattern). The LUNARVOID project cannot close this gap with code; the only closure path is a future higher-resolution thermal product (Chandrayaan-2 thermal channels; a future thermal mapper at 10-50 m/px).
- The Carrer 2024 carve-out is site-specific (Mare Tranquillitatis Pit) and stream-specific (Mini-RF S-band). No inference about any other site from a Mini-RF / DFSAR observation is supported. The v5 §9 carve-out sentence is the boundary on every claim.
- The GRAIL Chappaz 2017 / Zhu 2024 candidate geometry (9 km × 60 km × 605 m, 55 m central height) is regarded by Blair 2017 stability modelling as implausible as a single stable void; v5 §3 lines 128-132 verbatim. Any GRAIL Tier-D leg produces a 10-30 km mass deficit, never a 60-300 m tube constraint.
- The SELENE LRS 5 MHz echo at Marius Hills (Kaku 2017) is the strongest published LRS result for any candidate site; no other site has a published LRS echo. The LRS is mission-bounded (SELENE 2007-2009) and sparse-tracked (~5° spacing at most latitudes); new LRS data will not be acquired.
- The Tier-D integration architecture is the v5 §8 WP3 multi-evidence fusion; Paper 2's contribution is the scale-bridging methodology (v5 §3 line 137 verbatim: "publishable independent of the lunar result"), not a tier-A tube detection.

---

## Topic G — Photogrammetry (NAC + ISIS3 + ASP)

### Primary resource

- `00_SOURCE_ORIGINALS/VPS_Setup_Guide_Lunar_Photogrammetry.txt` — authoritative VPS setup guide (289 lines). §0 short answer (lines 8-34): "YES ... BUT: a standard cheap VPS (2 vCPU / 4 GB RAM / 80 GB SSD) will fail. Not 'be slow' - fail. Ames Stereo Pipeline will run out of memory and die." Three tiers (lines 36-68): TIER 0 ~$6-20/mo (analysis only; 2-4 vCPU, 8-16 GB RAM, 200-500 GB disk); TIER 1 ~$50-150/mo (photogrammetry; 16-32 DEDICATED cores, 64-128 GB RAM, 1-2 TB NVMe); TIER 2 ~$0.30-2.00/hr (GPU, hourly). §2 critical VPS buying traps (lines 71-118): TRAP 1 burstable vCPU; TRAP 2 NFS/spinning disk; TRAP 3 bandwidth; TRAP 4 the 520 GB ISIS data area; TRAP 5 OS; TRAP 6 snapshot the image. §3 where the free data actually is (lines 121-163): PDS NAC DTM RDR archive + footprint shapefile; NAC Stereo Catalog (PDF); SLDEM2015; LOLA; Diviner/Mini-RF/GRAIL/SELENE LRS/M3; Pit Atlas; LROC EDR/CDR via PDS Imaging Node; Chandrayaan-2 via ISRO ISSDC Pradan. §4 minimal setup Tier 1 (lines 166-228): the literal conda + tarball install (base ~26 GB + LRO --exclude="kernels/**" + ASP tarball); the literal 5-stage ISIS3 ingest + ASP stereo + point2dem command sequence; the lronaccal RADIANCE-vs-IOF gotcha (lines 196-200 verbatim: "GOTCHA: lronaccal defaults to RadiometricType=IOF, which needs the target-to-sun distance. The SPICE Web Service does not attach that, so IOF against web=yes produces cubes full of zeros. Either use RADIANCE (as above), or download the local mission data. This one silently wastes days if you do not know it."). §5 realistic budget and sequencing (lines 230-250): Months 0-6 Tier 0 only; Months 6-12 Tier 2 GPU hours as needed; Months 12+ Tier 1 only when needed; total plausibly under $600-800 self-funded across 18 months.
  Why: §0 is the sizing verdict; §1-§2 are the hardware floor + traps; §4 is the literal recipe the project's photogrammetry scripts (`01_WORKSPACE/code/wp8_stereo/retry_nac_edr_fetch.py`) operate against. The VPS guide is the v5 §7 "INFRASTRUCTURE AND BUDGET" (lines 407-437) predecessor document; the v5 master plan adopts and condenses its sizing rules. The LUNARVOID photogrammetry lessons (0025-0029) cite VPS §4 lines 188-213 verbatim for the literal command sequence.

- `00_SOURCE_ORIGINALS/LUNARVOID_Master_Plan_v5_Full_Synthesis.txt` — v5 master plan §7 INFRASTRUCTURE AND BUDGET (lines 407-437 verbatim): TIER 0 ~$10-20/mo "2-4 vCPU, 8-16 GB RAM, 200-500 GB disk"; TIER 2 ~$0.30-2.00/hr GPU hourly on demand; TIER 1 ~16-32 DEDICATED cores (not burstable vCPU), 64-128 GB RAM, 1-2 TB NVMe scratch, "ASP guidance: ~20k x 20k px imagery needs ~40 GB RAM and 16 cores for 4-20 hours per model; SGM/MGM subprocesses can exceed 4 GB each (8 processes on 64 GB is workable). Budget 100-250 GB scratch per stereo pair; use --keep-only and --resume-at-corr for spot instances." KNOWN TRAPS (lines 425-433 verbatim): "Burstable vCPUs throttle after credits; ASP saturates every core. NFS destroys ASP I/O; use local NVMe. Full ISIS data area is ~520 GB. Pull base (~26 GB) plus lro --exclude='kernels/**'; use spiceinit web=yes. lronaccal defaults to RadiometricType=IOF, which needs target-to-sun distance the SPICE web service does not attach — producing cubes full of zeros. USE RADIANCE. This one silently wastes days." v5 §8 WP0 (lines 443-452 verbatim): "Reproduce one published NAC DTM end-to-end at Mare Tranquillitatis Pit to within its stated error bars (budget 4-6 weeks; treat as a milestone). This de-risks the entire photogrammetry arm before it is needed." v5 §9 (lines 572-574 verbatim): "Nothing subsurface on the Moon is verifiable today except the radar-evidenced Tranquillitatis conduit" — the claim discipline boundary that any new Tier-1 DTM must respect.
  Why: §7 is the project-side sizing contract; §8 WP0 is the de-risk milestone the Phase 5 lessons converge on; §9 is the boundary every photogrammetry claim respects. Together they define what the LUNARVOID project's photogrammetry work does and does not claim.

### Supporting

- `01_WORKSPACE/code/wp8_stereo/retry_nac_edr_fetch.py` — NAC EDR retry fetcher with multi-endpoint fallback. 4-stage retry (lines 84-91 verbatim): legacy `https://pds.lroc.im-ldi.com/data/LRO-L-LROC-2-EDR-V1.0/LROLRC_2001/DATA/SDP/NAC_IMG/{product_id}.IMG`; mcp `https://pds.mcp.nasa.gov/data/lroc/LRO-L-LROC-2-EDR-V1.0/LROLRC_2001/DATA/SDP/NAC_IMG/{product_id}.IMG`; wms `https://wms.lroc.im-ldi.com/data/LRO-L-LROC-2-EDR-V1.0/LROLRC_2001/DATA/SDP/NAC_IMG/{product_id}.IMG`; Wayback CDX fallback (line 91). Input: `01_WORKSPACE/data/wp8_stereo/nac_edr_retry_queue.csv` (rows 2-3 verbatim: M137332905LE,TRANQPIT1,450000000,LE; M137332905RE,TRANQPIT1,450000000,RE). Output: per-row retry log at `01_WORKSPACE/data/wp8_stereo/nac_edr_retry_log.csv`. Status codes (lines 28-34): SKIP_EXISTS / OK_<endpoint> / HTTP_<code>_<endpoint> / URL_NOT_FOUND / WAYBACK_FOUND / WAYBACK_NOT_FOUND / ERROR.
  Why: This is the project's working PDS fetch path as of 2026-08-28; all 3 PDS endpoints are intermittently 404/403 per `01_WORKSPACE/data/wp8_stereo/retry_status_2026-08-28.md` lines 15-17 verbatim. The script's retry log is the audit trail; the WP0 pipeline is gated by data availability through this script.

- `01_WORKSPACE/code/wp8_stereo/enumerate_lroc_dtm_availability.py` — enumerates the project's NAC DTM availability across the candidate registry; output `01_WORKSPACE/data/lroc_dtm_availability.csv` (with DTM ID, lat/lon, terrain, footprint URL, resolution, on-disk status, relat_le, triang_rms columns). The TRANQPIT1 row (line 9 verbatim): 2.0 m/px, relat_le 0.72 m, triang_rms 0.379 m, "good" status; sha256 `3cf53c33783cb43d8788d71837c43e322ce015d9ef4b3f0f61709e9e98fbc662` per MANIFEST.md line 34.
  Why: This is the per-DTM index the WP0 reproduction compares against; the WP0 success criterion (v5 §8 line 451-452 verbatim "match the published product within its stated error bars") uses relat_le + triang_rms as the tolerance envelope.

- `01_WORKSPACE/data/wp8_stereo/retry_status_2026-08-28.md` — current PDS endpoint status snapshot (2026-08-28). All 3 endpoints intermittently non-functional (lines 15-17 verbatim): legacy 404 x4 unchanged from 2026-08-23 baseline; mcp 403 x4 (changed from 404 on 2026-08-23); wms 404 x4 unchanged. Comparison + next-steps verbatim; the retry log is the audit trail.
  Why: This is the project-side snapshot of PDS access; the photogrammetry pipeline's gating risk (data availability) is documented here.

- `01_WORKSPACE/data/outputs/wp0_scope_map/relevant_pits_x_dtms.csv` — pit × stereo pair × DTM index. Each catalogued pit row includes the `StereoIDs` field (from the Lunar Pit Atlas; per MANIFEST.md line 132 verbatim "StereoIDs: Image IDs of the the best stereo pair of the pit, if any exist."). TRANQPIT1 row (line 5 verbatim): "M152655237R,M137332905R", dtm_path=`NAC_DTM_TRANQPIT1`. SWFECUNPIT1 row (line 6 verbatim): "M1341063036R,M1297582135L" but no DTM (`STEREO_NO_DTM` per `pit_coverage_summary.csv` line 5). The third row (SW Mare Tranquillitatis B Pit, line 7 verbatim): "N/A" — no buildable pair at all.
  Why: This is the pair index the WP2 Tier-1 build cycle queries; rows where `StereoIDs` is non-empty but `dtm_path` is empty are the build backlog (v5 §8 line 486 verbatim "Targeted Tier-1 DTM builds only where the Stereo Catalog permits").

- Beyer et al. (NAC DTM quality standards; LROC team) — the published NAC DTMs in the PDS RDR archive carry per-DTM error metrics in the footprint shapefile (`NAC_DTMS_README.TXT` lines 26-27 verbatim: `conv_angle — Convergence angle between the images in the stereo pair`; `num_stereo — Number of stereo pairs used to create DTM`; plus `relat_le — Relative Linear Error. Vertical precision of the DTM, calculated at 90% confidence level by SOCET SET`; `triang_rms — Triangulation RMS. Root mean square error of the multi-sensor triangulation performed by SOCET SET to align the images`). These metrics are the quality gate the project's WP0 reproduction matches against.
  Why: This is the LROC team's NAC DTM quality standards; the WP0 success criterion (v5 §8 line 451-452 verbatim "match the published product within its stated error bars") uses `relat_le` (90% confidence vertical precision) + `triang_rms` (triangulation RMS) as the tolerance envelope. Every published NAC DTM in `01_WORKSPACE/data/lroc_dtm_availability.csv` carries these metrics.

- Beyer, R. A.; Alexandrov, O.; McMichael, S. (2018) "The Ames Stereo Pipeline: NASA's open source automated stereogrammetry software for planetary terrain", *Earth and Space Science* 5(9), 537-548, doi:10.1029/2018EA000409. The Ames Stereo Pipeline (ASP) reference paper. The LUNARVOID photogrammetry chain uses ASP via the prebuilt binary tarball per VPS §4 line 184-187 verbatim; the key flags (`--stereo-algorithm asp_mgm`, `--subpixel-mode`, `--corr-memory-limit-mb`, `--bundle-adjust-prefix`, `--keep-only`, `--resume-at-corr`) are documented in the ASP GitHub releases + the Beyer et al. paper.
  Why: This is the ASP source-of-truth paper; the LUNARVOID Phase 5 lessons cite the ASP flag set and the hardware sizing rules from the paper's documentation.

- USGS ISIS3 official documentation — the ISIS3 (Integrated Software for Imagers and Spectrometers) documentation at https://isis.astrogeology.usgs.gov/. ISIS3 is the US Geological Survey Astrogeology Science Center's planetary image processing package; the LUNARVOID chain uses ISIS3 for ingestion + SPICE attachment + map projection via the conda-forge package `isis` per VPS §4 line 170 verbatim `conda create -n isis -c usgs-astrogeology -c conda-forge isis rclone`. The key programs (`lronac2isis`, `spiceinit`, `lronaccal`, `lronacecho`, `campt`, `cam2map`) are documented in the ISIS3 documentation; `campt` and `cam2map` are the geometry-query and map-projection workhorses per Lesson 0026.
  Why: This is the ISIS3 source-of-truth documentation; the LUNARVOID Phase 5 lessons reference the ISIS3 command-line interface and PVL label conventions.

- NAC Stereo Catalog (PDF; LROC team) — per VPS §3 line 134-136 verbatim: "Lists all NAC stereo pairs and triplets suitable for DTM generation. This tells you what you could build that does not exist yet." PDF parsing only; per MANIFEST.md line 98 verbatim "Full catalog only when planning DTM builds beyond pits." Available at https://wms.lroc.asu.edu/lroc/content/new-products.
  Why: This is the LROC team's curated pair index for DTM production; the pit-centric `StereoIDs` field in the Lunar Pit Atlas is the LUNARVOID project's preferred entry point (per MANIFEST.md line 98 verbatim) and the NAC Stereo Catalog is the supplement for footprints outside the catalogued pits.

### Caveats

- The photogrammetry pipeline is gated on Tier-1 rental per v5 §7; the Phase 5 lessons are training material for when the gate opens. Until then, the LUNARVOID pipeline operates on the 660 published NAC DTMs (MANIFEST.md line 12 verbatim "releases through 2026-06-15; 660 DTMs"; ~2% of maria coverage).
- The lronaccal IOF→zero-cube trap (VPS §4 line 196-200 + v5 §7 KNOWN TRAPS verbatim) is silent; always set `radiometrictype=RADIANCE` explicitly when running with `spiceinit web=yes`. The cube is well-formed, the program exits 0, every pixel is 0.0 — only pixel-value inspection reveals the bug.
- PDS endpoint access is the gating risk as of 2026-08-28: all 3 endpoints intermittently 404/403 per `retry_status_2026-08-28.md` lines 15-17 verbatim. The `retry_nac_edr_fetch.py` 4-stage retry (legacy, mcp, wms, Wayback CDX) is the working path; the retry log is the audit trail.
- The 226 of 278 tier-C registry rows without LROC NAC DTMs (referee response Q8 line 121) are not errors in the project bookkeeping — they are the genuine coverage gap that the Tier-1 build cycle (deferred until rental authorised) or future LROC quarterly releases would close. The WP0 TRANQPIT1 reproduction is the de-risk milestone (v5 §8 line 453 verbatim) before committing to the 226-row build backlog.
- Claim discipline: any new Tier-1 build produces a NAC DTM that feeds the morphometry chain (Phase 3); the chain output remains tier-C inference (calibrated morphometry), never tier-A detection (v5 §9 carve-out line 572-574 verbatim: "Nothing subsurface on the Moon is verifiable today except the radar-evidenced Tranquillitatis conduit"). The photogrammetry work extends the morphometry universe; it does not by itself produce a tier-A claim.

---

## Topic H — Writing & publication

### Primary resource

- `00_SOURCE_ORIGINALS/LUNARVOID_Master_Plan_v5_Full_Synthesis.txt` — v5 master plan §12 Timeline and Deliverables (lines 628-637; M3 G0 / M9 G1 PAPER 1 / M15 G2 PAPER 2 / M24 G3 PAPER 3 / M30 PAPERS 4-5); §12 PUBLICATION STRATEGY (lines 639-651 verbatim: 6 venues for 6 deliverables; Nature Astronomy reserved for "a genuinely surprising, independently corroborated result"); §12 POSITIONING (lines 652-663 verbatim: the single-sentence DLR-institute-of-data-science framing that the cover letter and graphical abstract pass without modification); §3 line 137 verbatim (the scale-bridging machinery is "publishable independent of the lunar result"; the foundation for Paper 3's IEEE TGRS venue); §9 MANDATORY REPORTING (lines 555-574 verbatim: FP per 10⁴ km² not FP rate; calibrated inference never verified detection; the Tranquillitatis carve-out; the title-discipline anchor).
  Why: §12 is the contract that defines which paper goes where; §3 line 137 is the publishable-independently anchor that justifies the multi-paper strategy; §9 is the claim-discipline boundary every paper respects.

- `01_WORKSPACE/papers/paper1_resolution_limits/main.md` — Paper 1 (~720 lines; the worked example for the whole publication package). Abstract (lines 24-88) carries the per-rung numbers + claim-discipline caveats + Tranquillitatis anchor verbatim. §1.1 The base-rate problem (lines 92-101): ~20 tube-relevant lunar pits, ~281 catalogued, 278 tier-C morphometry rows, 0 verified negatives; 1% FP rate → 0.8% precision over 240,000 mare tiles; FP per 10⁴ km² is NOT MEASURED until survey-grade DTMs. §1.2 What the paper IS / IS NOT (lines 103-114): IS a benchmark; IS NOT a global detection claim; IS NOT a GRAIL/Mini-RF paper. §3.3 detector recipe (lines 152-172): depression-depth = Planchon-Darboux fill - DTM; Frangi sigmas 30/60/100/150/200/300 m; depth × vesselness score; 5-cell local-max. §4.2 Table 1a aggregate row (line 262): 3.74 [Poisson-exact 95% CI 1.71, 7.10] per 10⁴ km² over 24,062.96 km²; n_fp=9, n_tp=14, n_above_local_floor=45. §5.2 limitations (lines 545-583): 7 limitation bullets including the survey-grade FP gap and the I12 confound-covariate null gap.
  Why: §1.1 is the base-rate anchor; §3.3 is the recipe; §4.2 Table 1a is the headline number; §5.2 is the limitations block that the §9 claim-discipline framework requires. The file is the worked example for every Paper 2-6 in the v5 §12 strategy.

- `01_WORKSPACE/papers/paper1_resolution_limits/cover_letter.md` — Cover letter for the RSE submission (28 lines). The 4-paragraph template (paragraph 1 lines 14: title verbatim "Detectability limits for lava tube roof signatures in orbital topography: the LLTB-1 calibrated benchmark" + venue + 1-sentence contribution + load-bearing parenthetical "predict-all tile extrapolation, not a survey rate"; paragraph 2 lines 16: ESSA positioning on three substantive grounds — inference vs detection; 3D morphometry vs 2D imagery; per-rung 50/50 threshold hold-out — closing with Carrer 2024 anchor; paragraph 3 lines 18: 3-count fit-to-scope argument mirroring the 3-ground positioning + secondary venue ISPRS J. Photogramm. with "we would welcome transfer"; paragraph 4 lines 20: declarations + data discipline — NASA analog research-use-only + PDS fetch-by-ID + ISRO acknowledgement not required + LU5M812TGT not used + CRediT + single-author note).
  Why: This is the worked example for the 4-paragraph template every paper in v5 §12 follows; the template is engineered to be hard to refute on any single paragraph without engaging with the underlying data and the v5 §9 framework.

- `01_WORKSPACE/papers/paper1_resolution_limits/referee_response_template.md` — 28 pre-prepared Q/A stubs Q1-Q28 (286 lines). Header (lines 7-14: manuscript title / round / date / corresponding author). Per-comment response structure (lines 20-36: Section A referee comment verbatim; Section B 4-move response from Section D; Section C manuscript change with before/after diff + reason). Section D rebuttal-structure template (lines 39-54: 4 moves + 4 stylistic rules — calibrated inference never verified detection; exact number with file path; failures are findings not shames; FP per 10⁴ km² is calibration-context NOT survey). 28 stubs Q1-Q28 covering 8 categories: statistics/FP framing (Q1, Q3, Q26, Q27); methodology/detector (Q4, Q5, Q9, Q14, Q17, Q18, Q25); scope/generalisation (Q6, Q10, Q15, Q16, Q24); novelty vs ESSA (Q2); subsurface evidence anchor (Q8, Q23); multi-evidence stacking (Q7); engineering/data (Q11, Q12, Q13, Q19, Q20, Q21, Q22); title discipline (Q28).
  Why: This is the project's working Q/A library; expansion-time savings on receipt of a decision letter is ~10-15 min per stub vs ~60-90 min from scratch. The library grows by ~4-8 stubs per paper in v5 §12.

- `01_WORKSPACE/papers/paper1_resolution_limits/highlights.md` — 5 highlights for RSE submission, each ≤85 characters including spaces (RSE limit). H1: "LLTB-1 sets first-of-their-kind F1/P/R curves across LROC NAC GSD bands (0.5–10 m)" (82 chars). H2: "Cycles 1-2 closed TYCHOPK + 3 DTMs; aggregate FP 3.74 [1.71, 7.10] per 10⁴ km²" (78 chars). H3: "278 tier-C rows: 45 above-floor + 233 below-floor; 14 single-method inferred voids" (82 chars). H4: "Tranquillitatis radar conduit (Carrer 2024) = Moon's sole instrumented subsurface" (81 chars). H5: "V5 claim discipline: lunar FP per 10⁴ km² stays NOT MEASURED until survey-grade DTMs" (84 chars). Provenance table per highlight (lines 22-27); char-count verification (lines 49-54).
  Why: The RSE submission requires 3-5 highlights with character limits; the char-count discipline is mechanical but easy to miss; this file is the project's reference for what passes the limit and what each highlight's source is.

- `01_WORKSPACE/papers/paper1_resolution_limits/suggested_reviewers.md` — 6-row reviewer template R1-R6 covering 5 expertise areas: R1 lunar pit / planetary cave detection (direct ESSA competitor); R2 LROC NAC pit catalog / morphometry (Wagner & Robinson 2021 group); R3 photogrammetry / point-cloud kriging (Mueller 2026 group; I1-I7 audit); R4 forest / VCI / UAV-LiDAR (Reichenzeller 2026 group; I8-I15 audit); R5 lava tube stability (Blair / Chwala / Theinat group); R6 radar sounder / Tranquillitatis anchor (Carrer 2024 / Mini-RF team). Minimum slate: R1+R3+R4+R5; 5-reviewer adds R6; 6-reviewer adds R2. RSE Editorial Manager field mapping (lines 192-205); pre-submission checklist (lines 209-224).
  Why: The expertise-area mapping is anchored in cited references (not invented); the template's caveat (lines 12-21) explicitly states the user fills in real names without fabricated affiliations; the minimum-slate formula ensures every paper has the required expertise areas covered.

- `01_WORKSPACE/papers/paper1_resolution_limits/graphical_abstract_plan.md` — 4-panel graphical abstract layout (Panel A analog benchmark; Panel B lunar pipeline; Panel C headline number with sub-callouts; Panel D honest limitations). Plan only — graphic not yet generated (line 4 verbatim "PLAN ONLY — do NOT generate the graphic yet"). Typography + color guidance (lines 116-130: serif type; cividis colormap; muted ochre for headline; muted brick for caveats; no gradients, no shadows, no glow). Verbatim text strings (lines 138-157). Tool recommendation (matplotlib Agg + Pillow; lines 162-167). Estimated generation time: ~2 hours (lines 190-197).
  Why: RSE graphical abstract is required, ≤1 page; the plan defines the panel layout + verbatim text strings + typography guidance before any graphic is generated; the "do NOT generate yet" rule is the discipline that keeps the plan from being committed before user approval.

### Supporting

- `01_WORKSPACE/admin/hetzner_rental_kit/README.md` — Hetzner Cloud Tier-1 burst compute kit (188 lines). cx52 (24 vCPU AMD EPYC; 128 GB DDR4 ECC; 2×1 TB NVMe; Ubuntu 22.04 LTS; 20 TB/month egress; ~$55/mo on-demand 2026-Q3). 2-month total $110; below $150 ceiling; 3-month $169.50 rejected by launch.sh guard. Pre-launch checklist (lines 54-63): user authorisation + budget log row + API token + SSH key. Work-queue (5 priority tasks at `work_queue/`): 00_pds_retry.md → 01_stereo_pipeline.md → 02_sldem2015.md → 03_p3_1c_n51.md → 04_mgc3_paper2.md. Teardown via `teardown/nuke.sh` (audited path). D2 trigger APPROVED 2026-08-22 per `plans/2026-08-22_GATE_G1_report_v1.0.md` §3 row 9; rental NOT yet authorised pending PDS NAC_EDR path resolution (per `data/wp8_stereo/retry_status_2026-08-28.md` lines 15-17 verbatim all 3 PDS endpoints intermittently non-functional).
  Why: This is the launch-ready Tier-1 implementation; the D2 trigger is approved but the rental is gated on PDS recovery; the work-queue defines what the cx52 does when launched; the $150 ceiling guard enforces budget discipline.

- `00_SOURCE_ORIGINALS/VPS_Setup_Guide_Lunar_Photogrammetry.txt` §5 realistic budget (lines 230-250) — the VPS-guide perspective on the same budget math: "Months 0-6 Tier 0 only; Months 6-12 Tier 2 GPU hours as needed; Months 12+ Tier 1 only when needed; total plausibly under $600-800 self-funded across 18 months." Independent confirmation of the v5 §7 sequencing; the VPS guide is the upstream sizing rationale; v5 §7 is the v5 adoption.
  Why: The VPS guide is the source-of-truth for the Tier sequencing rationale; v5 §7 adopts and condenses the sizing rules.

- `01_WORKSPACE/plans/2026-08-22_GATE_G1_report_v1.0.md` §3 row 9 — the G1 gate report row that approved the D2 Tier-1 trigger on 2026-08-22. The trigger covers the right to rent; the rental itself is gated on PDS availability (per Hetzner README.md line 105 verbatim "PDS endpoints have been 404 since 2026-08-23").
  Why: This is the audit trail for the D2 approval; the GATE_G1 report is the project's gate-decision document; row 9 is the row that matters for the rental decision.

- Gregory et al. (advice on scientific writing) — classic guidance on scientific writing structure (the IMRaD pattern; the title discipline; the cover-letter convention). The Paper 1 cover-letter 4-paragraph template and the title-discipline rule are operationalisations of this guidance, anchored in the v5 §9 claim-discipline framework.
  Why: Background reading on scientific-writing conventions; the project's actual templates are operational, file-anchored versions of this guidance.

- Referee-report response templates from journal-editor websites (RSE Editorial Manager; ISPRS; Icarus; IEEE TGRS; JGR Planets; Acta Astronautica; IEEE RA-L) — each journal provides a structured rebuttal template; the LUNARVOID project's per-comment A/B/C structure (Section A verbatim; Section B 4-move response; Section C before/after diff) is the project's standard, compatible with all of the journal templates.
  Why: The per-comment structure must be compatible with each target journal's editorial-manager format; the LUNARVOID standard is engineered to round-trip cleanly through RSE / ISPRS / Icarus / IEEE TGRS editorial systems.

### Caveats

- The 6-venue publication strategy is the v5 §12 line 639-651 verbatim mapping; it is not a tentative plan that may change with referee feedback. Venue changes between RSE / ISPRS (Paper 1), Icarus / PSS (Paper 2), IEEE TGRS (Paper 3), JGR Planets (Paper 4), Acta Astronautica (Paper 5), and IEEE RA-L (Paper 6) are the v5 contract.
- Nature Astronomy is reserved for a "genuinely surprising, independently corroborated result" per v5 §12 lines 649-650 verbatim. The 14 single-method inferred void candidates in the Paper 1 registry are tier-C morphometry, not independently corroborated; submitting to Nature Astronomy at the Paper 1 or Paper 2 stage would violate the v5 contract.
- The D2 trigger for the Hetzner Tier-1 rental is APPROVED 2026-08-22 but the rental is NOT authorised. The PDS NAC_EDR 404/403 status as of 2026-08-28 (per `data/wp8_stereo/retry_status_2026-08-28.md` lines 15-17 verbatim) is the gating risk; renting before data is available burns the budget on idle cores.
- The 28-Q pre-prepared library is content-stable across Paper 1 and Paper 2 for ~11 stubs (Q1, Q3, Q8, Q9, Q11, Q12, Q13, Q20, Q22, Q27, Q28); the remaining ~17 stubs are Paper-1-specific and need venue-specific reframing for Paper 2 (Icarus observational scope vs RSE methodological scope). The library grows by ~4-8 stubs per paper.
- The graphical abstract is PLAN ONLY; the actual graphic is not generated until user approval per `graphical_abstract_plan.md` line 4 verbatim. Generating the graphic before plan approval violates the project's "plan first, then execute" discipline.
- The 4-paragraph cover letter template is engineered to be hard to refute on any single paragraph without engaging with the underlying data. A reviewer who disagrees with paragraph 2 (ESSA positioning) must engage with the three-ground argument; a reviewer who disagrees with paragraph 3 (RSE fit-to-scope) must engage with the three-count argument; a reviewer who disagrees with paragraph 4 (data discipline) must engage with the v5 §9 MANDATORY REPORTING framework.

---

## Topic I — Project operations (orchestrator + 5 agents + commit discipline)

### Primary resource

- `00_SOURCE_ORIGINALS/LUNARVOID_Master_Plan_v5_Full_Synthesis.txt` — v5 master plan §10 RISK REGISTER (lines 575-604). The 12 risks R1-R12 + 6 deliberate exclusions (no global detection claim; no gravity inversion for sub-kilometre geometry; no in-house robotic hardware; no mineral/ice classification without matched spectral ground truth; no ISRU or life-support engineering; no claim of verified subsurface detection beyond existing radar evidence) are the safety rails every paper / every phase / every orchestrator cycle respects. Why: §10 is the v5 contract that defines what the project does NOT do; the orchestrator's stop conditions in `lunarvoid-protocol` SKILL.md lines 75-83 verbatim are the operational codification of these rails.

- `.opencode/skills/lunarvoid-protocol/SKILL.md` — The protocol skill (183 lines). Roles table lines 8-20 verbatim (5-agent team + their permission boundaries); task lifecycle lines 30-73 (5-step autonomous loop with the 6 h lock TTL + re-acquire-at-start-of-cycle rule); stop conditions lines 75-83 (5 halts including cost trigger; gate decision; verifier FAIL ×3; T5 regression; out-of-workspace write); skeptic gate lines 85-92 (4 trigger conditions + "FU / downgrade / commit over an UNSOUND verdict" rule); commit-message convention lines 120-166 (5 hard rules + 6 forbidden phrases + re-rewrite tool); LLTB-1 release protocol lines 168-174; context discipline lines 176-183. Why: This is the meta-resource on how the agents are wired; the source-of-truth for the orchestrator loop.

- `.opencode/skills/lunarvoid-conventions/SKILL.md` — The technical conventions skill (283 lines). §1 environment paths (Python venv at `~/lunarvoid/venv/`; rasters only under `~/lunarvoid/data/`); §2 terrain-engine Planchon-Darboux mandate (the non-negotiable; Wang & Liu + breach fills DRAIN the NoData pit floor); §3 lunar geodesy (NAC DTM GeoTIFFs use LOCAL equirectangular CRS `+proj=eqc +lat_ts=<center_lat> +lon_0=180 +R=1737400`; pit geodesy via `pyproj.CRS.from_proj4("+proj=longlat +R=1737400 +no_defs")`); §6 statistics + claim discipline (seeds fixed at 42; 50/50 cal/test splits; FP per 10⁴ km² as primary FP metric; calibrated inference never verified detection; $0 until §8 cost trigger); §7 verification habits (after ANY module change run `~/lunarvoid/venv/bin/python 01_WORKSPACE/code/smoke_test.py`; known-good: per-rung F1 0.39/0/0.80 on synthetic; fusion AUC 0.990). Why: This is the meta-resource on terrain-engine rules; every agent loads it before any technical work per skill line 20 verbatim.

- `01_WORKSPACE/admin/CHANGELOG.md` — The project's process ledger (~900 lines across 31 execution sessions as of 2026-08-23). Newest first. Format pinned in `lunarvoid-protocol` skill lines 97-99 verbatim (`## YYYY-MM-DD (execution session N)` heading + bullets: task, headline numbers, deliverable paths, gotchas learned). The worked examples of orchestrator bookkeeping: session 31 (Rounds 7-10 housekeeping + Paper 1 v1.0 release note) lines 6-15; session 29 (Cycle 7 close: Paper 1 v1.0 submission-ready) lines 17-28; session 27 (Cycle 2 close: TYCHOPK) lines 46-70; session 23 (P3.1c growth cycle closed) lines 106-123. Why: This is the project's process memory; CHANGELOG = what we did (skill line 27 verbatim); findings = what we learned. Every orchestrator cycle produces one entry.

### Supporting

- `01_WORKSPACE/admin/hetzner_rental_kit/launch.sh` — Hetzner Tier-1 burst compute launch script (116 lines). The worked example of an operational script the orchestrator produces: header banner lines 1-9 (DO NOT RUN WITHOUT USER AUTHORIZATION); pre-launch checklist lines 11-15 (4 items: user authorisation; budget log row; API token; SSH key); LV_LAUNCH_AUTHORIZED env-var guard line 42 (refuses to run unless `LV_LAUNCH_AUTHORIZED=YES` is set in the calling shell); $150 ceiling guard lines 53-60 (`TOTAL_USD=$((MONTHLY_USD * PROJECTED_MONTHS))` then `if (( TOTAL_USD > 150 )); then exit 1; fi`; 3-month rentals rejected automatically); explicit confirmation prompt lines 64-68; terraform + bootstrap + verify + work-queue hand-off lines 70-116. Why: This is the launch-ready Tier-1 implementation; the script pattern (header banner → pre-launch checklist → mechanical guard → explicit confirmation → step-by-step work → audit-trail hand-off) is reusable for any operational boundary.

- `01_WORKSPACE/admin/hetzner_rental_kit/README.md` — Hetzner rental kit README (188 lines). Server specs (cx52: 24 vCPU AMD EPYC; 128 GB DDR4 ECC; 2×1 TB NVMe; Ubuntu 22.04 LTS; 20 TB/month egress; ~$55/mo on-demand 2026-Q3). Cost ceiling table lines 39-45 (2-month total $114.50 below ceiling; 3-month $169.50 rejected). Pre-launch checklist lines 54-63 verbatim. Work queue (5 priority tasks at `work_queue/`): `00_pds_retry.md` → `01_stereo_pipeline.md` → `02_sldem2015.md` → `03_p3_1c_n51.md` → `04_mgc3_paper2.md`. Teardown procedure lines 84-99 (nuke.sh is the audited path; bypassing via `terraform destroy` leaves dangling volumes and IPs). Why: The Hetzner kit is the Tier-1 implementation; the work queue defines what the cx52 does when launched; the pre-launch checklist is the audit trail for any future rental.

- `01_WORKSPACE/admin/hetzner_rental_kit/teardown/nuke.sh` — Teardown script (the audited path to delete the Hetzner server when the work-queue is drained or the budget cap is hit). Bypass via `terraform destroy` is forbidden (Hetzner README.md line 95-98 verbatim): <em>"Never delete the server out-of-band — <code>nuke.sh</code> is the audited path; bypassing it leaves dangling volumes and IPs that incur post-deletion charges."</em> Why: The teardown script enforces the budget discipline at the close of every rental cycle.

- `01_WORKSPACE/notes/findings.md` — The project's scientific memory (794 lines as of 2026-08-21). Append-only; dated-sectioned (`## <kind> YYYY-MM-DD`); format per entry pinned in protocol skill line 9 verbatim `<code>- CLAIM (confidence) — evidence: <path> — caveat: <known weakness></code>`. The worked examples of skeptic-augmented findings: 2026-08-21 (seed — backfilled headline results) lines 13-42; 2026-08-21 (skeptic corrections, G0' report v1.1 review) lines 44-71 (the G0' report claim refutation); 2026-08-22 (skeptic review, Task 12 analog void ground truth) lines 73-100 (the relabel required + 4 methodological fixes). Why: This is the project's scientific memory; every scientific claim has an evidence link and a caveat; corrections are new dated sections, never retro-edits (skill line 246-251 verbatim).

### Caveats

- The protocol skill's Roles table (lines 8-20 verbatim) is the single source of truth for permission boundaries; any new agent must be added to the table before it can be dispatched. A new agent NOT in the table has no permission boundary; the orchestrator cannot dispatch it.
- The commit-message convention's NO cost info rule (added 2026-08-24 per skill line 132 verbatim) is enforced mechanically by the archivist (skill line 129 verbatim <em>"orchestrator MUST follow; archivist MUST reject"</em>). The 2026-08-24 archive commit rewrite stripped 12 commits of cost phrases via `git filter-branch --msg-filter`; the backup branch `backup/pre-cost-rewrite-original` preserves the pre-rewrite SHAs for audit. Future rewrites (if any) follow the same rule.
- The 6 h lock TTL (skill line 38 verbatim) is the survival mechanism for long pauses between sessions. The orchestrator must re-acquire at the start of every task cycle even within the same session; the lock could have expired during a long verifier run, and a sibling orchestrator (the Hermes-side one) could be waiting.
- The 3-strike rule (skill line 79 verbatim <em>"Verifier FAIL ×3 on one task"</em>) is bounded by the T5 regression trigger (skill line 80-82 verbatim): a regression outside the ±5% envelope on a frozen calibration halts the orchestrator BEFORE the strike count increments. The T5 stop supersedes the strike count.
- The skeptic gate (skill line 87 verbatim <em>"AFTER verifier PASS and BEFORE archivist commit"</em>) fires on 4 trigger conditions only: gate reports; paper sections with claims; CONFIRMED-tier promotions; high-confidence findings entries. Routine work (refactors; documentation; MANIFEST row additions; roadmap ticks) does NOT require the skeptic. Over-using the skeptic on non-claims wastes tokens; under-using it on scientific claims violates the protocol.
- The launch.sh LV_LAUNCH_AUTHORIZED env-var guard (line 42) is a mechanical check, not a convention. The script refuses to run unless `LV_LAUNCH_AUTHORIZED=YES` is set in the calling shell; the default is "NO"; opt-in only. This is the operational codification of the user's "DO NOT RUN WITHOUT USER AUTHORIZATION" rule (Hetzner README.md line 8 verbatim).

---

## Format guidance for new entries (when populated)

```
## Topic <Letter> — <short name>

### Primary resource
- <title>, <authors>, <venue>, <year>, <URL>
  Why: 1-2 sentences on why this is the most authoritative.

### Supporting
- <2-3 more, ordered by trust>

### Caveats
- What the primary gets wrong / doesn't cover.
```

# NOTES — orchestrator working notes + your preferences

> Working notes from the orchestrator that may be useful in future teaching sessions. Edit freely.
> Last edited: 2026-08-26

## Your preferences (observed 2026-08-19 onwards)

- **Terse delegations** — you say "complete all" / "push" / "don't commit" / "fix it" and expect the orchestrator to figure out the scope. Don't ask multi-question debriefs; do the work.
- **Trust the orchestrator's judgment** on scientific claims (you accepted the PARTIAL verdict, the by-terrain split, the calibration-context framing without pushback).
- **Visual inspection is YOURS, not mine.** I write the procedure; you look at the imagery.
- **Zotero library is real** — 10 papers attached (Carrrer 2024, Le Corre 2025, Mueller 2026, Reichenzeller 2026, Wagner & Robinson 2021, Wong 2014, van Ewijk 2011, Blair 2017, Chwala 2024, Theinat 2020). Where possible, prefer DOI lookup.
- **Zotero MCP is reconnected** — `zotero_*` tools should work in subagent dispatches.
- **No cost info in commit messages** going forward (added 2026-08-24). History rewrites are OK.
- **No force-push without explicit "push" instruction** unless you've said so.
- **You like concrete clickable artifacts** — the `visual_inspection_helper.html` pattern worked well. More like that.
- **You don't like abstraction** — when the orchestrator gives you a procedure and you don't understand, ask "explain more concretely." Don't muddle through.

## Working context the orchestrator holds (2026-08-26)

- LUNARVOID project ~40% complete (per v5 master plan effort weighting)
- G0 ✓ FINAL-PASSED · G1 ✓ FINAL-PASSED · G2 ⚠ PARTIAL · G3 ✗ NOT MEASURED
- Paper 1 v1.0 submission-ready (729 lines + cover letter + referee template + graphical abstract plan + reviewer templates)
- 278 tier-C registry rows; aggregate FP **3.74 [1.71, 7.10]** per 10⁴ km² (calibration-context)
- $0 spent; $150 / $800 ceilings intact

## Resources to consult (suggested, not yet curated)

- v5 master plan: `00_SOURCE_ORIGINALS/LUNARVOID_Master_Plan_v5_Full_Synthesis.txt`
- Backlog-of-record: `01_WORKSPACE/Lunar Lavatube knowledge/backlog/Visual inspection index.md`
- Mueller 2026 (kriging): open access, doi:10.1139/as-2025-0062
- Reichenzeller 2026 (VCI): open access, doi:10.3390/f17080807
- Carrer 2024 (Tranquillitatis radar conduit): Nature Astronomy 8:1001-1010
- Wagner & Robinson 2021 (Lunar Pit Atlas): LPSC 52 #2530
- Wong 2014 (NASA analog dataset): https://ti.arc.nasa.gov/dataset/caves

## Open threads

- 27 visual-inspection candidates at 15 unique locations (your eyes)
- pulearn installed at venv (numpy 2.5.2 okay in practice; pulearn's pinned numpy<2.5 is wrong)
- Hetzner rental kit ready at `01_WORKSPACE/admin/hetzner_rental_kit/` (NOT launched; awaiting your authorization)
- 30 random-mare-sites gap (no LROC NAC DTMs)
- PDS NAC_EDR 404s (environmental block)
